const fs = require('fs');
let content = fs.readFileSync('src/main.tsx', 'utf8');

const cleanup = `
try {
  // Security cleanup (CWE-922)
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith('zentora_')) {
      localStorage.removeItem(key);
      i--; // Adjust index since we removed an item
    }
  }
} catch(e) {}
`;

content = content.replace("import App from './App.tsx';", cleanup + "\nimport App from './App.tsx';");
fs.writeFileSync('src/main.tsx', content);
