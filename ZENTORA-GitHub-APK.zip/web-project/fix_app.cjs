const fs = require('fs');
let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

const importSocialSidebar = "import { SocialSidebar } from './components/social/SocialSidebar';\nimport { FeedView } from './components/social/FeedView';\nimport { ProfileView } from './components/social/ProfileView';\nimport { NotificationsView } from './components/social/NotificationsView';\nimport { SearchView } from './components/social/SearchView';\n";
appTsx = appTsx.replace("import { Attachment } from './types';", "import { Attachment } from './types';\n" + importSocialSidebar);

appTsx = appTsx.replace("const [activeSection, setActiveSection] = useState<'chats' | 'contacts' | 'calls'>('chats');", "const [activeSection, setActiveSection] = useState<'chats' | 'contacts' | 'calls'>('chats');\n  const [globalTab, setGlobalTab] = useState<string>('feed');");

const oldAppContent = `        {/* App Content Area */}
        <div className="flex flex-1 overflow-hidden relative w-full h-full">
          
          {/* Sidebar / Chat List */}
          <div className={\`\${activeChatId && isPhoneView ? 'hidden' : 'flex'} w-full \${!isPhoneView ? 'md:w-80 lg:w-96' : ''} shrink-0 h-full\`}>
            <Sidebar
              onOpenCreateChat={() => setShowCreateChatModal(true)}
              onOpenSettings={() => setShowSettingsModal(true)}
              onOpenAdmin={() => setShowAdminModal(true)}
              activeSection={activeSection}
              setActiveSection={setActiveSection}
            />
          </div>

          {/* Center Main Chat Area */}
          <div className={\`\${activeChatId || !isPhoneView ? 'flex' : 'hidden'} flex-1 h-full overflow-hidden relative\`}>
            {activeSection === 'chats' && (
              <ChatArea
                onToggleInfoPanel={() => setShowInfoPanel(!showInfoPanel)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenReport={() => setShowReportModal(true)}
              />
            )}
            {activeSection === 'contacts' && <ContactsView onChatStart={() => setActiveSection('chats')} />}
            {activeSection === 'calls' && <CallsView />}

            {/* Right Info Panel */}
            {showInfoPanel && activeSection === 'chats' && (
              <InfoPanel
                onClose={() => setShowInfoPanel(false)}
                onOpenReport={() => setShowReportModal(true)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenSearch={() => setIsSearchOpen(true)}
              />
            )}
          </div>
        </div>`;

const newAppContent = `        {/* App Content Area */}
        <div className="flex flex-1 overflow-hidden relative w-full h-full">
          
          {/* Global Social Sidebar (Hidden on small mobile if in chat) */}
          {!isPhoneView && (
             <SocialSidebar activeTab={globalTab} onTabChange={setGlobalTab} />
          )}

          {globalTab === 'messenger' && (
            <>
              {/* Sidebar / Chat List */}
              <div className={\`\${activeChatId && isPhoneView ? 'hidden' : 'flex'} w-full \${!isPhoneView ? 'md:w-80 lg:w-96' : ''} shrink-0 h-full border-r border-[var(--border)]\`}>
                <Sidebar
                  onOpenCreateChat={() => setShowCreateChatModal(true)}
                  onOpenSettings={() => setShowSettingsModal(true)}
                  onOpenAdmin={() => setShowAdminModal(true)}
                  activeSection={activeSection}
                  setActiveSection={setActiveSection}
                />
              </div>

              {/* Center Main Chat Area */}
              <div className={\`\${activeChatId || !isPhoneView ? 'flex' : 'hidden'} flex-1 h-full overflow-hidden relative\`}>
                {activeSection === 'chats' && (
                  <ChatArea
                    onToggleInfoPanel={() => setShowInfoPanel(!showInfoPanel)}
                    onOpenMediaViewer={(att) => setSelectedMedia(att)}
                    onOpenReport={() => setShowReportModal(true)}
                  />
                )}
                {activeSection === 'contacts' && <ContactsView onChatStart={() => setActiveSection('chats')} />}
                {activeSection === 'calls' && <CallsView />}

                {/* Right Info Panel */}
                {showInfoPanel && activeSection === 'chats' && (
                  <InfoPanel
                    onClose={() => setShowInfoPanel(false)}
                    onOpenReport={() => setShowReportModal(true)}
                    onOpenMediaViewer={(att) => setSelectedMedia(att)}
                    onOpenSearch={() => setIsSearchOpen(true)}
                  />
                )}
              </div>
            </>
          )}

          {globalTab === 'feed' && <FeedView />}
          {globalTab === 'profile' && <ProfileView />}
          {globalTab === 'notifications' && <NotificationsView />}
          {globalTab === 'search' && <SearchView />}
          {(globalTab === 'store' || globalTab === 'event') && (
            <div className="flex-1 flex flex-col items-center justify-center bg-[#F3F4F6] dark:bg-[var(--background)] text-[var(--text-secondary)]">
              <span className="text-6xl mb-4">🚧</span>
              <h2 className="text-2xl font-bold text-[var(--text-primary)]">Раздел в разработке</h2>
              <p className="mt-2">Скоро здесь появится что-то интересное!</p>
            </div>
          )}

        </div>`;

appTsx = appTsx.replace(oldAppContent, newAppContent);
fs.writeFileSync('src/App.tsx', appTsx);
