const fs = require('fs');
const files = [
  'src/context/AuthContext.tsx',
  'src/context/ChatContext.tsx',
  'src/context/MusicContext.tsx'
];

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/localStorage/g, 'sessionStorage');
  fs.writeFileSync(file, content);
}
