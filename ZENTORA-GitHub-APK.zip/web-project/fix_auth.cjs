const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

// Replace standard exports
code = code.replace(
  'interface AuthContextType {',
  'interface AuthContextType {\n  registeredUsers: User[];'
);

code = code.replace(
  'const [sessions, setSessions] = useState<UserSession[]>(INITIAL_SESSIONS);',
  `const [sessions, setSessions] = useState<UserSession[]>(INITIAL_SESSIONS);
  const [registeredUsers, setRegisteredUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('zentora_all_users');
    if (saved) return JSON.parse(saved);
    // Add current user if not in registry
    if (CURRENT_USER) return [CURRENT_USER];
    return [];
  });
  
  useEffect(() => {
    localStorage.setItem('zentora_all_users', JSON.stringify(registeredUsers));
  }, [registeredUsers]);`
);

code = code.replace(
  'setUser(newUser);',
  `setUser(newUser);
      setRegisteredUsers(prev => [...prev, newUser]);`
);

code = code.replace(
  'value={{',
  'value={{\n        registeredUsers,'
);

fs.writeFileSync('src/context/AuthContext.tsx', code);
