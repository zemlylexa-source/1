const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

// Replace all instances of usr_admin_rafa with something else, or add a filter for it.
// Actually, it's easier to just add usr_admin_rafa filtering.
// We can just replace 'usr_admin_nerik' with 'usr_admin_rafa' everywhere in AuthContext.tsx
// wait, we can just replace 'usr_admin_nerik' and 'nerik' with 'usr_admin_rafa' and 'rafa' in AuthContext.tsx
content = content.replace(/usr_admin_nerik/g, 'usr_admin_rafa');
content = content.replace(/u\.username\?\.toLowerCase\(\) !== 'nerik'/g, "u.username?.toLowerCase() !== 'rafa'");
content = content.replace(/u\.username === 'nerik'/g, "u.username === 'rafa'");

fs.writeFileSync('src/context/AuthContext.tsx', content);

