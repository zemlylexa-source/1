const fs = require('fs');

function replaceFile(file, regex, replace) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(regex, replace);
  fs.writeFileSync(file, content, 'utf8');
}

// CallsView
replaceFile('src/components/CallsView.tsx', /setActiveChatId\(chatId\);/g, '');

// ContactsView
replaceFile('src/components/ContactsView.tsx', /setActiveChatId\(chatId\);/g, '');
replaceFile('src/components/ContactsView.tsx', /const handleCallUser = \(contact: any\) => \{/g, 'const handleCallUser = async (contact: any) => {');
replaceFile('src/components/ContactsView.tsx', /onClick=\{\(\) => \{/g, 'onClick={async () => {');

// UserProfileModal
replaceFile('src/components/UserProfileModal.tsx', /setActiveChatId\(chatId\);/g, '');

// ChatArea
replaceFile('src/components/ChatArea.tsx', /await getOrCreateDirectChat\(u\);/g, 'await getOrCreateDirectChat(contact);');

