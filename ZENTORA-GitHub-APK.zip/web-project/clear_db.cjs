const admin = require('firebase-admin');
const fs = require('fs');

const config = JSON.parse(fs.readFileSync('firebase-applet-config.json', 'utf8'));

admin.initializeApp({
  projectId: config.projectId
});

const db = admin.firestore();
db.settings({
    databaseId: config.firestoreDatabaseId
});

async function clearCollection(collectionPath) {
  const collectionRef = db.collection(collectionPath);
  const snapshot = await collectionRef.get();
  
  const batch = db.batch();
  snapshot.docs.forEach((doc) => {
    batch.delete(doc.ref);
  });
  
  await batch.commit();
  console.log(`Cleared collection: ${collectionPath}`);
}

async function run() {
  await clearCollection('users');
  await clearCollection('chats');
  await clearCollection('calls');
  await clearCollection('reports');
  console.log('Done');
}

run().catch(console.error);
