const fs = require('fs');

const file = 'src/components/AdminPanelModal.tsx';
let content = fs.readFileSync(file, 'utf8');

const replacement = `      snapshot.forEach(docSnap => {
        const data = docSnap.data() as Partial<User>;
        delete data.twoFASecret;
        delete (data as any)._pwdHash;
        const u: User = {`;

content = content.replace(/      snapshot\.forEach\(docSnap => \{\n        const data = docSnap\.data\(\) as Partial<User>;\n        const u: User = \{/, replacement);

fs.writeFileSync(file, content);
