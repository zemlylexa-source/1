const fs = require('fs');
let code = fs.readFileSync('src/components/SettingsModal.tsx', 'utf8');

// I will just replace the file with a much better looking React component via sed or node.
