// Just to be extremely certain the admin block button renders properly
const fs = require('fs');
let adminPanel = fs.readFileSync('src/components/AdminPanelModal.tsx', 'utf8');

if (!adminPanel.includes("setTargetUserToDelete(u)")) {
  console.log("Block button not found!");
} else {
  console.log("Block button is present.");
}
