const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// Replace the usersStore map
code = code.replace(/const usersStore: Map<string, StoredUser> = new Map\(\[[\s\S]*?\]\);/, `const usersStore: Map<string, StoredUser> = new Map([
  [
    'usr_admin_nerik',
    {
      id: 'usr_admin_nerik',
      name: 'Nerik',
      username: 'nerik',
      email: 'nerik@zentora.io',
      passwordHash: bcrypt.hashSync('admin1234', 10),
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
      bio: 'Администратор ⚡',
      phone: '',
      status: 'online',
      isAdmin: true,
      is2FAEnabled: false,
      createdAt: new Date().toISOString()
    }
  ]
]);`);

fs.writeFileSync('server.ts', code);
