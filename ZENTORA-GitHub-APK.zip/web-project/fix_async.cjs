const fs = require('fs');

function fixFile(file) {
  let content = fs.readFileSync(file, 'utf8');
  
  // Make onClick async
  content = content.replace(/onClick=\{\(\) => \{/g, 'onClick={async () => {');
  // Make onMessage async
  content = content.replace(/onMessage=\{\(\w+\) => \{/g, 'onMessage={async ($1) => {');
  
  // ContactsView specific
  content = content.replace(/const handleMessageUser = \(contact: any\) => \{/g, 'const handleMessageUser = async (contact: any) => {');
  content = content.replace(/const handleCallUser = \(contact: any\) => \{/g, 'const handleCallUser = async (contact: any) => {');

  // Any remaining setActiveChatId(chatId)
  content = content.replace(/setActiveChatId\(chatId\);?/g, '');

  fs.writeFileSync(file, content, 'utf8');
}

['src/components/Sidebar.tsx', 'src/components/CallsView.tsx', 'src/components/UserProfileModal.tsx', 'src/components/ContactsView.tsx', 'src/components/ChatArea.tsx'].forEach(fixFile);
