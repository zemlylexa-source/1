const fs = require('fs');
let adminPanel = fs.readFileSync('src/components/AdminPanelModal.tsx', 'utf8');

// Fix accidental 'den' replacements
adminPanel = adminPanel.replace(/главного администратора den/g, 'главного администратора Den');
adminPanel = adminPanel.replace(/Только den может/g, 'Только Den может');

fs.writeFileSync('src/components/AdminPanelModal.tsx', adminPanel);
