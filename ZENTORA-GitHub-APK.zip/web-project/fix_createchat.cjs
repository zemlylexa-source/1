const fs = require('fs');
let code = fs.readFileSync('src/components/CreateChatModal.tsx', 'utf8');
code = code.replace("import { MOCK_USERS } from '../lib/initialData';", "");
code = code.replace("const { user } = useAuth();", "const { user, registeredUsers } = useAuth();");
code = code.replace("const availableUsers = MOCK_USERS.filter", "const availableUsers = registeredUsers.filter");
fs.writeFileSync('src/components/CreateChatModal.tsx', code);
