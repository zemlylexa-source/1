const fs = require('fs');

const file = 'src/components/Sidebar.tsx';
let content = fs.readFileSync(file, 'utf8');

const regexUseEffect = /  useEffect\(\(\) => \{\n    const clean = qClean\.trim\(\);\n    if \(clean\.length >= 2\) \{\n      const handler = setTimeout\(async \(\) => \{\n        try \{\n          const userDocQuery = firestoreQuery\(collection\(db, 'users'\), where\('username', '==', clean\)\);\n          const snapshot = await getDocs\(userDocQuery\);\n          if \(\!snapshot\.empty\) \{\n            setSearchedUser\(snapshot\.docs\[0\]\.data\(\)\);\n            setSearchNotFound\(false\);\n          \} else \{\n            setSearchedUser\(null\);\n            setSearchNotFound\(false\);\n          \}\n        \} catch \(e\) \{\n          console\.error\("Search error:", e\);\n          setSearchedUser\(null\);\n          setSearchNotFound\(false\);\n        \}\n      \}, 300\);\n      return \(\) => clearTimeout\(handler\);\n    \} else \{\n      setSearchedUser\(null\);\n      setSearchNotFound\(false\);\n    \}\n  \}, \[qClean\]\);\n/g;

content = content.replace(regexUseEffect, '');

const regexUsage = /    if \(searchedUser && searchedUser\.id \!== user\?\.id\) \{\n      globalUserMap\.set\(searchedUser\.id, searchedUser\);\n    \}\n/g;
content = content.replace(regexUsage, '');

fs.writeFileSync(file, content);
