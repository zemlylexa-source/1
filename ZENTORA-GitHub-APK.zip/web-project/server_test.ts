import express from "express";
import { createServer } from "http";
import path from "path";
import { WebSocketServer, WebSocket } from "ws";
import bcrypt from "bcryptjs";

const rootDir = process.cwd();

interface StoredUser {
  id: string;
  name: string;
  username: string;
  email: string;
  passwordHash: string;
  avatar?: string;
  bio?: string;
  phone?: string;
  status: "online" | "offline" | "away";
  isAdmin: boolean;
  isBlocked?: boolean;
  is2FAEnabled: boolean;
  twoFASecret?: string;
  createdAt: string;
}

interface StoredSession {
  id: string;
  userId: string;
  device: string;
  browser: string;
  os: string;
  ip: string;
  location: string;
  lastActive: string;
  createdAt: string;
}

interface StoredReport {
  id: string;
  reporterId: string;
  reporterName: string;
  targetId: string;
  targetType: "user" | "message" | "group" | "channel";
  reason: string;
  details?: string;
  createdAt: string;
  status: "pending" | "reviewed" | "dismissed";
}

// ======================================================
// CONFIG
// ======================================================

const PORT = 3005;

// ======================================================
// IN-MEMORY DATABASE
// ======================================================

const usersStore = new Map<string, StoredUser>();

const sessionsStore = new Map<string, StoredSession>();

const reportsStore: StoredReport[] = [];

// ======================================================
// DEFAULT ADMIN
// ======================================================

const adminUser: StoredUser = {
  id: "usr_admin_nerik",

  name: "Nerik",

  username: "nerik",

  email: "nerik@zentora.io",

  passwordHash: bcrypt.hashSync("admin1234", 10),

  avatar:
    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80",

  bio: "Администратор ⚡",

  phone: "",

  status: "online",

  isAdmin: true,

  isBlocked: false,

  is2FAEnabled: false,

  createdAt: new Date().toISOString(),
};

usersStore.set(adminUser.id, adminUser);

// ======================================================
// RATE LIMIT
// ======================================================

const rateLimitMap = new Map<
  string,
  {
    count: number;
    firstAttempt: number;
  }
>();

function checkRateLimit(
  ip: string,
  maxAttempts = 10,
  windowMs = 60000
): boolean {
  const now = Date.now();

  const record = rateLimitMap.get(ip);

  if (!record) {
    rateLimitMap.set(ip, {
      count: 1,
      firstAttempt: now,
    });

    return true;
  }

  if (now - record.firstAttempt > windowMs) {
    rateLimitMap.set(ip, {
      count: 1,
      firstAttempt: now,
    });

    return true;
  }

  if (record.count >= maxAttempts) {
    return false;
  }

  record.count++;

  return true;
}

// ======================================================
// SERVER
// ======================================================

async function startServer() {
  const app = express();

  // Cloud Run requires 0.0.0.0
  const host = "0.0.0.0";

  // ====================================================
  // EXPRESS CONFIG
  // ====================================================

  app.set("trust proxy", 1);

  app.use(
    express.json({
      limit: "25mb",
    })
  );

  app.use(
    express.urlencoded({
      extended: true,
      limit: "25mb",
    })
  );

  // ====================================================
  // SECURITY HEADERS
  // ====================================================

  app.use((req, res, next) => {
    res.setHeader(
      "X-Content-Type-Options",
      "nosniff"
    );

    res.setHeader(
      "X-Frame-Options",
      "SAMEORIGIN"
    );

    res.setHeader(
      "Referrer-Policy",
      "strict-origin-when-cross-origin"
    );

    next();
  });

  // ====================================================
  // BASIC TEST
  // ====================================================

  app.get("/api", (req, res) => {
    res.json({
      status: "ok",
      service: "Zentora Messenger",
      message: "API is working",
    });
  });

  // ====================================================
  // HEALTH CHECK
  // ====================================================

  app.get("/api/health", (req, res) => {
    res.status(200).json({
      status: "ok",

      service: "Zentora Messenger Engine",

      websocket: "enabled",

      webrtcSignaling: "active",

      port: PORT,

      uptime: process.uptime(),

      timestamp: new Date().toISOString(),
    });
  });

  // ====================================================
  // REGISTER
  // ====================================================

  app.post(
    "/api/auth/register",
    (req, res) => {
      try {
        const clientIp =
          req.ip || "127.0.0.1";

        if (
          !checkRateLimit(
            clientIp,
            10,
            60000
          )
        ) {
          return res.status(429).json({
            error:
              "Too many attempts. Please try again in 1 minute.",
          });
        }

        const {
          name,
          username,
          email,
          password,
        } = req.body;

        if (
          !name ||
          !username ||
          !email ||
          !password
        ) {
          return res.status(400).json({
            error:
              "All fields are required.",
          });
        }

        if (
          String(password).length < 8
        ) {
          return res.status(400).json({
            error:
              "Password must be at least 8 characters long.",
          });
        }

        const cleanUsername =
          String(username)
            .toLowerCase()
            .trim()
            .replace(
              /[^a-z0-9_]/g,
              ""
            );

        const cleanEmail =
          String(email)
            .toLowerCase()
            .trim();

        if (!cleanUsername) {
          return res.status(400).json({
            error:
              "Invalid username.",
          });
        }

        for (const user of usersStore.values()) {
          if (
            user.username ===
            cleanUsername
          ) {
            return res.status(409).json({
              error:
                "Username is already taken.",
            });
          }

          if (
            user.email ===
            cleanEmail
          ) {
            return res.status(409).json({
              error:
                "Email is already registered.",
            });
          }
        }

        const newUser: StoredUser = {
          id:
            `usr_${Date.now()}_` +
            Math.random()
              .toString(36)
              .substring(2, 8),

          name: String(name).trim(),

          username: cleanUsername,

          email: cleanEmail,

          passwordHash:
            bcrypt.hashSync(
              String(password),
              10
            ),

          avatar:
            `https://api.dicebear.com/7.x/identicon/svg?seed=${encodeURIComponent(
              cleanUsername
            )}`,

          bio:
            "Hey there! I am using Zentora Messenger.",

          phone: "",

          status: "online",

          isAdmin: false,

          isBlocked: false,

          is2FAEnabled: false,

          createdAt:
            new Date().toISOString(),
        };

        usersStore.set(
          newUser.id,
          newUser
        );

        const session: StoredSession = {
          id:
            `sess_${Date.now()}_` +
            Math.random()
              .toString(36)
              .substring(2, 8),

          userId: newUser.id,

          device: "Web Client",

          browser:
            typeof req.headers[
              "user-agent"
            ] === "string"
              ? req.headers[
                  "user-agent"
                ]
              : "Browser",

          os: "Unknown OS",

          ip: clientIp,

          location: "Online",

          lastActive:
            new Date().toISOString(),

          createdAt:
            new Date().toISOString(),
        };

        sessionsStore.set(
          session.id,
          session
        );

        const {
          passwordHash,
          ...safeUser
        } = newUser;

        return res.status(201).json({
          user: safeUser,

          sessionId: session.id,
        });
      } catch (error) {
        console.error(
          "REGISTER ERROR:",
          error
        );

        return res.status(500).json({
          error:
            "Registration failed.",
        });
      }
    }
  );

  // ====================================================
  // LOGIN
  // ====================================================

  app.post(
    "/api/auth/login",
    (req, res) => {
      try {
        const clientIp =
          req.ip || "127.0.0.1";

        if (
          !checkRateLimit(
            clientIp,
            10,
            60000
          )
        ) {
          return res.status(429).json({
            error:
              "Too many login attempts. Please wait 1 minute.",
          });
        }

        const {
          login,
          password,
        } = req.body;

        if (!login || !password) {
          return res.status(400).json({
            error:
              "Email/Username and Password are required.",
          });
        }

        const cleanLogin =
          String(login)
            .toLowerCase()
            .trim();

        let targetUser:
          | StoredUser
          | null = null;

        for (const user of usersStore.values()) {
          if (
            user.email ===
              cleanLogin ||
            user.username ===
              cleanLogin
          ) {
            targetUser = user;
            break;
          }
        }

        if (!targetUser) {
          return res.status(401).json({
            error:
              "Invalid credentials.",
          });
        }

        if (
          targetUser.isBlocked
        ) {
          return res.status(403).json({
            error:
              "Account has been suspended by an administrator.",
          });
        }

        const validPassword =
          bcrypt.compareSync(
            String(password),
            targetUser.passwordHash
          );

        if (!validPassword) {
          return res.status(401).json({
            error:
              "Invalid credentials.",
          });
        }

        targetUser.status = "online";

        const session: StoredSession = {
          id:
            `sess_${Date.now()}_` +
            Math.random()
              .toString(36)
              .substring(2, 8),

          userId: targetUser.id,

          device: "Web Desktop",

          browser:
            typeof req.headers[
              "user-agent"
            ] === "string"
              ? req.headers[
                  "user-agent"
                ]
              : "Browser",

          os: "Web Platform",

          ip: clientIp,

          location: "Online",

          lastActive:
            new Date().toISOString(),

          createdAt:
            new Date().toISOString(),
        };

        sessionsStore.set(
          session.id,
          session
        );

        const {
          passwordHash,
          ...safeUser
        } = targetUser;

        return res.json({
          user: safeUser,

          sessionId: session.id,
        });
      } catch (error) {
        console.error(
          "LOGIN ERROR:",
          error
        );

        return res.status(500).json({
          error:
            "Login failed.",
        });
      }
    }
  );

  // ====================================================
  // UPLOAD
  // ====================================================

  app.post(
    "/api/upload",
    (req, res) => {
      try {
        const {
          name,
          mimeType,
          dataUrl,
        } = req.body;

        if (
          !name ||
          !mimeType ||
          !dataUrl
        ) {
          return res.status(400).json({
            error:
              "File payload missing required fields.",
          });
        }

        const sizeInBytes =
          Math.round(
            (String(dataUrl).length *
              3) /
              4
          );

        if (
          sizeInBytes >
          25 * 1024 * 1024
        ) {
          return res.status(413).json({
            error:
              "File size exceeds 25MB limit.",
          });
        }

        let fileType:
          | "image"
          | "video"
          | "audio"
          | "voice"
          | "document" =
          "document";

        if (
          String(mimeType).startsWith(
            "image/"
          )
        ) {
          fileType = "image";
        } else if (
          String(mimeType).startsWith(
            "video/"
          )
        ) {
          fileType = "video";
        } else if (
          String(mimeType).includes(
            "audio/webm"
          ) ||
          String(mimeType).includes(
            "audio/ogg"
          ) ||
          String(name).includes(
            "voice"
          )
        ) {
          fileType = "voice";
        } else if (
          String(mimeType).startsWith(
            "audio/"
          )
        ) {
          fileType = "audio";
        }

        return res.json({
          attachment: {
            id:
              `att_${Date.now()}_` +
              Math.random()
                .toString(36)
                .substring(2, 8),

            name,

            size: sizeInBytes,

            mimeType,

            url: dataUrl,

            type: fileType,
          },
        });
      } catch (error) {
        console.error(
          "UPLOAD ERROR:",
          error
        );

        return res.status(500).json({
          error:
            "Upload failed.",
        });
      }
    }
  );

  // ====================================================
  // SESSIONS
  // ====================================================

  app.get(
    "/api/sessions",
    (req, res) => {
      return res.json(
        Array.from(
          sessionsStore.values()
        )
      );
    }
  );

  app.delete(
    "/api/sessions/:sessionId",
    (req, res) => {
      const {
        sessionId,
      } = req.params;

      sessionsStore.delete(
        sessionId
      );

      return res.json({
        success: true,

        message:
          "Session terminated.",
      });
    }
  );

  app.delete(
    "/api/sessions/other/all",
    (req, res) => {
      const currentId =
        typeof req.headers[
          "x-session-id"
        ] === "string"
          ? req.headers[
              "x-session-id"
            ]
          : "";

      for (
        const [id] of sessionsStore
      ) {
        if (id !== currentId) {
          sessionsStore.delete(id);
        }
      }

      return res.json({
        success: true,

        message:
          "All other sessions terminated.",
      });
    }
  );

  // ====================================================
  // ADMIN STATS
  // ====================================================

  app.get(
    "/api/admin/stats",
    (req, res) => {
      return res.json({
        totalUsers:
          usersStore.size,

        onlineUsers:
          Array.from(
            usersStore.values()
          ).filter(
            (user) =>
              user.status ===
              "online"
          ).length,

        activeSessions:
          sessionsStore.size,

        reportsCount:
          reportsStore.length,

        systemUptime:
          process.uptime(),
      });
    }
  );

  // ====================================================
  // ADMIN USERS
  // ====================================================

  app.get(
    "/api/admin/users",
    (req, res) => {
      const list =
        Array.from(
          usersStore.values()
        ).map(
          ({
            passwordHash,
            ...user
          }) => user
        );

      return res.json(list);
    }
  );

  // ====================================================
  // ADMIN BLOCK
  // ====================================================

  app.post(
    "/api/admin/block",
    (req, res) => {
      const {
        userId,
        blocked,
      } = req.body;

      const user =
        usersStore.get(userId);

      if (!user) {
        return res.status(404).json({
          error:
            "User not found.",
        });
      }

      user.isBlocked =
        Boolean(blocked);

      if (user.isBlocked) {
        user.status = "offline";
      }

      return res.json({
        success: true,

        user,
      });
    }
  );

  // ====================================================
  // REPORTS
  // ====================================================

  app.post(
    "/api/reports",
    (req, res) => {
      const {
        targetId,
        targetType,
        reason,
        details,
      } = req.body;

      if (
        !targetId ||
        !targetType
      ) {
        return res.status(400).json({
          error:
            "Target information is required.",
        });
      }

      const report: StoredReport = {
        id: `rep_${Date.now()}`,

        reporterId: "usr_me",

        reporterName:
          "Alexander Zent",

        targetId,

        targetType,

        reason:
          reason ||
          "Inappropriate content",

        details:
          details || "",

        createdAt:
          new Date().toISOString(),

        status: "pending",
      };

      reportsStore.push(
        report
      );

      return res.json({
        success: true,

        report,
      });
    }
  );

  app.get(
    "/api/reports",
    (req, res) => {
      return res.json(
        reportsStore
      );
    }
  );

  // ====================================================
  // STATIC FRONTEND
  // ====================================================

  const distPath = path.resolve(process.cwd(), "dist");

  app.use(
    express.static(distPath)
  );

  // SPA fallback
  app.use(
    (req, res, next) => {
      if (
        req.path.startsWith(
          "/api/"
        )
      ) {
        return next();
      }

      const indexPath =
        path.join(
          distPath,
          "index.html"
        );

      res.sendFile(
        indexPath,
        (error) => {
          if (error) {
            console.error(
              "FRONTEND ERROR:",
              error
            );

            if (!res.headersSent) {
              res.status(404).json({
                error:
                  "Frontend build not found.",
              });
            }
          }
        }
      );
    }
  );

  // ====================================================
  // HTTP SERVER
  // ====================================================

  const server =
    createServer(app);

  // ====================================================
  // WEBSOCKET SERVER
  // ====================================================

  const wss =
    new WebSocketServer({
      server,
    });

  const clients =
    new Map<
      string,
      WebSocket
    >();

  wss.on(
    "connection",
    (ws) => {
      let currentUserId:
        | string
        | null = null;

      ws.on(
        "message",
        (messageRaw) => {
          try {
            const data =
              JSON.parse(
                messageRaw.toString()
              );

            const {
              type,
              payload,
            } = data;

            // ------------------------------------------
            // AUTH
            // ------------------------------------------

            if (
              type === "auth"
            ) {
              currentUserId =
                payload?.userId ||
                null;

              if (
                currentUserId
              ) {
                clients.set(
                  currentUserId,
                  ws
                );

                const onlineEvent =
                  JSON.stringify({
                    type:
                      "user:online",

                    payload: {
                      userId:
                        currentUserId,
                    },
                  });

                clients.forEach(
                  (
                    client,
                    id
                  ) => {
                    if (
                      id !==
                        currentUserId &&
                      client.readyState ===
                        WebSocket.OPEN
                    ) {
                      client.send(
                        onlineEvent
                      );
                    }
                  }
                );
              }

              return;
            }

            // ------------------------------------------
            // TYPING
            // ------------------------------------------

            if (
              type ===
                "typing:start" ||
              type ===
                "typing:stop"
            ) {
              const event =
                JSON.stringify({
                  type,

                  payload,
                });

              clients.forEach(
                (
                  client,
                  id
                ) => {
                  if (
                    id !==
                      currentUserId &&
                    client.readyState ===
                      WebSocket.OPEN
                  ) {
                    client.send(
                      event
                    );
                  }
                }
              );

              return;
            }

            // ------------------------------------------
            // MESSAGES
            // ------------------------------------------

            if (
              type ===
                "message:new" ||
              type ===
                "message:update" ||
              type ===
                "message:delete"
            ) {
              const event =
                JSON.stringify({
                  type,

                  payload,
                });

              clients.forEach(
                (
                  client,
                  id
                ) => {
                  if (
                    id !==
                      currentUserId &&
                    client.readyState ===
                      WebSocket.OPEN
                  ) {
                    client.send(
                      event
                    );
                  }
                }
              );

              return;
            }

            // ------------------------------------------
            // CALL / WEBRTC
            // ------------------------------------------

            if (
              typeof type ===
                "string" &&
              type.startsWith(
                "call:"
              )
            ) {
              const targetId =
                payload?.receiverId ||
                payload?.targetUserId ||
                payload?.callerId;

              const targetWs =
                targetId
                  ? clients.get(
                      targetId
                    )
                  : undefined;

              if (
                targetWs &&
                targetWs.readyState ===
                  WebSocket.OPEN
              ) {
                targetWs.send(
                  JSON.stringify({
                    type,

                    payload,
                  })
                );
              } else {
                const event =
                  JSON.stringify({
                    type,

                    payload,
                  });

                clients.forEach(
                  (
                    client,
                    id
                  ) => {
                    if (
                      id !==
                        currentUserId &&
                      client.readyState ===
                        WebSocket.OPEN
                    ) {
                      client.send(
                        event
                      );
                    }
                  }
                );
              }

              return;
            }
          } catch (error) {
            console.error(
              "WEBSOCKET MESSAGE ERROR:",
              error
            );
          }
        }
      );

      // ----------------------------------------------
      // CLOSE
      // ----------------------------------------------

      ws.on(
        "close",
        () => {
          if (
            currentUserId
          ) {
            clients.delete(
              currentUserId
            );

            const offlineEvent =
              JSON.stringify({
                type:
                  "user:offline",

                payload: {
                  userId:
                    currentUserId,
                },
              });

            clients.forEach(
              (
                client,
                id
              ) => {
                if (
                  id !==
                    currentUserId &&
                  client.readyState ===
                    WebSocket.OPEN
                ) {
                  client.send(
                    offlineEvent
                  );
                }
              }
            );
          }
        }
      );

      ws.on(
        "error",
        (error) => {
          console.error(
            "WEBSOCKET ERROR:",
            error
          );
        }
      );
    }
  );

  // ====================================================
  // SERVER ERROR
  // ====================================================

  server.on(
    "error",
    (error) => {
      console.error(
        "SERVER ERROR:",
        error
      );

      process.exit(1);
    }
  );

  // ====================================================
  // START
  // ====================================================

  server.listen(
    PORT,
    host,
    () => {
      console.log(
        "======================================"
      );

      console.log(
        "ZENTORA MESSENGER SERVER"
      );

      console.log(
        "======================================"
      );

      console.log(
        `Server listening on ${host}:${PORT}`
      );

      console.log(
        `Cloud Run PORT: ${PORT}`
      );

      console.log(
        `Root directory: ${rootDir}`
      );

      console.log(
        `Frontend directory: ${distPath}`
      );

      console.log(
        "WebSocket: ENABLED"
      );

      console.log(
        "Health: /api/health"
      );

      console.log(
        "======================================"
      );
    }
  );
}

// ======================================================
// START APPLICATION
// ======================================================

startServer().catch(
  (error) => {
    console.error(
      "======================================"
    );

    console.error(
      "FATAL SERVER STARTUP ERROR"
    );

    console.error(
      "======================================"
    );

    console.error(error);

    process.exit(1);
  }
);