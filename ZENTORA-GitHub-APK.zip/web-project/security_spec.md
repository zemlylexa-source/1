# Security Specification for Zentora

## Data Invariants
1. A user can only edit their own profile (except for admin/moderator fields).
2. Only participants of a chat can read or write messages in that chat.
3. A user can only see chats they are a member of.
4. Signals for a call can only be read/written by the caller or receiver.
5. Administrative fields (isAdmin, isModerator, isBlocked) can only be changed by admins (or Nerik specifically).

## The Dirty Dozen Payloads (Targeting PERMISSION_DENIED)
1. **Identity Theft**: User A tries to update User B's profile.
2. **Privilege Escalation**: User A tries to set `isAdmin: true` on their own profile.
3. **Eavesdropping**: User A tries to read messages from a chat they are not a member of.
4. **Unauthorized Injection**: User A tries to send a message into a chat they are not a member of.
5. **Call Hijacking**: User A tries to send signaling data for a call between User B and User C.
6. **Report Tampering**: User A tries to delete a report filed against them.
7. **System Spoofing**: User A tries to send a message with `type: "system"` to impersonate the system.
8. **Status Faking**: User A tries to set User B's status to "offline".
9. **Chat Creation Fraud**: User A tries to create a group chat where they are not the owner.
10. **Signal Poisoning**: User A tries to send an "answer" signal to a call they didn't start or receive.
11. **History Deletion**: User A tries to delete the entire `chats` collection.
12. **Metadata Manipulation**: User A tries to change the `createdAt` timestamp of a message.

## Test Runner (Logic Verification)
The `firestore.rules.test.ts` will verify these cases.
