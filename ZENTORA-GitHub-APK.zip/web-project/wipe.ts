import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';

try {
  initializeApp({ projectId: 'linen-cubist-118qq' });
} catch (e) {}

async function wipe() {
  try {
    const auth = getAuth();
    const db = getFirestore();
    
    // Auth wipe
    console.log("Fetching users...");
    const users = await auth.listUsers(1000);
    for (const u of users.users) {
      await auth.deleteUser(u.uid);
      console.log("Deleted auth user", u.email);
    }

    // Firestore wipe
    const snapshot = await db.collection('users').get();
    const batch = db.batch();
    snapshot.docs.forEach((doc) => {
      batch.delete(doc.ref);
    });
    await batch.commit();
    console.log("Deleted all users from Firestore");

  } catch(e) {
    console.error("Error wiping:", e.message);
  }
}
wipe();
