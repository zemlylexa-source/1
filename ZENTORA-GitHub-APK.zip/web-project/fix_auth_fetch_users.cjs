const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

// Replace the registeredUsers initialization and effect
code = code.replace(/const \[registeredUsers, setRegisteredUsers\] = useState<User\[\]>\(\(\) => \{[\s\S]*?\}\);[\s\S]*?useEffect\(\(\) => \{[\s\S]*?localStorage\.setItem\('zentora_all_users'[\s\S]*?\}\, \[registeredUsers\]\);/,
`const [registeredUsers, setRegisteredUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('zentora_all_users');
    let users = saved ? JSON.parse(saved) : [];
    if (users.some(u => u.id === 'usr_me' || u.id === 'usr_elena')) {
       users = [];
       localStorage.removeItem('zentora_user');
       localStorage.removeItem('zentora_all_users');
    }
    if (CURRENT_USER && !users.some(u => u.id === CURRENT_USER.id)) {
       users.push(CURRENT_USER);
    }
    return users;
  });

  useEffect(() => {
    localStorage.setItem('zentora_all_users', JSON.stringify(registeredUsers));
  }, [registeredUsers]);

  // Fetch real users from backend
  useEffect(() => {
    fetch('/api/admin/users')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setRegisteredUsers(data);
        }
      })
      .catch(() => {});
  }, []);`
);

fs.writeFileSync('src/context/AuthContext.tsx', code);
