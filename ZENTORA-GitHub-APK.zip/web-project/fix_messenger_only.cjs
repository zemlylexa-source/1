const fs = require('fs');

// We need to revert App.tsx back to just the Messenger interface.
let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// The original Messenger layout we had before adding the Social features
const originalAppContent = `        {/* App Content Area */}
        <div className="flex flex-1 overflow-hidden relative w-full h-full">
          
          {/* Sidebar / Chat List */}
          <div className={\`\${activeChatId && isPhoneView ? 'hidden' : 'flex'} w-full \${!isPhoneView ? 'md:w-80 lg:w-96' : ''} shrink-0 h-full\`}>
            <Sidebar
              onOpenCreateChat={() => setShowCreateChatModal(true)}
              onOpenSettings={() => setShowSettingsModal(true)}
              onOpenAdmin={() => setShowAdminModal(true)}
              activeSection={activeSection}
              setActiveSection={setActiveSection}
            />
          </div>

          {/* Center Main Chat Area */}
          <div className={\`\${activeChatId || !isPhoneView ? 'flex' : 'hidden'} flex-1 h-full overflow-hidden relative\`}>
            {activeSection === 'chats' && (
              <ChatArea
                onToggleInfoPanel={() => setShowInfoPanel(!showInfoPanel)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenReport={() => setShowReportModal(true)}
              />
            )}
            {activeSection === 'contacts' && <ContactsView onChatStart={() => setActiveSection('chats')} />}
            {activeSection === 'calls' && <CallsView />}

            {/* Right Info Panel */}
            {showInfoPanel && activeSection === 'chats' && (
              <InfoPanel
                onClose={() => setShowInfoPanel(false)}
                onOpenReport={() => setShowReportModal(true)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenSearch={() => setIsSearchOpen(true)}
              />
            )}
          </div>
        </div>

        {/* Floating Mobile Dock Navigation Bar */}
        {isPhoneView && !activeChatId && (
          <div className="p-2 pb-3 bg-slate-950/90 backdrop-blur-2xl border-t border-white/10 shrink-0 z-40 select-none">
            <div className="w-full max-w-sm mx-auto bg-slate-900/90 border border-white/10 rounded-full p-1 flex items-center justify-around gap-1 shadow-2xl">
              <button
                onClick={() => setActiveSection('chats')}
                className={\`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all \${
                  activeSection === 'chats'
                    ? 'bg-purple-600/30 text-purple-200 font-bold border border-purple-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }\`}
              >
                <MessageSquare className="w-4 h-4 text-purple-400" />
                <span>Чаты</span>
              </button>
              <button
                onClick={() => setActiveSection('calls')}
                className={\`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all \${
                  activeSection === 'calls'
                    ? 'bg-emerald-600/30 text-emerald-200 font-bold border border-emerald-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }\`}
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Звонки</span>
              </button>
              <button
                onClick={() => setActiveSection('contacts')}
                className={\`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all \${
                  activeSection === 'contacts'
                    ? 'bg-blue-600/30 text-blue-200 font-bold border border-blue-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }\`}
              >
                <Contact className="w-4 h-4 text-blue-400" />
                <span>Контакты</span>
              </button>
            </div>
          </div>
        )}`;

// Clean up imports and states
appTsx = appTsx.replace("import { MessageSquare, Contact, Phone, Settings, Home, Search, Bell, User as UserIcon } from 'lucide-react';", "import { MessageSquare, Contact, Phone, Settings } from 'lucide-react';");
appTsx = appTsx.replace("import { SocialSidebar } from './components/social/SocialSidebar';\nimport { FeedView } from './components/social/FeedView';\nimport { ProfileView } from './components/social/ProfileView';\nimport { NotificationsView } from './components/social/NotificationsView';\nimport { SearchView } from './components/social/SearchView';\nimport { ZentoraPremiumModal } from './components/social/ZentoraPremiumModal';\n", "");

// Replace the entire App Content Area structure back to the original
appTsx = appTsx.replace(/{\/\* App Content Area \*\/}[\s\S]*?(?={\/\* Overlay Modals \*\/})/g, originalAppContent + "\n      ");

fs.writeFileSync('src/App.tsx', appTsx);
