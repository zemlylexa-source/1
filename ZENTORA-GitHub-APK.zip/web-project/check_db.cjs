const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');
const fs = require('fs');

const config = JSON.parse(fs.readFileSync('firebase-applet-config.json', 'utf8'));

admin.initializeApp({
  projectId: config.projectId
});

const db = getFirestore();
db.settings({ databaseId: config.firestoreDatabaseId });

async function run() {
  const usersRef = db.collection('users');
  const snapshot = await usersRef.get();
  console.log('Total users in DB:', snapshot.size);
  snapshot.forEach(doc => {
      console.log('-', doc.id, doc.data().username, doc.data().email);
  });
}

run().catch(console.error);
