const fs = require('fs');
let content = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');

// Find the onSnapshot for messages and add read-status update
const target = `setMessages(msgs);
      setLoadingMessages(false);
    });`;

const replacement = `setMessages(msgs);
      setLoadingMessages(false);

      // Mark unread messages as read if they are from others
      if (user) {
        msgs.forEach(msg => {
          if (msg.senderId !== user.id && msg.status !== 'read') {
            import('firebase/firestore').then(({ doc, updateDoc }) => {
              updateDoc(doc(db, 'chats', activeChatId, 'messages', msg.id), { status: 'read' }).catch(console.error);
            });
          }
        });
      }
    });`;

if (!content.includes('import(')) {
  content = content.replace(target, replacement);
  fs.writeFileSync('src/context/ChatContext.tsx', content, 'utf8');
}
