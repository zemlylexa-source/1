const fs = require('fs');
let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// Fix global dock text colors
appTsx = appTsx.replace(/text-\[var\(--text-primary\)\]/g, "text-gray-900 dark:text-white");
appTsx = appTsx.replace(/text-\[var\(--text-secondary\)\]/g, "text-gray-600 dark:text-gray-400");
fs.writeFileSync('src/App.tsx', appTsx);
