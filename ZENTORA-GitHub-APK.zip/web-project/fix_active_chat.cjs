const fs = require('fs');
let code = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');

code = code.replace(/const \[activeChatId, setActiveChatId\] = useState<string \| null>\('chat_elena'\);/,
  "const [activeChatId, setActiveChatId] = useState<string | null>(null);");

fs.writeFileSync('src/context/ChatContext.tsx', code);
