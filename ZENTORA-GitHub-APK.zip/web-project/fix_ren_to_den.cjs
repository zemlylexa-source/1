const fs = require('fs');

let chatArea = fs.readFileSync('src/components/ChatArea.tsx', 'utf8');
chatArea = chatArea.replace(/activeChat\.username\?\.toLowerCase\(\) === 'ren'/g, "activeChat.username?.toLowerCase() === 'den'");
fs.writeFileSync('src/components/ChatArea.tsx', chatArea);

let infoPanel = fs.readFileSync('src/components/InfoPanel.tsx', 'utf8');
infoPanel = infoPanel.replace(/activeChat\.username\?\.toLowerCase\(\) === 'ren'/g, "activeChat.username?.toLowerCase() === 'den'");
fs.writeFileSync('src/components/InfoPanel.tsx', infoPanel);
