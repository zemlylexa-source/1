const fs = require('fs');

let chatAreaTsx = fs.readFileSync('src/components/ChatArea.tsx', 'utf8');

const audioCallMatch = `                  const targetId = otherMember?.userId || activeChat.memberIds?.find(id => id !== user?.id);
                  if (targetId) {
                    startCall(`;

const audioCallReplace = `                  const targetId = otherMember?.userId || activeChat.memberIds?.find(id => id !== user?.id);
                  if (!targetId) {
                    alert('Нельзя позвонить самому себе (в Избранном) или в пустом чате.');
                    return;
                  }
                  if (targetId) {
                    startCall(`;

chatAreaTsx = chatAreaTsx.replaceAll(audioCallMatch, audioCallReplace);

fs.writeFileSync('src/components/ChatArea.tsx', chatAreaTsx);
