const fs = require('fs');

let feedTsx = fs.readFileSync('src/components/social/FeedView.tsx', 'utf8');

// Replace standard useState with dynamic one
feedTsx = feedTsx.replace(
  "const [posts] = useState<Post[]>([", 
  "const [posts, setPosts] = useState<Post[]>(["
);

const submitLogic = `
  const handlePost = () => {
    if (!postText.trim()) return;
    const newPost: Post = {
      id: 'post_' + Date.now(),
      authorId: user?.id || 'me',
      authorName: user?.name || 'Я',
      authorUsername: user?.username || 'user',
      authorAvatar: user?.avatar || \`https://api.dicebear.com/7.x/identicon/svg?seed=\${user?.name}\`,
      text: postText.trim(),
      createdAt: Date.now(),
      likes: [],
      reposts: 0,
      views: 0,
      commentsCount: 0
    };
    setPosts([newPost, ...posts]);
    setPostText('');
  };
`;

feedTsx = feedTsx.replace("const [posts, setPosts] = useState<Post[]>([", submitLogic + "\n  const [posts, setPosts] = useState<Post[]>([");

// Add onClick to publish button
feedTsx = feedTsx.replace(
  "className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all ${postText.trim() ? 'bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)]' : 'bg-gray-400 dark:bg-gray-600 text-white cursor-not-allowed opacity-80'}`}",
  "onClick={handlePost}\n                  disabled={!postText.trim()}\n                  className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all ${postText.trim() ? 'bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)]' : 'bg-gray-400 dark:bg-gray-600 text-white cursor-not-allowed opacity-80'}`}"
);

fs.writeFileSync('src/components/social/FeedView.tsx', feedTsx);

let profileTsx = fs.readFileSync('src/components/social/ProfileView.tsx', 'utf8');

profileTsx = profileTsx.replace(
  "const [posts] = useState<Post[]>([", 
  "const [posts, setPosts] = useState<Post[]>(["
);

profileTsx = profileTsx.replace("const [posts, setPosts] = useState<Post[]>([", submitLogic + "\n  const [posts, setPosts] = useState<Post[]>([");

profileTsx = profileTsx.replace(
  "className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all ${postText.trim() ? 'bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)]' : 'bg-gray-400 dark:bg-gray-600 text-white cursor-not-allowed opacity-80'}`}",
  "onClick={handlePost}\n                    disabled={!postText.trim()}\n                    className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all ${postText.trim() ? 'bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)]' : 'bg-gray-400 dark:bg-gray-600 text-white cursor-not-allowed opacity-80'}`}"
);

fs.writeFileSync('src/components/social/ProfileView.tsx', profileTsx);
