const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

// Change the registeredUsers init to clear out old bots.
code = code.replace(/const \[registeredUsers, setRegisteredUsers\] = useState<User\[\]>\(\(\) => \{[\s\S]*?\}\);/, `const [registeredUsers, setRegisteredUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('zentora_all_users');
    let users = saved ? JSON.parse(saved) : [];
    
    // Nuke old bots if 'usr_me' or 'usr_elena' is present
    if (users.some(u => u.id === 'usr_me' || u.id === 'usr_elena')) {
       users = [];
       localStorage.removeItem('zentora_user'); // Log out the old user as well
       localStorage.removeItem('zentora_all_users');
    }
    
    // Ensure CURRENT_USER is always present
    if (CURRENT_USER && !users.some(u => u.id === CURRENT_USER.id)) {
       users.push(CURRENT_USER);
    }
    
    return users;
  });`);

fs.writeFileSync('src/context/AuthContext.tsx', code);
