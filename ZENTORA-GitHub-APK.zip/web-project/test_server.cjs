const { spawn } = require('child_process');
const server = spawn('node', ['dist/server_test.cjs']);
server.stdout.on('data', data => {
  const output = data.toString();
  console.log('SERVER:', output);
  const match = output.match(/Server listening on [^:]+:(\d+)/);
  if (match) {
    const port = match[1];
    const exec = require('child_process').exec;
    exec(`curl -v http://127.0.0.1:${port}/api/health`, (err, stdout, stderr) => {
      console.log('CURL OUT:', stdout);
      console.log('CURL ERR:', stderr);
      server.kill();
    });
  }
});
server.stderr.on('data', data => console.error('SERVER ERR:', data.toString()));
