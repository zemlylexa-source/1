const fs = require('fs');
let code = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');

code = code.replace(/const \[chats, setChats\] = useState<Chat\[\]>\(\(\) => \{[\s\S]*?\}\);/,
`const [chats, setChats] = useState<Chat[]>(() => {
    const saved = localStorage.getItem('zentora_chats');
    if (!saved) return INITIAL_CHATS;
    let loadedChats = JSON.parse(saved);
    if (loadedChats.some(c => c.id === 'chat_elena' || c.id === 'chat_group_design')) {
        localStorage.removeItem('zentora_chats');
        localStorage.removeItem('zentora_messages');
        return INITIAL_CHATS;
    }
    return loadedChats;
  });`);

fs.writeFileSync('src/context/ChatContext.tsx', code);
