const fs = require('fs');
let feedTsx = fs.readFileSync('src/components/social/FeedView.tsx', 'utf8');

// For custom light theme, ensure standard html classes override the css variables.
feedTsx = feedTsx.replace(/bg-\[\#F3F4F6\]/g, "bg-gray-100");
fs.writeFileSync('src/components/social/FeedView.tsx', feedTsx);

let profileTsx = fs.readFileSync('src/components/social/ProfileView.tsx', 'utf8');
profileTsx = profileTsx.replace(/bg-\[\#F3F4F6\]/g, "bg-gray-100");
fs.writeFileSync('src/components/social/ProfileView.tsx', profileTsx);

let searchTsx = fs.readFileSync('src/components/social/SearchView.tsx', 'utf8');
searchTsx = searchTsx.replace(/bg-\[\#F3F4F6\]/g, "bg-gray-100");
fs.writeFileSync('src/components/social/SearchView.tsx', searchTsx);

let notifTsx = fs.readFileSync('src/components/social/NotificationsView.tsx', 'utf8');
notifTsx = notifTsx.replace(/bg-\[\#F3F4F6\]/g, "bg-gray-100");
fs.writeFileSync('src/components/social/NotificationsView.tsx', notifTsx);

