const fs = require('fs');

let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// There's a missing closing `</div>` before `{/* Overlay Modals */}`
appTsx = appTsx.replace(
  "        )}\n      {/* Overlay Modals */}",
  "        )}\n      </div>\n      {/* Overlay Modals */}"
);

fs.writeFileSync('src/App.tsx', appTsx);
