const fs = require('fs');
let initialData = fs.readFileSync('src/lib/initialData.ts', 'utf8');
initialData = initialData.replace(/seed=ren/g, 'seed=den');
fs.writeFileSync('src/lib/initialData.ts', initialData);
