import express from "express";
import { createServer } from "http";
import path from "path";
import { WebSocketServer, WebSocket } from "ws";
import bcrypt from "bcryptjs";
import { createServer as createViteServer } from "vite";

const rootDir = process.cwd();

interface StoredUser {
  id: string;
  name: string;
  username: string;
  email: string;
  passwordHash: string;
  avatar?: string;
  bio?: string;
  phone?: string;
  status: "online" | "offline" | "away";
  isAdmin: boolean;
  isModerator?: boolean;
  isBlocked?: boolean;
  is2FAEnabled: boolean;
  twoFASecret?: string;
  createdAt: string;
}

interface StoredSession {
  id: string;
  userId: string;
  device: string;
  browser: string;
  os: string;
  ip: string;
  location: string;
  lastActive: string;
  createdAt: string;
}

interface StoredReport {
  id: string;
  reporterId: string;
  reporterName: string;
  targetId: string;
  targetType: "user" | "message" | "group" | "channel";
  reason: string;
  details?: string;
  createdAt: string;
  status: "pending" | "reviewed" | "dismissed";
}

// ======================================================
// CONFIG
// ======================================================

const PORT = 3000;

// ======================================================
// IN-MEMORY DATABASE
// ======================================================

const usersStore = new Map<string, StoredUser>();
const sessionsStore = new Map<string, StoredSession>();
const reportsStore: StoredReport[] = [];

interface StoredChat {
  id: string;
  type: "direct" | "group" | "channel";
  name?: string;
  avatar?: string;
  description?: string;
  memberIds: string[];
  ownerId: string;
  createdAt: string;
}

interface StoredMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  text: string;
  time: string;
  timestamp: number;
  status: "sent" | "delivered" | "read";
  isEdited?: boolean;
  replyToId?: string;
  attachments?: any[];
}

interface StoredCall {
  id: string;
  callerId: string;
  callerName: string;
  callerAvatar?: string;
  recipientId: string;
  recipientName: string;
  recipientAvatar?: string;
  type: "audio" | "video";
  status: "completed" | "missed" | "declined" | "busy" | "failed";
  duration: number;
  timestamp: number;
  createdAt: string;
}

const chatsStore = new Map<string, StoredChat>();
const messagesStore = new Map<string, StoredMessage[]>();
const callHistoryStore: StoredCall[] = [];

// ======================================================
// DEFAULT ADMIN & SEED DATA
// ======================================================

const adminUser: StoredUser = {
  id: "usr_admin_den",
  name: "Den",
  username: "den",
  email: "den@zentora.io",
  passwordHash: bcrypt.hashSync("10102005", 10),
  avatar: "https://api.dicebear.com/7.x/identicon/svg?seed=ren",
  bio: "Администратор Zentora ⚡",
  phone: "",
  status: "online",
  isAdmin: true,
  isModerator: true,
  isBlocked: false,
  is2FAEnabled: false,
  createdAt: new Date().toISOString(),
};

usersStore.set(adminUser.id, adminUser);

// Seed "Saved Messages" for admin
const savedChat: StoredChat = {
  id: "chat_saved",
  type: "direct",
  name: "Избранное",
  description: "Ваши личные заметки и сохраненные сообщения",
  memberIds: [adminUser.id],
  ownerId: adminUser.id,
  createdAt: new Date().toISOString()
};
chatsStore.set(savedChat.id, savedChat);

messagesStore.set(savedChat.id, [
  {
    id: "msg_seed_1",
    chatId: "chat_saved",
    senderId: adminUser.id,
    senderName: adminUser.name,
    text: "Добро пожаловать в Zentora! Это ваше личное пространство для заметок.",
    time: "12:00",
    timestamp: Date.now(),
    status: "read"
  }
]);

// ======================================================
// RATE LIMIT
// ======================================================

const rateLimitMap = new Map<
  string,
  {
    count: number;
    firstAttempt: number;
  }
>();

function checkRateLimit(
  ip: string,
  maxAttempts = 10,
  windowMs = 60000
): boolean {
  const now = Date.now();

  const record = rateLimitMap.get(ip);

  if (!record) {
    rateLimitMap.set(ip, {
      count: 1,
      firstAttempt: now,
    });

    return true;
  }

  if (now - record.firstAttempt > windowMs) {
    rateLimitMap.set(ip, {
      count: 1,
      firstAttempt: now,
    });

    return true;
  }

  if (record.count >= maxAttempts) {
    return false;
  }

  record.count++;

  return true;
}

// ======================================================
// SERVER
// ======================================================

async function startServer() {
  const app = express();

  // Cloud Run requires 0.0.0.0
  const host = "0.0.0.0";

  // ====================================================
  // EXPRESS CONFIG
  // ====================================================

  app.set("trust proxy", 1);

  app.use(
    express.json({
      limit: "25mb",
    })
  );

  app.use(
    express.urlencoded({
      extended: true,
      limit: "25mb",
    })
  );

  // ====================================================
  // SECURITY HEADERS
  // ====================================================

  app.use((req, res, next) => {
    res.setHeader(
      "X-Content-Type-Options",
      "nosniff"
    );

    res.setHeader(
      "X-Frame-Options",
      "SAMEORIGIN"
    );

    res.setHeader(
      "Referrer-Policy",
      "strict-origin-when-cross-origin"
    );

    next();
  });

  // ====================================================
  // BASIC TEST
  // ====================================================

  app.get("/api", (req, res) => {
    res.json({
      status: "ok",
      service: "Zentora Messenger",
      message: "API is working",
    });
  });

  // ====================================================
  // HEALTH CHECK
  // ====================================================

  app.get("/api/health", (req, res) => {
    res.status(200).json({
      status: "ok",

      service: "Zentora Messenger Engine",

      websocket: "enabled",

      webrtcSignaling: "active",

      port: PORT,

      uptime: process.uptime(),

      timestamp: new Date().toISOString(),
    });
  });

  // ====================================================
  // REGISTER
  // ====================================================

  app.post(
    "/api/auth/register",
    (req, res) => {
      try {
        const clientIp =
          req.ip || "127.0.0.1";

        if (
          !checkRateLimit(
            clientIp,
            10,
            60000
          )
        ) {
          return res.status(429).json({
            error:
              "Too many attempts. Please try again in 1 minute.",
          });
        }

        const {
          name,
          username,
          email,
          password,
        } = req.body;

        if (
          !name ||
          !username ||
          !email ||
          !password
        ) {
          return res.status(400).json({
            error:
              "All fields are required.",
          });
        }

        if (
          String(password).length < 8
        ) {
          return res.status(400).json({
            error:
              "Password must be at least 8 characters long.",
          });
        }

        const cleanUsername =
          String(username)
            .toLowerCase()
            .trim()
            .replace(
              /[^a-z0-9_]/g,
              ""
            );

        const cleanEmail =
          String(email)
            .toLowerCase()
            .trim();

        if (!cleanUsername) {
          return res.status(400).json({
            error:
              "Invalid username.",
          });
        }

        for (const user of usersStore.values()) {
          if (
            user.username ===
            cleanUsername
          ) {
            return res.status(409).json({
              error:
                "Username is already taken.",
            });
          }

          if (
            user.email ===
            cleanEmail
          ) {
            return res.status(409).json({
              error:
                "Email is already registered.",
            });
          }
        }

        const newUser: StoredUser = {
          id:
            `usr_${Date.now()}_` +
            Math.random()
              .toString(36)
              .substring(2, 8),

          name: String(name).trim(),

          username: cleanUsername,

          email: cleanEmail,

          passwordHash:
            bcrypt.hashSync(
              String(password),
              10
            ),

          avatar:
            `https://api.dicebear.com/7.x/identicon/svg?seed=${encodeURIComponent(
              cleanUsername
            )}`,

          bio:
            "Hey there! I am using Zentora Messenger.",

          phone: "",

          status: "online",

          isAdmin: false,

          isModerator: false,

          isBlocked: false,

          is2FAEnabled: false,

          createdAt:
            new Date().toISOString(),
        };

        usersStore.set(
          newUser.id,
          newUser
        );

        const session: StoredSession = {
          id:
            `sess_${Date.now()}_` +
            Math.random()
              .toString(36)
              .substring(2, 8),

          userId: newUser.id,

          device: "Web Client",

          browser:
            typeof req.headers[
              "user-agent"
            ] === "string"
              ? req.headers[
                  "user-agent"
                ]
              : "Browser",

          os: "Unknown OS",

          ip: clientIp,

          location: "Online",

          lastActive:
            new Date().toISOString(),

          createdAt:
            new Date().toISOString(),
        };

        sessionsStore.set(
          session.id,
          session
        );

        const {
          passwordHash,
          ...safeUser
        } = newUser;

        return res.status(201).json({
          user: safeUser,

          sessionId: session.id,
        });
      } catch (error) {
        console.error(
          "REGISTER ERROR:",
          error
        );

        return res.status(500).json({
          error:
            "Registration failed.",
        });
      }
    }
  );

  // ====================================================
  // LOGIN
  // ====================================================

  app.post(
    "/api/auth/login",
    (req, res) => {
      try {
        const clientIp =
          req.ip || "127.0.0.1";

        if (
          !checkRateLimit(
            clientIp,
            10,
            60000
          )
        ) {
          return res.status(429).json({
            error:
              "Too many login attempts. Please wait 1 minute.",
          });
        }

        const {
          login,
          password,
        } = req.body;

        if (!login || !password) {
          return res.status(400).json({
            error:
              "Email/Username and Password are required.",
          });
        }

        const cleanLogin =
          String(login)
            .toLowerCase()
            .trim();

        let targetUser:
          | StoredUser
          | null = null;

        for (const user of usersStore.values()) {
          if (
            user.email ===
              cleanLogin ||
            user.username ===
              cleanLogin
          ) {
            targetUser = user;
            break;
          }
        }

        if (!targetUser) {
          return res.status(401).json({
            error:
              "Invalid credentials.",
          });
        }

        if (
          targetUser.isBlocked
        ) {
          return res.status(403).json({
            error:
              "Account has been suspended by an administrator.",
          });
        }

        const validPassword =
          bcrypt.compareSync(
            String(password),
            targetUser.passwordHash
          );

        if (!validPassword) {
          return res.status(401).json({
            error:
              "Invalid credentials.",
          });
        }

        targetUser.status = "online";

        const session: StoredSession = {
          id:
            `sess_${Date.now()}_` +
            Math.random()
              .toString(36)
              .substring(2, 8),

          userId: targetUser.id,

          device: "Web Desktop",

          browser:
            typeof req.headers[
              "user-agent"
            ] === "string"
              ? req.headers[
                  "user-agent"
                ]
              : "Browser",

          os: "Web Platform",

          ip: clientIp,

          location: "Online",

          lastActive:
            new Date().toISOString(),

          createdAt:
            new Date().toISOString(),
        };

        sessionsStore.set(
          session.id,
          session
        );

        const {
          passwordHash,
          ...safeUser
        } = targetUser;

        return res.json({
          user: safeUser,

          sessionId: session.id,
        });
      } catch (error) {
        console.error(
          "LOGIN ERROR:",
          error
        );

        return res.status(500).json({
          error:
            "Login failed.",
        });
      }
    }
  );

  // ====================================================
  // UPLOAD
  // ====================================================

  app.post(
    "/api/upload",
    (req, res) => {
      try {
        const {
          name,
          mimeType,
          dataUrl,
        } = req.body;

        if (
          !name ||
          !mimeType ||
          !dataUrl
        ) {
          return res.status(400).json({
            error:
              "File payload missing required fields.",
          });
        }

        const sizeInBytes =
          Math.round(
            (String(dataUrl).length *
              3) /
              4
          );

        if (
          sizeInBytes >
          25 * 1024 * 1024
        ) {
          return res.status(413).json({
            error:
              "File size exceeds 25MB limit.",
          });
        }

        let fileType:
          | "image"
          | "video"
          | "audio"
          | "voice"
          | "document" =
          "document";

        if (
          String(mimeType).startsWith(
            "image/"
          )
        ) {
          fileType = "image";
        } else if (
          String(mimeType).startsWith(
            "video/"
          )
        ) {
          fileType = "video";
        } else if (
          String(mimeType).includes(
            "audio/webm"
          ) ||
          String(mimeType).includes(
            "audio/ogg"
          ) ||
          String(name).includes(
            "voice"
          )
        ) {
          fileType = "voice";
        } else if (
          String(mimeType).startsWith(
            "audio/"
          )
        ) {
          fileType = "audio";
        }

        return res.json({
          attachment: {
            id:
              `att_${Date.now()}_` +
              Math.random()
                .toString(36)
                .substring(2, 8),

            name,

            size: sizeInBytes,

            mimeType,

            url: dataUrl,

            type: fileType,
          },
        });
      } catch (error) {
        console.error(
          "UPLOAD ERROR:",
          error
        );

        return res.status(500).json({
          error:
            "Upload failed.",
        });
      }
    }
  );

  // ====================================================
  // SESSIONS
  // ====================================================

  app.get(
    "/api/sessions",
    (req, res) => {
      return res.json(
        Array.from(
          sessionsStore.values()
        )
      );
    }
  );

  app.delete(
    "/api/sessions/:sessionId",
    (req, res) => {
      const {
        sessionId,
      } = req.params;

      sessionsStore.delete(
        sessionId
      );

      return res.json({
        success: true,

        message:
          "Session terminated.",
      });
    }
  );

  app.delete(
    "/api/sessions/other/all",
    (req, res) => {
      const currentId =
        typeof req.headers[
          "x-session-id"
        ] === "string"
          ? req.headers[
              "x-session-id"
            ]
          : "";

      for (
        const [id] of sessionsStore
      ) {
        if (id !== currentId) {
          sessionsStore.delete(id);
        }
      }

      return res.json({
        success: true,

        message:
          "All other sessions terminated.",
      });
    }
  );

  // ====================================================
  // ADMIN STATS
  // ====================================================

  app.get(
    "/api/admin/stats",
    (req, res) => {
      const adminId = req.headers['x-admin-id'] as string;
      const admin = usersStore.get(adminId);
      if (!admin || (!admin.isAdmin && !admin.isModerator)) {
        return res.status(403).json({ error: "Access denied" });
      }

      return res.json({
        totalUsers:
          usersStore.size,

        onlineUsers:
          Array.from(
            usersStore.values()
          ).filter(
            (user) =>
              user.status ===
              "online"
          ).length,

        activeSessions:
          sessionsStore.size,

        reportsCount:
          reportsStore.length,

        systemUptime:
          process.uptime(),
      });
    }
  );

  // ====================================================
  // USER SEARCH BY USERNAME / NAME / GENERAL SEARCH
  // ====================================================

  app.get("/api/search", (req, res) => {
    try {
      const q = (req.query.q || req.query.username || "") as string;
      const cleanQuery = q.toLowerCase().trim().replace(/^@/, "");
      if (!cleanQuery) {
        return res.json({ users: [] });
      }

      const results: any[] = [];
      for (const u of usersStore.values()) {
        if (
          u.username.toLowerCase().includes(cleanQuery) ||
          u.name.toLowerCase().includes(cleanQuery) ||
          u.email.toLowerCase().includes(cleanQuery)
        ) {
          const { passwordHash, ...safeUser } = u;
          results.push(safeUser);
        }
      }

      return res.json({ users: results });
    } catch (error) {
      console.error("SEARCH ERROR:", error);
      return res.status(500).json({ error: "Search failed." });
    }
  });

  app.get("/api/users/search", (req, res) => {
    try {
      const q = (req.query.username || req.query.q || "") as string;
      if (!q || typeof q !== "string") {
        return res.status(400).json({ error: "Username parameter is required." });
      }

      const cleanQuery = q.toLowerCase().trim().replace(/^@/, "");
      if (cleanQuery.length < 1) {
        return res.status(400).json({ error: "Search query is too short." });
      }

      const results: any[] = [];
      let foundUser: StoredUser | null = null;
      for (const u of usersStore.values()) {
        if (u.username.toLowerCase() === cleanQuery) {
          foundUser = u;
        }
        if (
          u.username.toLowerCase().includes(cleanQuery) ||
          u.name.toLowerCase().includes(cleanQuery)
        ) {
          const { passwordHash, ...safeUser } = u;
          results.push(safeUser);
        }
      }

      const safeFound = foundUser ? (({ passwordHash, ...safe }) => safe)(foundUser) : (results[0] || null);

      return res.json({
        found: !!safeFound,
        user: safeFound,
        users: results
      });
    } catch (error) {
      console.error("USER SEARCH ERROR:", error);
      return res.status(500).json({ error: "Search failed." });
    }
  });

  // ====================================================
  // ADMIN USERS
  // ====================================================

  app.get(
    "/api/admin/users",
    (req, res) => {
      const adminId = req.headers['x-admin-id'] as string;
      const admin = usersStore.get(adminId);
      if (!admin || (!admin.isAdmin && !admin.isModerator)) {
        return res.status(403).json({ error: "Access denied" });
      }

      const list =
        Array.from(
          usersStore.values()
        ).map(
          ({
            passwordHash,
            ...user
          }) => user
        );

      return res.json(list);
    }
  );

  // ====================================================
  // ADMIN BLOCK
  // ====================================================

  app.post(
    "/api/admin/block",
    (req, res) => {
      const adminId = req.headers['x-admin-id'] as string;
      const admin = usersStore.get(adminId);
      if (!admin || (!admin.isAdmin && !admin.isModerator)) {
        return res.status(403).json({ error: "Access denied" });
      }

      const {
        userId,
        blocked,
        isDeleted,
        reason,
        name,
        bio
      } = req.body;

      const user =
        usersStore.get(userId);

      if (!user) {
        return res.status(404).json({
          error:
            "User not found.",
        });
      }

      user.isBlocked =
        Boolean(blocked);

      if (user.isBlocked) {
        user.status = "offline";
        if (isDeleted) {
          user.name = name || "Удалённый аккаунт";
          user.avatar = "";
          user.bio = bio || "Данный аккаунт был удален за иную причину администрацией Zentora.";
        }
      } else {
        user.name = user.username || "Пользователь";
      }

      return res.json({
        success: true,
        user,
      });
    }
  );

  // ====================================================
  // REPORTS
  // ====================================================

  app.post(
    "/api/reports",
    (req, res) => {
      const {
        targetId,
        targetType,
        reason,
        details,
      } = req.body;

      if (
        !targetId ||
        !targetType
      ) {
        return res.status(400).json({
          error:
            "Target information is required.",
        });
      }

      const report: StoredReport = {
        id: `rep_${Date.now()}`,

        reporterId: "usr_me",

        reporterName:
          "Alexander Zent",

        targetId,

        targetType,

        reason:
          reason ||
          "Inappropriate content",

        details:
          details || "",

        createdAt:
          new Date().toISOString(),

        status: "pending",
      };

      reportsStore.push(
        report
      );

      return res.json({
        success: true,

        report,
      });
    }
  );

  app.post("/api/admin/toggle-moderator", (req, res) => {
    const { userId, moderator } = req.body;
    const adminId = req.headers['x-admin-id'] as string;
    
    // Safety check: Only Ren can promote others to moderator
    const admin = usersStore.get(adminId);
    if (!admin || admin.username?.toLowerCase() !== 'ren') {
      return res.status(403).json({ error: "Access denied. Only owner can manage moderators." });
    }

    const user = usersStore.get(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    user.isModerator = moderator;
    return res.json({ success: true, isModerator: user.isModerator });
  });

  app.get(
    "/api/reports",
    (req, res) => {
      return res.json(
        reportsStore
      );
    }
  );

  // ====================================================
  // CHATS & MESSAGES (PERSISTENCE)
  // ====================================================

  app.get("/api/chats", (req, res) => {
    const userId = req.query.userId as string;
    if (!userId) return res.status(400).json({ error: "userId required" });

    const userChats = Array.from(chatsStore.values()).filter(c => 
      c.memberIds.includes(userId)
    );

    // Map stored chats back to frontend Chat type
    const frontendChats = userChats.map(c => ({
      id: c.id,
      type: c.type,
      name: c.name,
      avatar: c.avatar,
      description: c.description,
      members: c.memberIds.map(mid => ({
        userId: mid,
        role: mid === c.ownerId ? 'owner' : 'member',
        joinedAt: c.createdAt
      })),
      unreadCount: 0, // In a real app, this would be calculated from message read status
      createdAt: c.createdAt,
      lastMessage: (messagesStore.get(c.id) || []).slice(-1)[0]
    }));

    return res.json(frontendChats);
  });

  app.get("/api/messages/:chatId", (req, res) => {
    const { chatId } = req.params;
    const messages = messagesStore.get(chatId) || [];
    return res.json(messages);
  });

  // ====================================================
  // CALL HISTORY ENDPOINTS
  // ====================================================

  app.get("/api/calls/history", (req, res) => {
    const userId = req.query.userId ? String(req.query.userId) : null;
    if (!userId) {
      return res.json({ calls: callHistoryStore.slice(-50).reverse() });
    }
    const userCalls = callHistoryStore.filter(
      c => c.callerId === userId || c.recipientId === userId
    ).slice(-50).reverse();
    return res.json({ calls: userCalls });
  });

  app.post("/api/calls/history", (req, res) => {
    const { id, callerId, callerName, callerAvatar, recipientId, recipientName, recipientAvatar, type, status, duration, timestamp, createdAt } = req.body;
    if (!callerId || !recipientId) {
      return res.status(400).json({ error: "Missing required call details" });
    }
    const newCall: StoredCall = {
      id: id || `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      callerId,
      callerName: callerName || "Пользователь",
      callerAvatar: callerAvatar || "",
      recipientId,
      recipientName: recipientName || "Пользователь",
      recipientAvatar: recipientAvatar || "",
      type: type || "audio",
      status: status || "completed",
      duration: duration || 0,
      timestamp: timestamp || Date.now(),
      createdAt: createdAt || new Date().toISOString()
    };
    callHistoryStore.push(newCall);
    if (callHistoryStore.length > 200) {
      callHistoryStore.shift();
    }
    return res.json({ success: true, call: newCall });
  });

  app.delete("/api/calls/history", (req, res) => {
    const userId = req.query.userId ? String(req.query.userId) : null;
    if (userId) {
      for (let i = callHistoryStore.length - 1; i >= 0; i--) {
        if (callHistoryStore[i].callerId === userId || callHistoryStore[i].recipientId === userId) {
          callHistoryStore.splice(i, 1);
        }
      }
    } else {
      callHistoryStore.length = 0;
    }
    return res.json({ success: true });
  });

  // ====================================================
  // SEARCH
  // ====================================================

  app.get("/api/search", (req, res) => {
    const rawQuery = String(req.query.q || "").toLowerCase().trim();
    if (!rawQuery) {
      return res.json({ users: [], chats: [] });
    }

    const qClean = rawQuery.startsWith('@') ? rawQuery.slice(1) : rawQuery;

    const users = Array.from(usersStore.values())
      .filter(u => 
        u.name.toLowerCase().includes(qClean) || 
        u.username.toLowerCase().includes(qClean) ||
        u.email.toLowerCase().includes(qClean)
      )
      .map(({ passwordHash, ...user }) => user);

    return res.json({ users, chats: [] });
  });

  // ====================================================
  // FRONTEND MIDDLEWARE / SPA FALLBACK
  // ====================================================

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res, next) => {
      if (req.path.startsWith("/api/")) {
        return next();
      }
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // ====================================================
  // HTTP SERVER
  // ====================================================

  const server =
    createServer(app);

  // ====================================================
  // WEBSOCKET SERVER
  // ====================================================

  const wss =
    new WebSocketServer({
      server,
      path: "/ws"
    });

  const clients = new Map<string, Set<WebSocket>>();

  wss.on("connection", (ws) => {
    let currentUserId: string | null = null;

    ws.on("message", (messageRaw) => {
      try {
        const data = JSON.parse(messageRaw.toString());
        const { type, payload } = data;

        if (type === "ping") {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: "pong", timestamp: Date.now() }));
          }
          return;
        }

        if (type === "auth") {
          currentUserId = payload?.userId || null;
          if (currentUserId) {
            if (!clients.has(currentUserId)) {
              clients.set(currentUserId, new Set());
            }
            clients.get(currentUserId)!.add(ws);
            console.log(`User ${currentUserId} authenticated, total active connections for user: ${clients.get(currentUserId)!.size}`);
            
            // Broadcast online status
            const onlineEvent = JSON.stringify({
              type: "user:online",
              payload: { userId: currentUserId },
            });
            clients.forEach((userSockets, id) => {
              userSockets.forEach(client => {
                if (client !== ws && client.readyState === WebSocket.OPEN) {
                  client.send(onlineEvent);
                }
              });
            });
          }
          return;
        }

        if (type === "typing:start" || type === "typing:stop") {
          const event = JSON.stringify({ type, payload });
          clients.forEach((userSockets, id) => {
            userSockets.forEach(client => {
              if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(event);
              }
            });
          });
          return;
        }

        // ------------------------------------------
        // MESSAGES
        // ------------------------------------------

        if (type === "message:new") {
          const { message, memberIds } = payload;
          if (message && message.chatId) {
            // Persist message
            const msgs = messagesStore.get(message.chatId) || [];
            messagesStore.set(message.chatId, [...msgs, message]);
            
            // Update chat last active? (Optional but good)
          }

          const event = JSON.stringify({ type, payload });
          const targetIds = memberIds || (chatsStore.get(message?.chatId)?.memberIds);

          if (targetIds && Array.isArray(targetIds)) {
            targetIds.forEach((targetId: string) => {
              const userSockets = clients.get(targetId);
              if (userSockets) {
                userSockets.forEach(client => {
                  if (client !== ws && client.readyState === WebSocket.OPEN) {
                    client.send(event);
                  }
                });
              }
            });
          } else {
            clients.forEach((userSockets, id) => {
              userSockets.forEach(client => {
                if (client !== ws && client.readyState === WebSocket.OPEN) {
                  client.send(event);
                }
              });
            });
          }
          return;
        }

        if (type === "chat:new") {
          const { chat, memberIds } = payload;
          if (chat && chat.id) {
            // Persist chat
            chatsStore.set(chat.id, {
              id: chat.id,
              type: chat.type,
              name: chat.name,
              avatar: chat.avatar,
              description: chat.description,
              memberIds: chat.members.map((m: any) => m.userId),
              ownerId: currentUserId || chat.members[0].userId,
              createdAt: chat.createdAt
            });
          }

          const event = JSON.stringify({ type, payload });
          if (memberIds && Array.isArray(memberIds)) {
            memberIds.forEach((targetId: string) => {
              const userSockets = clients.get(targetId);
              if (userSockets) {
                userSockets.forEach(client => {
                  if (client !== ws && client.readyState === WebSocket.OPEN) {
                    client.send(event);
                  }
                });
              }
            });
          }
          return;
        }

        if (
          type === "message:update" ||
          type === "message:delete" ||
          type === "message:status" ||
          type === "chat:update" ||
          type === "call:offer" ||
          type === "call:answer" ||
          type === "call:reject" ||
          type === "call:cancel" ||
          type === "call:hangup" ||
          type === "call:ice-candidate" ||
          type === "call:media-state" ||
          type === "call:ringing" ||
          type === "call:busy" ||
          type === "call:reconnect" ||
          type === "call:initiate"
        ) {
          // Update persistence for messages
          if (type === "message:update") {
            const { chatId, messageId, newText, reaction } = payload;
            const msgs = messagesStore.get(chatId) || [];
            messagesStore.set(chatId, msgs.map(m => {
              if (m.id === messageId) {
                if (newText) return { ...m, text: newText, isEdited: true };
                // Reactions logic here if needed
              }
              return m;
            }));
          } else if (type === "message:delete") {
            const { chatId, messageId } = payload;
            const msgs = messagesStore.get(chatId) || [];
            messagesStore.set(chatId, msgs.filter(m => m.id !== messageId));
          } else if (type === "message:status") {
            const { chatId, messageId, status } = payload;
            const msgs = messagesStore.get(chatId) || [];
            messagesStore.set(chatId, msgs.map(m => m.id === messageId ? { ...m, status } : m));
          }

          const event = JSON.stringify({ type, payload });
          
          // Check if payload targets specific user (recipientId or targetId or memberIds)
          const targetIds: string[] = [];
          if (payload?.recipientId) targetIds.push(payload.recipientId);
          if (payload?.targetUserId) targetIds.push(payload.targetUserId);
          if (payload?.callerId && payload.callerId !== currentUserId) targetIds.push(payload.callerId);
          if (payload?.memberIds && Array.isArray(payload.memberIds)) {
            payload.memberIds.forEach((t: string) => {
              if (!targetIds.includes(t)) targetIds.push(t);
            });
          }

          if (targetIds.length > 0) {
            targetIds.forEach((targetId: string) => {
              const userSockets = clients.get(targetId);
              if (userSockets) {
                userSockets.forEach(client => {
                  if (client !== ws && client.readyState === WebSocket.OPEN) {
                    client.send(event);
                  }
                });
              }
            });
          } else {
            clients.forEach((userSockets, id) => {
              userSockets.forEach(client => {
                if (client !== ws && client.readyState === WebSocket.OPEN) {
                  client.send(event);
                }
              });
            });
          }

          return;
        }

          } catch (error) {
            console.error("WEBSOCKET MESSAGE ERROR:", error);
          }
        });

      ws.on("close", () => {
        if (currentUserId && clients.has(currentUserId)) {
          clients.get(currentUserId)!.delete(ws);
          if (clients.get(currentUserId)!.size === 0) {
            clients.delete(currentUserId);
            // Optional: update usersStore status
            const user = usersStore.get(currentUserId);
            if (user) user.status = "offline";

            const offlineEvent = JSON.stringify({
              type: "user:offline",
              payload: { userId: currentUserId },
            });
            clients.forEach((userSockets) => {
              userSockets.forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                  client.send(offlineEvent);
                }
              });
            });
          }
        }
        console.log(`User ${currentUserId} disconnected`);
      });

      ws.on("error", (error) => {
        console.error("WEBSOCKET ERROR:", error);
      });
    }
  );

  // ====================================================
  // SERVER ERROR
  // ====================================================

  server.on(
    "error",
    (error) => {
      console.error(
        "SERVER ERROR:",
        error
      );

      process.exit(1);
    }
  );

  // ====================================================
  // START
  // ====================================================

  server.listen(
    PORT,
    host,
    () => {
      console.log(
        "======================================"
      );

      console.log(
        "ZENTORA MESSENGER SERVER"
      );

      console.log(
        "======================================"
      );

      console.log(
        `Server listening on ${host}:${PORT}`
      );

      console.log(
        `Cloud Run PORT: ${PORT}`
      );

      console.log(
        `Root directory: ${rootDir}`
      );

      console.log(
        `Frontend directory: ${path.resolve(rootDir, "dist")}`
      );

      console.log(
        "WebSocket: ENABLED"
      );

      console.log(
        "Health: /api/health"
      );

      console.log(
        "======================================"
      );
    }
  );
}

// ======================================================
// START APPLICATION
// ======================================================

startServer().catch(
  (error) => {
    console.error(
      "======================================"
    );

    console.error(
      "FATAL SERVER STARTUP ERROR"
    );

    console.error(
      "======================================"
    );

    console.error(error);

    process.exit(1);
  }
);