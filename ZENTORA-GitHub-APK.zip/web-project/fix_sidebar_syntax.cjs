const fs = require('fs');

const file = 'src/components/Sidebar.tsx';
let content = fs.readFileSync(file, 'utf8');

const errorBlock = `    // apiUsers.forEach(u => {
      if (u.id !== user?.id) {
        globalUserMap.set(u.id, u);
      }
    });`;

content = content.replace(errorBlock, '');
fs.writeFileSync(file, content);
