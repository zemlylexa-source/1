const fs = require('fs');
let code = fs.readFileSync('src/components/CreateChatModal.tsx', 'utf8');

code = code.replace(/createChat\(chatType, nameInput, selectedUserIds, descInput\);/, `let finalName = nameInput;
    if (chatType === 'direct') {
       const target = registeredUsers.find(u => u.id === selectedUserIds[0]);
       if (target) finalName = target.name;
    }
    createChat(chatType, finalName, selectedUserIds, descInput);`);

fs.writeFileSync('src/components/CreateChatModal.tsx', code);
