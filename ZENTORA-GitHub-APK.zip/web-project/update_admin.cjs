const fs = require('fs');

let initialData = fs.readFileSync('src/lib/initialData.ts', 'utf8');
initialData = initialData.replace(/usr_admin_ren/g, 'usr_admin_den');
initialData = initialData.replace(/'Ren'/g, "'Den'");
initialData = initialData.replace(/'ren'/g, "'den'");
initialData = initialData.replace(/'ren@zentora.io'/g, "'den@zentora.io'");
fs.writeFileSync('src/lib/initialData.ts', initialData);

let serverData = fs.readFileSync('server.ts', 'utf8');
serverData = serverData.replace(/usr_admin_ren/g, 'usr_admin_den');
serverData = serverData.replace(/"Ren"/g, '"Den"');
serverData = serverData.replace(/"ren"/g, '"den"');
serverData = serverData.replace(/"ren@zentora.io"/g, '"den@zentora.io"');
serverData = serverData.replace(/bcrypt\.hashSync\("admin1234", 10\)/g, 'bcrypt.hashSync("10102005", 10)');
fs.writeFileSync('server.ts', serverData);

let authContext = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');
authContext = authContext.replace(/usr_admin_ren/g, 'usr_admin_den');
authContext = authContext.replace(/ren@zentora\.io/g, 'den@zentora.io');
authContext = authContext.replace(/cleanUsername === 'ren'/g, "cleanUsername === 'den'");
authContext = authContext.replace(/trimmedInput === 'ren@zentora\.io'/g, "trimmedInput === 'den@zentora.io'");
// the old hash was 5af4... (admin123455)
// the new hash is 84cd2989dc91d13ea10da515e884c6d59acafe997d62c04c78a258975d064832
authContext = authContext.replace(/5af487585ec137c5916b93384ad1974d66aaa3f0e42d2741a34997634b4a0f2c/g, '84cd2989dc91d13ea10da515e884c6d59acafe997d62c04c78a258975d064832');
authContext = authContext.replace(/u\.username\?\.toLowerCase\(\) === 'ren'/g, "u.username?.toLowerCase() === 'den'");
fs.writeFileSync('src/context/AuthContext.tsx', authContext);

let adminPanel = fs.readFileSync('src/components/AdminPanelModal.tsx', 'utf8');
adminPanel = adminPanel.replace(/usr_admin_ren/g, 'usr_admin_den');
adminPanel = adminPanel.replace(/ren/gi, 'den');
adminPanel = adminPanel.replace(/Den/g, 'Den'); // capitalize properly where it might have become 'den' 
// let's just make sure we only replaced ren with den for the string comparisons.
fs.writeFileSync('src/components/AdminPanelModal.tsx', adminPanel);
