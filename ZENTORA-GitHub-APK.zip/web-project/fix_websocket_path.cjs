const fs = require('fs');
let serverFile = fs.readFileSync('server.ts', 'utf8');

serverFile = serverFile.replace(
  'const wss =\n    new WebSocketServer({\n      server,\n    });',
  'const wss =\n    new WebSocketServer({\n      server,\n      path: "/ws"\n    });'
);
fs.writeFileSync('server.ts', serverFile);

let chatContext = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');
chatContext = chatContext.replace(
  'const ws = new WebSocket(`${protocol}//${window.location.host}`);',
  'const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);'
);
fs.writeFileSync('src/context/ChatContext.tsx', chatContext);

let callContext = fs.readFileSync('src/context/CallContext.tsx', 'utf8');
callContext = callContext.replace(
  'const ws = new WebSocket(`${protocol}//${window.location.host}`);',
  'const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);'
);
fs.writeFileSync('src/context/CallContext.tsx', callContext);
