const fs = require('fs');

// Ensure Profile, Search, and Notifications also use the black text overrides in light mode
const filesToUpdate = [
  'src/components/social/ProfileView.tsx',
  'src/components/social/NotificationsView.tsx',
  'src/components/social/SearchView.tsx',
  'src/components/social/SocialSidebar.tsx'
];

filesToUpdate.forEach(file => {
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, 'utf8');
    content = content.replace(/text-\[var\(--text-primary\)\]/g, "text-gray-900 dark:text-white");
    content = content.replace(/text-\[var\(--text-secondary\)\]/g, "text-gray-600 dark:text-gray-400");
    fs.writeFileSync(file, content);
  }
});
