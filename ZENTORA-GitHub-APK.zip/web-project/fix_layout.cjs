const fs = require('fs');

let mainLayout = fs.readFileSync('src/components/MainLayout.tsx', 'utf8');

// Insert new imports
const importSocialSidebar = "import { SocialSidebar } from './social/SocialSidebar';\nimport { FeedView } from './social/FeedView';\nimport { ProfileView } from './social/ProfileView';\nimport { NotificationsView } from './social/NotificationsView';\nimport { SearchView } from './social/SearchView';\n";
mainLayout = mainLayout.replace("import { Attachment } from './types';", "import { Attachment } from './types';\n" + importSocialSidebar);

// Add globalTab state
mainLayout = mainLayout.replace("const [activeSection, setActiveSection] = useState<'chats' | 'contacts' | 'calls'>('chats');", "const [activeSection, setActiveSection] = useState<'chats' | 'contacts' | 'calls'>('chats');\n  const [globalTab, setGlobalTab] = useState<string>('feed');");

// Modify the MainLayout structure to include SocialSidebar and conditionally render Messenger vs Social views
const oldAppContent = `        {/* App Content Area */}
        <div className="flex flex-1 overflow-hidden relative w-full h-full">
          
          {/* Sidebar / Chat List */}
          <div className={\`\${activeChatId && isPhoneView ? 'hidden' : 'flex'} w-full \${!isPhoneView ? 'md:w-80 lg:w-96' : ''} shrink-0 h-full\`}>
            <Sidebar
              onOpenCreateChat={() => setShowCreateChatModal(true)}
              onOpenSettings={() => setShowSettingsModal(true)}
              onOpenAdmin={() => setShowAdminModal(true)}
              activeSection={activeSection}
              setActiveSection={setActiveSection}
            />
          </div>

          {/* Center Main Chat Area */}
          <div className={\`\${activeChatId || !isPhoneView ? 'flex' : 'hidden'} flex-1 h-full overflow-hidden relative\`}>
            {activeSection === 'chats' && (
              <ChatArea
                onToggleInfoPanel={() => setShowInfoPanel(!showInfoPanel)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenReport={() => setShowReportModal(true)}
              />
            )}
            {activeSection === 'contacts' && <ContactsView onChatStart={() => setActiveSection('chats')} />}
            {activeSection === 'calls' && <CallsView />}

            {/* Right Info Panel */}
            {showInfoPanel && activeSection === 'chats' && (
              <InfoPanel
                onClose={() => setShowInfoPanel(false)}
                onOpenReport={() => setShowReportModal(true)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenSearch={() => setIsSearchOpen(true)}
              />
            )}
          </div>
        </div>`;

const newAppContent = `        {/* App Content Area */}
        <div className="flex flex-1 overflow-hidden relative w-full h-full">
          
          {/* Global Social Sidebar (Hidden on small mobile if in chat) */}
          {!isPhoneView && (
             <SocialSidebar activeTab={globalTab} onTabChange={setGlobalTab} />
          )}

          {globalTab === 'messenger' && (
            <>
              {/* Sidebar / Chat List */}
              <div className={\`\${activeChatId && isPhoneView ? 'hidden' : 'flex'} w-full \${!isPhoneView ? 'md:w-80 lg:w-96' : ''} shrink-0 h-full border-r border-[var(--border)]\`}>
                <Sidebar
                  onOpenCreateChat={() => setShowCreateChatModal(true)}
                  onOpenSettings={() => setShowSettingsModal(true)}
                  onOpenAdmin={() => setShowAdminModal(true)}
                  activeSection={activeSection}
                  setActiveSection={setActiveSection}
                />
              </div>

              {/* Center Main Chat Area */}
              <div className={\`\${activeChatId || !isPhoneView ? 'flex' : 'hidden'} flex-1 h-full overflow-hidden relative\`}>
                {activeSection === 'chats' && (
                  <ChatArea
                    onToggleInfoPanel={() => setShowInfoPanel(!showInfoPanel)}
                    onOpenMediaViewer={(att) => setSelectedMedia(att)}
                    onOpenReport={() => setShowReportModal(true)}
                  />
                )}
                {activeSection === 'contacts' && <ContactsView onChatStart={() => setActiveSection('chats')} />}
                {activeSection === 'calls' && <CallsView />}

                {/* Right Info Panel */}
                {showInfoPanel && activeSection === 'chats' && (
                  <InfoPanel
                    onClose={() => setShowInfoPanel(false)}
                    onOpenReport={() => setShowReportModal(true)}
                    onOpenMediaViewer={(att) => setSelectedMedia(att)}
                    onOpenSearch={() => setIsSearchOpen(true)}
                  />
                )}
              </div>
            </>
          )}

          {globalTab === 'feed' && <FeedView />}
          {globalTab === 'profile' && <ProfileView />}
          {globalTab === 'notifications' && <NotificationsView />}
          {globalTab === 'search' && <SearchView />}
          {(globalTab === 'store' || globalTab === 'event') && (
            <div className="flex-1 flex flex-col items-center justify-center bg-[var(--background)] text-[var(--text-secondary)]">
              <span className="text-6xl mb-4">🚧</span>
              <h2 className="text-2xl font-bold">Раздел в разработке</h2>
              <p className="mt-2">Скоро здесь появится что-то интересное!</p>
            </div>
          )}

        </div>`;

mainLayout = mainLayout.replace(oldAppContent, newAppContent);
fs.writeFileSync('src/components/MainLayout.tsx', mainLayout);
