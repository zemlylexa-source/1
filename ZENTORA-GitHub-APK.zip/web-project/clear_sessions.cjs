const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(/const sessionsStore: Map<string, StoredSession> = new Map\(\[[\s\S]*?\]\);/, 'const sessionsStore: Map<string, StoredSession> = new Map();');
fs.writeFileSync('server.ts', code);
