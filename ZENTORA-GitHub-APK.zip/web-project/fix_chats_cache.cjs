const fs = require('fs');
let content = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');

// Remove load local chats
content = content.replace(/      \/\/ Load local chats first\n      try \{\n        const saved = sessionStorage\.getItem\(`zentora_local_chats_\$\{user\.id\}`\);\n        if \(saved\) \{\n          const parsed: Chat\[\] = JSON\.parse\(saved\);\n          parsed\.forEach\(c => \{\n            if \(c && c\.id\) \{\n              if \(\!Array\.isArray\(c\.memberIds\)\) c\.memberIds = \[\];\n              chatsMap\.set\(c\.id, c\);\n            \}\n          \}\);\n        \}\n      \} catch \(e\) \{\}/, '');

// Remove fallback local chats
content = content.replace(/      \/\/ Fallback local chats\n      try \{\n        const saved = sessionStorage\.getItem\(`zentora_local_chats_\$\{user\.id\}`\);\n        if \(saved\) \{\n          setChats\(JSON\.parse\(saved\)\);\n        \}\n      \} catch \(e\) \{\}/, '');

// Remove save to local storage in sendMessage
content = content.replace(/      try \{\n        sessionStorage\.setItem\(`zentora_local_chats_\$\{user\.id\}`, JSON\.stringify\(updated\)\);\n      \} catch \(e\) \{\}/g, '');

// Remove save to local storage in createChat
content = content.replace(/      try \{\n        sessionStorage\.setItem\(`zentora_local_chats_\$\{user\.id\}`, JSON\.stringify\(next\)\);\n      \} catch \(e\) \{\}/g, '');

fs.writeFileSync('src/context/ChatContext.tsx', content);
