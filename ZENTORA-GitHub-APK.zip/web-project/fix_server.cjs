const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');
code = code.replace(
  'const __filename = typeof process !== "undefined" && process.argv[1] ? process.argv[1] : "";\nconst __dirname = path.dirname(__filename);',
  'const rootDir = process.cwd();'
);
// replace __dirname with rootDir where necessary
code = code.replace(/__dirname/g, 'rootDir');
fs.writeFileSync('server.ts', code);
