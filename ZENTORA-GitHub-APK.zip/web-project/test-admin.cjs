const admin = require('firebase-admin');
admin.initializeApp({ projectId: 'linen-cubist-118qq' });
admin.auth().listUsers(10).then((users) => {
  console.log("Success! Users count:", users.users.length);
}).catch((err) => {
  console.log("Error:", err.message);
});
