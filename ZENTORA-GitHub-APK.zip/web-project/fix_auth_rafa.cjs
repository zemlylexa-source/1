const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

// Inside useEffect for auth state, there is:
/*
          const savedGuest = localStorage.getItem('zentora_guest_user');
          if (savedGuest) {
            try {
              const parsed = JSON.parse(savedGuest);
              setUser(sanitizeUser(parsed));
            } catch {
*/
// Let's replace that block
content = content.replace(
  `              const parsed = JSON.parse(savedGuest);\n              setUser(sanitizeUser(parsed));`,
  `              const parsed = JSON.parse(savedGuest);
              if (parsed.id === 'usr_admin_rafa' || parsed.username === 'rafa') {
                localStorage.removeItem('zentora_guest_user');
                setUser(null);
              } else {
                setUser(sanitizeUser(parsed));
              }`
);

fs.writeFileSync('src/context/AuthContext.tsx', content);
