const fs = require('fs');

let content = fs.readFileSync('src/components/AdminPanelModal.tsx', 'utf8');

// Replace: await banUser(targetUser.id, reason, duration);
// With: await banUser(targetUser.id, duration === 0 ? { isPermanent: true } : { minutes: duration }, reason);

content = content.replace(
  `await banUser(targetUser.id, reason, duration);`,
  `await banUser(targetUser.id, duration === 0 ? { isPermanent: true } : { minutes: duration }, reason);`
);

fs.writeFileSync('src/components/AdminPanelModal.tsx', content);
