const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

code = code.replace(/const \[user, setUser\] = useState<User \| null>\(\(\) => \{[\s\S]*?\}\);/, `const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('zentora_user');
    if (!saved) return null;
    const parsedUser = JSON.parse(saved);
    if (parsedUser && (parsedUser.id === 'usr_me' || parsedUser.id === 'usr_elena')) {
        localStorage.removeItem('zentora_user');
        return null;
    }
    return parsedUser;
  });`);

fs.writeFileSync('src/context/AuthContext.tsx', code);
