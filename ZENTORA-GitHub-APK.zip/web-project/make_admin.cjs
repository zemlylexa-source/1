const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');
code = code.replace('isAdmin: false', 'isAdmin: true');
fs.writeFileSync('src/context/AuthContext.tsx', code);
