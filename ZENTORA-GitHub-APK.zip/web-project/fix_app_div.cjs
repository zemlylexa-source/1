const fs = require('fs');

let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// The error says "JSX element 'div' has no corresponding closing tag" at line 85.
// Let's look around line 85.

const appTsxLines = appTsx.split('\n');
console.log(appTsxLines.slice(80, 100).join('\n'));

