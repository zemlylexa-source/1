const fs = require('fs');
let chatArea = fs.readFileSync('src/components/ChatArea.tsx', 'utf8');

// The main chat container background
const bgClasses = "className=\"flex-1 flex flex-col relative overflow-hidden bg-[var(--background)]\"";
const newBgClasses = "className=\"flex-1 flex flex-col relative overflow-hidden bg-[var(--background)] relative\"\n      style={{ backgroundImage: 'url(\"https://www.transparenttextures.com/patterns/cubes.png\")', backgroundBlendMode: 'overlay', opacity: 0.98 }}";

chatArea = chatArea.replace(bgClasses, newBgClasses);
fs.writeFileSync('src/components/ChatArea.tsx', chatArea);
