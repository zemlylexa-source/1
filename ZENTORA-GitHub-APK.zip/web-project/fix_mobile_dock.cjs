const fs = require('fs');

let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// Need to import missing icons if not already there: Home, Search, Bell, User as UserIcon
if (!appTsx.includes('import { Home, Search, Bell, User as UserIcon }')) {
  appTsx = appTsx.replace("import { MessageSquare, Contact, Phone, Settings } from 'lucide-react';", "import { MessageSquare, Contact, Phone, Settings, Home, Search, Bell, User as UserIcon } from 'lucide-react';");
}


const oldDock = `        {/* Floating Mobile Dock Navigation Bar */}
        {isPhoneView && !activeChatId && (
          <div className="p-2 pb-3 bg-slate-950/90 backdrop-blur-2xl border-t border-white/10 shrink-0 z-40 select-none">
            <div className="w-full max-w-sm mx-auto bg-slate-900/90 border border-white/10 rounded-full p-1 flex items-center justify-around gap-1 shadow-2xl">
              <button
                onClick={() => setActiveSection('chats')}
                className={\`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all \${
                  activeSection === 'chats'
                    ? 'bg-purple-600/30 text-purple-200 font-bold border border-purple-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }\`}
              >
                <MessageSquare className="w-4 h-4 text-purple-400" />
                <span>Чаты</span>
              </button>
              <button
                onClick={() => setActiveSection('calls')}
                className={\`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all \${
                  activeSection === 'calls'
                    ? 'bg-emerald-600/30 text-emerald-200 font-bold border border-emerald-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }\`}
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Звонки</span>
              </button>
              <button
                onClick={() => setActiveSection('contacts')}
                className={\`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all \${
                  activeSection === 'contacts'
                    ? 'bg-blue-600/30 text-blue-200 font-bold border border-blue-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }\`}
              >
                <Contact className="w-4 h-4 text-blue-400" />
                <span>Контакты</span>
              </button>
            </div>
          </div>
        )}`;

const newDock = `        {/* Floating Mobile Dock Navigation Bar */}
        {isPhoneView && !activeChatId && (
          <div className="pt-2 pb-6 px-4 bg-white/90 dark:bg-[#090b10]/90 backdrop-blur-2xl border-t border-[var(--border)] shrink-0 z-40 select-none shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
            <div className="w-full max-w-sm mx-auto flex items-center justify-between">
              <button
                onClick={() => setGlobalTab('feed')}
                className={\`flex flex-col items-center gap-1 p-2 transition-all \${
                  globalTab === 'feed'
                    ? 'text-[var(--text-primary)] scale-110'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }\`}
              >
                <Home className={\`w-6 h-6 \${globalTab === 'feed' ? 'fill-current' : ''}\`} />
                <span className="text-[10px] font-bold">Лента</span>
              </button>

              <button
                onClick={() => setGlobalTab('search')}
                className={\`flex flex-col items-center gap-1 p-2 transition-all \${
                  globalTab === 'search'
                    ? 'text-[var(--text-primary)] scale-110'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }\`}
              >
                <Search className={\`w-6 h-6 \${globalTab === 'search' ? 'stroke-[3px]' : ''}\`} />
                <span className="text-[10px] font-bold">Поиск</span>
              </button>

              <button
                onClick={() => setGlobalTab('messenger')}
                className={\`flex flex-col items-center gap-1 p-2 transition-all \${
                  globalTab === 'messenger'
                    ? 'text-[var(--text-primary)] scale-110'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }\`}
              >
                <MessageSquare className={\`w-6 h-6 \${globalTab === 'messenger' ? 'fill-current' : ''}\`} />
                <span className="text-[10px] font-bold">Чаты</span>
              </button>

              <button
                onClick={() => setGlobalTab('notifications')}
                className={\`flex flex-col items-center gap-1 p-2 transition-all \${
                  globalTab === 'notifications'
                    ? 'text-[var(--text-primary)] scale-110'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }\`}
              >
                <Bell className={\`w-6 h-6 \${globalTab === 'notifications' ? 'fill-current' : ''}\`} />
                <span className="text-[10px] font-bold">Уведы</span>
              </button>

              <button
                onClick={() => setGlobalTab('profile')}
                className={\`flex flex-col items-center gap-1 p-2 transition-all \${
                  globalTab === 'profile'
                    ? 'text-[var(--text-primary)] scale-110'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }\`}
              >
                <UserIcon className={\`w-6 h-6 \${globalTab === 'profile' ? 'fill-current' : ''}\`} />
                <span className="text-[10px] font-bold">Профиль</span>
              </button>
            </div>
          </div>
        )}`;

if (appTsx.includes(oldDock)) {
  appTsx = appTsx.replace(oldDock, newDock);
  fs.writeFileSync('src/App.tsx', appTsx);
  console.log("Successfully updated dock");
} else {
  console.log("Could not find old dock");
}

