const fs = require('fs');

let profile = fs.readFileSync('src/components/UserProfileModal.tsx', 'utf8');

const regexStats = /\{\/\* Account Activity Stats \*\/\}[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/;
profile = profile.replace(regexStats, '');
fs.writeFileSync('src/components/UserProfileModal.tsx', profile);

let adminPanel = fs.readFileSync('src/components/AdminPanelModal.tsx', 'utf8');

// Replace {!u.isAdmin && ( with {u.username?.toLowerCase() !== 'den' && (
adminPanel = adminPanel.replace(/\{\!u\.isAdmin && \(/g, "{u.username?.toLowerCase() !== 'den' && (");

fs.writeFileSync('src/components/AdminPanelModal.tsx', adminPanel);
