import { User, Chat, Message, UserSession, UserSettings, CallLog } from '../types';

export const CURRENT_USER: User = {
  id: 'usr_admin_den',
  name: 'Den',
  username: 'den',
  email: 'den@zentora.io',
  avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=den',
  bio: 'Главный Администратор Zentora ⚡',
  status: 'online',
  isAdmin: true,
  isModerator: true,
  is2FAEnabled: false,
  createdAt: '2026-01-01T00:00:00.000Z'
};

export const DEFAULT_SETTINGS: UserSettings = {
  theme: 'dark',
  fontSize: 'medium',
  notificationsEnabled: true,
  soundEnabled: true,
  messagePreview: true,
  enterToSend: true,
  reducedMotion: false,
  density: 'comfortable',
  lastSeenPrivacy: 'everyone',
  profilePhotoPrivacy: 'everyone',
  whoCanMessageMe: 'everyone',
  whoCanAddToGroups: 'everyone'
};

export const INITIAL_SESSIONS: UserSession[] = [];

// Single admin user Ren, all other accounts deleted
export const MOCK_USERS: User[] = [CURRENT_USER];

export const INITIAL_CHATS: Chat[] = [];
export const INITIAL_MESSAGES: Record<string, Message[]> = {};
export const INITIAL_CALL_LOGS: CallLog[] = [];
