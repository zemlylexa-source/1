export type UserStatus = 'online' | 'offline' | 'away' | 'deleted';

export interface ProfileComment {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername: string;
  authorAvatar?: string;
  text: string;
  date: string;
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  url: string;
  cover: string;
  duration: number; // in seconds
  addedBy?: string;
  isCustom?: boolean;
}

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  phone?: string;
  avatar?: string;
  banner?: string;
  bio?: string;
  customStatus?: string;
  pronouns?: string;
  location?: string;
  birthday?: string;
  discord?: string;
  telegram?: string;
  vk?: string;
  github?: string;
  steam?: string;
  status: UserStatus;
  lastSeen?: string;
  isAdmin?: boolean;
  isModerator?: boolean;
  is2FAEnabled?: boolean;
  twoFASecret?: string;
  createdAt: string;
  level?: number;
  comments?: ProfileComment[];
  isDeleted?: boolean;
  deleteReason?: string;
  isBanned?: boolean;
  banReason?: string;
  banExpiresAt?: string | null; // ISO string for temporary ban expiry or null/undefined for permanent
  isMutedUntil?: string | null; // ISO string for temporary chat timeout
  spamViolationsCount?: number;
  originalName?: string;
  originalBio?: string;
  originalAvatar?: string;
  profileTrack?: MusicTrack;
}

export interface UserSession {
  id: string;
  userId: string;
  device: string;
  browser: string;
  os: string;
  ip: string;
  location?: string;
  lastActive: string;
  isCurrent: boolean;
}

export type AppTheme = 'light' | 'dark' | 'max' | 'black' | 'cyber' | 'green' | 'purple' | 'darkblue';

export interface UserSettings {
  theme: AppTheme;
  fontSize: 'small' | 'medium' | 'large';
  notificationsEnabled: boolean;
  soundEnabled: boolean;
  messagePreview: boolean;
  enterToSend: boolean;
  reducedMotion: boolean;
  density: 'comfortable' | 'compact';
  lastSeenPrivacy: 'everyone' | 'contacts' | 'nobody';
  profilePhotoPrivacy: 'everyone' | 'contacts' | 'nobody';
  whoCanMessageMe: 'everyone' | 'contacts';
  whoCanAddToGroups: 'everyone' | 'contacts';
}

export type ChatType = 'direct' | 'group' | 'channel' | 'saved';

export type MemberRole = 'owner' | 'admin' | 'member';

export interface ChatMember {
  userId: string;
  role: MemberRole;
  joinedAt: string;
  isMuted?: boolean;
  customTitle?: string;
}

export type MessageStatus = 'sending' | 'sent' | 'delivered' | 'read' | 'failed';

export type AttachmentType = 'image' | 'video' | 'audio' | 'voice' | 'document';

export interface Attachment {
  id: string;
  name: string;
  size: number;
  mimeType: string;
  url: string;
  type: AttachmentType;
  duration?: number;
  waveform?: number[];
}

export interface Reaction {
  emoji: string;
  count: number;
  users: string[]; // array of userIds
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  text: string;
  time: string;
  timestamp: number;
  status: MessageStatus;
  replyToId?: string;
  replyToMessage?: {
    id: string;
    senderName: string;
    text: string;
  };
  isEdited?: boolean;
  isPinned?: boolean;
  attachments?: Attachment[];
  reactions?: Reaction[];
  forwardedFrom?: string;
}

export interface Chat {
  id: string;
  type: ChatType;
  name?: string;
  username?: string;
  avatar?: string;
  description?: string;
  members: ChatMember[];
  memberIds: string[];
  ownerId?: string;
  isPinned?: boolean;
  isArchived?: boolean;
  isMuted?: boolean;
  unreadCount: number;
  lastMessage?: Message;
  createdAt: string;
  isPublic?: boolean;
}

export type CallType = 'audio' | 'video';

export type CallState = 
  | 'idle' 
  | 'calling' 
  | 'ringing' 
  | 'accepted' 
  | 'rejected' 
  | 'declined' 
  | 'cancelled' 
  | 'missed' 
  | 'busy' 
  | 'connecting' 
  | 'connected' 
  | 'reconnecting' 
  | 'ended' 
  | 'failed';

export interface CallInfo {
  id: string;
  chatId: string;
  callerId: string;
  callerName: string;
  callerAvatar?: string;
  recipientId: string;
  recipientName: string;
  recipientAvatar?: string;
  type: CallType;
  state: CallState;
  startTime?: number;
  duration?: number;
  createdAt?: string;
  isIncoming?: boolean;
  isMuted?: boolean;
  isVideoOff?: boolean;
  isRemoteMuted?: boolean;
  isRemoteVideoOff?: boolean;
  isSpeakerOn?: boolean;
  facingMode?: 'user' | 'environment';
  connectionQuality?: 'excellent' | 'good' | 'poor' | 'reconnecting';
}

export interface CallLog {
  id: string;
  chatId?: string;
  callerId: string;
  callerName: string;
  callerAvatar?: string;
  recipientId: string;
  recipientName: string;
  recipientAvatar?: string;
  type: CallType;
  direction: 'incoming' | 'outgoing' | 'missed';
  status: 'completed' | 'missed' | 'declined' | 'busy' | 'failed';
  time: string;
  timestamp: number;
  duration: number;
}

export interface Report {
  id: string;
  reporterId: string;
  reporterName: string;
  targetId: string;
  targetType: 'user' | 'message' | 'group' | 'channel';
  reason: string;
  details?: string;
  createdAt: string;
  status: 'pending' | 'reviewed' | 'dismissed';
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorUsername: string;
  authorAvatar?: string;
  text: string;
  createdAt: number;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername: string;
  authorAvatar?: string;
  text: string;
  mediaUrls?: string[];
  createdAt: number;
  likes: string[]; // array of userIds
  reposts: number;
  views: number;
  commentsCount: number;
  tags?: string[];
}

export interface SocialNotification {
  id: string;
  userId: string; // The user who receives the notification
  actorId: string; // The user who performed the action
  actorName: string;
  actorUsername: string;
  actorAvatar?: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  postId?: string;
  postTextSnippet?: string;
  createdAt: number;
  isRead: boolean;
}

export interface Story {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  mediaUrl: string;
  caption?: string;
  createdAt: number;
  expiresAt: number;
  viewers?: string[];
}

