import React, { useState, useEffect, useRef } from 'react';
import { User, ProfileComment, MusicTrack } from '../types';
import { 
  X, Check, Search, MessageSquare, ArrowUpRight, Send, 
  ShieldCheck, Gamepad2, Edit3, Camera, Save, Trash2, 
  Sparkles, CheckCircle2, Phone, Video, Music, Play, 
  Pause, Download, Upload, Disc, Plus, Copy, Share2, 
  MapPin, Calendar, Globe, Award, Heart, Info, Image, 
  Github, Radio, Eye, Layers, Palette
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import { useCall } from '../context/CallContext';
import { useMusic } from '../context/MusicContext';
import { AdminInfoModal } from './AdminInfoModal';
import { AvatarChoiceModal } from './AvatarChoiceModal';
import { StoriesModal } from './StoriesModal';
import { MediaViewer } from './MediaViewer';
import { UserAvatar, DELETED_ACCOUNT_NAME } from './UserAvatar';

interface UserProfileModalProps {
  user: User | null;
  onClose: () => void;
  onMessage?: (user: User) => void;
  onCall?: (user: User) => void;
}

const DEFAULT_BANNERS = [
  { id: 'aurora', name: 'Северное сияние', gradient: 'from-violet-600 via-indigo-600 to-sky-500' },
  { id: 'cyber', name: 'Киберпанк Неон', gradient: 'from-pink-600 via-purple-600 to-cyan-500' },
  { id: 'emerald', name: 'Изумрудный кристалл', gradient: 'from-emerald-600 via-teal-600 to-blue-600' },
  { id: 'sunset', name: 'Закат в Токио', gradient: 'from-amber-500 via-rose-600 to-purple-700' },
  { id: 'obsidian', name: 'Темный обсидиан', gradient: 'from-slate-900 via-zinc-800 to-stone-900' },
  { id: 'royal', name: 'Королевский бархат', gradient: 'from-blue-700 via-indigo-900 to-purple-950' },
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ user, onClose, onMessage, onCall }) => {
  const { user: currentUser, updateProfile, registeredUsers = [] } = useAuth();
  const { getOrCreateDirectChat } = useChat();
  const { startCall } = useCall();
  const {
    playlist,
    currentTrack,
    isPlaying,
    playTrack,
    togglePlay,
    downloadTrack,
    setTrackToProfile,
    removeTrackFromProfile,
    uploadCustomTrack
  } = useMusic();

  const [activeTab, setActiveTab] = useState<'info' | 'music' | 'wall' | 'customize'>('info');
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [comments, setComments] = useState<ProfileComment[]>([]);
  const [newCommentText, setNewCommentText] = useState('');
  const [copiedTag, setCopiedTag] = useState(false);
  
  // Local state for user view
  const [displayUser, setDisplayUser] = useState<User | null>(user);
  
  // Profile Edit State
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editCustomStatus, setEditCustomStatus] = useState('');
  const [editLocation, setEditLocation] = useState('');
  const [editBirthday, setEditBirthday] = useState('');
  const [editDiscord, setEditDiscord] = useState('');
  const [editTelegram, setEditTelegram] = useState('');
  const [editVk, setEditVk] = useState('');
  const [editGithub, setEditGithub] = useState('');
  const [editSteam, setEditSteam] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [editBanner, setEditBanner] = useState('');
  const [editLevel, setEditLevel] = useState<number>(10);
  const [editStatus, setEditStatus] = useState<'online' | 'offline' | 'away'>('online');

  const [showAvatarChoice, setShowAvatarChoice] = useState(false);
  const [showStoriesModal, setShowStoriesModal] = useState(false);
  const [isAddStory, setIsAddStory] = useState(false);
  const [showFullAvatar, setShowFullAvatar] = useState(false);
  const [showMusicPicker, setShowMusicPicker] = useState(false);
  const [downloadingProfileMusic, setDownloadingProfileMusic] = useState(false);
  const [saveToast, setSaveToast] = useState(false);

  const customMusicInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    setDisplayUser(user);
    setEditName(user.name || '');
    setEditUsername(user.username || '');
    setEditBio(user.bio || '');
    setEditCustomStatus(user.customStatus || '');
    setEditLocation(user.location || '');
    setEditBirthday(user.birthday || '');
    setEditDiscord(user.discord || '');
    setEditTelegram(user.telegram || '');
    setEditVk(user.vk || '');
    setEditGithub(user.github || '');
    setEditSteam(user.steam || '');
    setEditAvatar(user.avatar || '');
    setEditBanner(user.banner || 'aurora');
    setEditLevel(user.level || 15);
    setEditStatus(user.status || 'online');

    const saved = localStorage.getItem(`zentora_comments_${user.id}`);
    if (saved) {
      try {
        setComments(JSON.parse(saved));
      } catch {
        setComments([]);
      }
    } else {
      setComments(user.comments || []);
    }
  }, [user]);

  // Handle ESC to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!displayUser) return null;

  const isSelf = currentUser?.id === displayUser.id;
  const activeProfileUser = isSelf && currentUser ? currentUser : displayUser;
  const profileTrack = activeProfileUser.profileTrack;

  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setEditAvatar(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleBannerFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setEditBanner(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCustomMusicUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const newTrack = await uploadCustomTrack(file);
      await setTrackToProfile(newTrack);
      setShowMusicPicker(false);
    } catch (err) {
      console.error(err);
      alert("Ошибка при загрузке трека");
    }
  };

  const handleDownloadProfileTrack = async (track: MusicTrack) => {
    setDownloadingProfileMusic(true);
    await downloadTrack(track);
    setTimeout(() => setDownloadingProfileMusic(false), 1000);
  };

  const handleSaveProfile = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const updatedFields: Partial<User> = {
      name: editName.trim() || displayUser.name,
      username: editUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, '') || displayUser.username,
      bio: editBio.trim(),
      customStatus: editCustomStatus.trim(),
      location: editLocation.trim(),
      birthday: editBirthday.trim(),
      discord: editDiscord.trim(),
      telegram: editTelegram.trim(),
      vk: editVk.trim(),
      github: editGithub.trim(),
      steam: editSteam.trim(),
      avatar: editAvatar || displayUser.avatar,
      banner: editBanner || displayUser.banner || 'aurora',
      level: editLevel,
      status: editStatus
    };

    if (isSelf) {
      updateProfile(updatedFields);
    }

    const updatedUser: User = { ...displayUser, ...updatedFields };
    setDisplayUser(updatedUser);
    localStorage.setItem(`zentora_custom_profile_${displayUser.id}`, JSON.stringify(updatedUser));
    setIsEditing(false);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 3000);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim() || !currentUser) return;

    const newComment: ProfileComment = {
      id: `c_${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorUsername: currentUser.username,
      authorAvatar: currentUser.avatar,
      text: newCommentText.trim(),
      date: new Date().toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
    };

    const updated = [newComment, ...comments];
    setComments(updated);
    localStorage.setItem(`zentora_comments_${displayUser.id}`, JSON.stringify(updated));
    setNewCommentText('');
  };

  const handleDeleteComment = (commentId: string) => {
    const updated = comments.filter(c => c.id !== commentId);
    setComments(updated);
    localStorage.setItem(`zentora_comments_${displayUser.id}`, JSON.stringify(updated));
  };

  const copyUsername = () => {
    navigator.clipboard.writeText(`@${displayUser.username}`);
    setCopiedTag(true);
    setTimeout(() => setCopiedTag(false), 2000);
  };

  const getBannerBackground = () => {
    const currentBanner = isEditing ? editBanner : (displayUser.banner || 'aurora');
    if (currentBanner.startsWith('data:') || currentBanner.startsWith('http')) {
      return { backgroundImage: `url(${currentBanner})`, backgroundSize: 'cover', backgroundPosition: 'center' };
    }
    const preset = DEFAULT_BANNERS.find(b => b.id === currentBanner) || DEFAULT_BANNERS[0];
    return { className: `bg-gradient-to-r ${preset.gradient}` };
  };

  const bannerBg = getBannerBackground();

  return (
    <>
      <input
        type="file"
        ref={avatarInputRef}
        onChange={handleAvatarFileChange}
        accept="image/*"
        className="hidden"
      />
      <input
        type="file"
        ref={bannerInputRef}
        onChange={handleBannerFileChange}
        accept="image/*"
        className="hidden"
      />

      <div 
        onClick={onClose}
        className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md animate-fadeIn select-none overflow-y-auto"
      >
        {/* Main Card Container */}
        <div 
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-2xl bg-[var(--surface)] border border-[var(--border)] rounded-[32px] md:rounded-[36px] shadow-2xl overflow-hidden flex flex-col text-[var(--text-primary)] max-h-[92vh] my-auto animate-scaleUp"
        >
          
          {/* ================= HERO HEADER WITH BANNER ================= */}
          <div className="relative h-44 sm:h-52 w-full shrink-0 overflow-hidden">
            {/* Banner Background */}
            <div 
              className={`w-full h-full transition-all duration-500 ${bannerBg.className || ''}`}
              style={bannerBg.backgroundImage ? bannerBg : undefined}
            >
              {/* Subtle Mesh & Glass Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface)] via-black/20 to-transparent" />
              <div className="absolute inset-0 bg-black/15 backdrop-blur-[1px]" />
            </div>

            {/* Top Bar Actions on Banner */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-black/40 backdrop-blur-md rounded-full text-[11px] font-bold text-white/90 border border-white/15 flex items-center gap-1.5 shadow-sm">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Zentora ID</span>
                </span>
                {saveToast && (
                  <span className="px-3 py-1 bg-emerald-500/90 text-white text-xs font-bold rounded-full animate-fadeIn flex items-center gap-1 shadow-lg">
                    <Check className="w-3.5 h-3.5" />
                    <span>Сохранено!</span>
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                {isSelf && (
                  <button
                    onClick={() => {
                      if (isEditing) {
                        handleSaveProfile();
                      } else {
                        setIsEditing(true);
                        setActiveTab('customize');
                      }
                    }}
                    className="px-3.5 py-1.5 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md border border-white/20 text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                  >
                    {isEditing ? (
                      <>
                        <Save className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Готово</span>
                      </>
                    ) : (
                      <>
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Изменить</span>
                      </>
                    )}
                  </button>
                )}

                <button
                  onClick={onClose}
                  className="p-2 rounded-full bg-black/40 hover:bg-black/60 text-white/90 hover:text-white backdrop-blur-md border border-white/20 transition-all active:scale-95 cursor-pointer"
                  title="Закрыть (Esc)"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Change Banner Button (for owner) */}
            {isSelf && (
              <button
                onClick={() => bannerInputRef.current?.click()}
                className="absolute bottom-3 right-4 px-3 py-1.5 rounded-xl bg-black/50 hover:bg-black/75 text-white/90 hover:text-white backdrop-blur-md border border-white/20 text-[11px] font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                title="Сменить фото обложки"
              >
                <Image className="w-3.5 h-3.5 text-indigo-300" />
                <span>Сменить обложку</span>
              </button>
            )}
          </div>

          {/* ================= AVATAR & IDENTITY OVERLAP ================= */}
          <div className="px-6 relative -mt-16 sm:-mt-20 flex flex-col sm:flex-row sm:items-end justify-between gap-4 z-10 shrink-0">
            
            {/* Avatar with Glow & Ring */}
            <div className="flex items-end gap-4">
              <div className="relative group">
                <div 
                  onClick={() => setShowAvatarChoice(true)}
                  className="relative cursor-pointer rounded-full p-1 bg-[var(--surface)] shadow-2xl border-2 border-[var(--border)] hover:scale-105 transition-transform"
                >
                  <img
                    src={isEditing ? (editAvatar || displayUser.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${displayUser.username}`) : (displayUser.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${displayUser.username}`)}
                    alt={displayUser.name}
                    className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover shadow-inner"
                  />
                  
                  {/* Status Ring Dot */}
                  <span 
                    className={`absolute bottom-2 right-2 w-5 h-5 rounded-full border-3 border-[var(--surface)] shadow-md ${
                      displayUser.status === 'online' 
                        ? 'bg-emerald-500 animate-pulse' 
                        : displayUser.status === 'away' 
                        ? 'bg-amber-400' 
                        : 'bg-zinc-400'
                    }`} 
                    title={displayUser.status === 'online' ? 'В сети' : 'Не в сети'}
                  />

                  {/* Hover Camera Icon */}
                  <div className="absolute inset-0 bg-black/40 rounded-full flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white text-[10px] font-bold">
                    <Camera className="w-5 h-5 mb-0.5" />
                    <span>Сменить</span>
                  </div>
                </div>
              </div>

              {/* Identity Info */}
              <div className="pb-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-[var(--text-primary)] flex items-center gap-1.5">
                    {displayUser.isDeleted ? DELETED_ACCOUNT_NAME : (isEditing ? editName : displayUser.name)}
                  </h1>

                  {/* Verification Badges */}
                  {displayUser.isAdmin && (
                    <span className="px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-400 text-[10px] font-bold flex items-center gap-1" title="Администратор">
                      <CheckCircle2 className="w-3.5 h-3.5 fill-blue-500 text-white" />
                      <span>ADMIN</span>
                    </span>
                  )}
                  {displayUser.isModerator && !displayUser.isAdmin && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold flex items-center gap-1" title="Модератор">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>MOD</span>
                    </span>
                  )}

                  {/* Level Pill */}
                  <span className="px-2.5 py-0.5 rounded-full bg-[var(--surface-hover)] border border-[var(--border)] text-xs font-mono font-bold text-[var(--accent)]">
                    Lvl {isEditing ? editLevel : (displayUser.level || 15)}
                  </span>
                </div>

                {/* Username & Copy Button */}
                <div className="flex items-center gap-2 mt-1">
                  <button 
                    onClick={copyUsername}
                    className="text-xs font-mono text-[var(--accent)] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                    title="Нажмите чтобы скопировать @юзернейм"
                  >
                    <span>@{displayUser.username}</span>
                    {copiedTag ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-[var(--text-secondary)]" />}
                  </button>

                  <span className="text-[var(--text-secondary)]">•</span>

                  <span className="text-xs text-[var(--text-secondary)] flex items-center gap-1">
                    {displayUser.status === 'online' ? (
                      <span className="text-emerald-400 font-semibold">В сети</span>
                    ) : (
                      <span>был(а) недавно</span>
                    )}
                  </span>
                </div>

                {/* Custom Status Quote */}
                {(displayUser.customStatus || editCustomStatus) && (
                  <p className="text-xs text-[var(--text-secondary)] italic mt-1 flex items-center gap-1.5 font-medium">
                    <span>💭</span>
                    <span>{isEditing ? editCustomStatus : displayUser.customStatus}</span>
                  </p>
                )}
              </div>
            </div>

            {/* Quick Contact / Actions Bar */}
            {!displayUser.isDeleted && (
              <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end pb-1">
                <button
                  onClick={async () => {
                    const chatId = await getOrCreateDirectChat({
                      id: displayUser.id,
                      name: displayUser.name,
                      avatar: displayUser.avatar || '',
                      username: displayUser.username
                    });
                    if (onMessage) onMessage(displayUser);
                    onClose();
                  }}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-2xl bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--message-sent-text)] font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Написать</span>
                </button>

                <button
                  onClick={async () => {
                    const chatId = await getOrCreateDirectChat({
                      id: displayUser.id,
                      name: displayUser.name,
                      avatar: displayUser.avatar || '',
                      username: displayUser.username
                    });
                    startCall(chatId, { id: displayUser.id, name: displayUser.name, avatar: displayUser.avatar || '' }, 'audio');
                    onClose();
                  }}
                  className="p-2.5 rounded-2xl bg-[var(--surface-hover)] hover:bg-[var(--border)] border border-[var(--border)] text-[var(--text-primary)] hover:text-emerald-400 active:scale-95 transition-all cursor-pointer"
                  title="Аудиозвонок"
                >
                  <Phone className="w-4 h-4" />
                </button>

                <button
                  onClick={async () => {
                    const chatId = await getOrCreateDirectChat({
                      id: displayUser.id,
                      name: displayUser.name,
                      avatar: displayUser.avatar || '',
                      username: displayUser.username
                    });
                    startCall(chatId, { id: displayUser.id, name: displayUser.name, avatar: displayUser.avatar || '' }, 'video');
                    onClose();
                  }}
                  className="p-2.5 rounded-2xl bg-[var(--surface-hover)] hover:bg-[var(--border)] border border-[var(--border)] text-[var(--text-primary)] hover:text-purple-400 active:scale-95 transition-all cursor-pointer"
                  title="Видеозвонок"
                >
                  <Video className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* ================= NAVIGATION TABS ================= */}
          <div className="px-6 mt-6 border-b border-[var(--border)] flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
            <button
              onClick={() => setActiveTab('info')}
              className={`pb-3 px-3 text-xs font-bold transition-all relative flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'info' 
                  ? 'text-[var(--accent)]' 
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <Info className="w-4 h-4" />
              <span>О профиле</span>
              {activeTab === 'info' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--accent)] rounded-full animate-fadeIn" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('music')}
              className={`pb-3 px-3 text-xs font-bold transition-all relative flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'music' 
                  ? 'text-indigo-400' 
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <Music className="w-4 h-4 text-indigo-400" />
              <span>Музыка</span>
              {profileTrack && (
                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
              )}
              {activeTab === 'music' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500 rounded-full animate-fadeIn" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('wall')}
              className={`pb-3 px-3 text-xs font-bold transition-all relative flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'wall' 
                  ? 'text-[var(--accent)]' 
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>Стена и отзывы</span>
              <span className="px-1.5 py-0.2 rounded-full bg-[var(--surface-hover)] border border-[var(--border)] text-[10px] font-mono">
                {comments.length}
              </span>
              {activeTab === 'wall' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--accent)] rounded-full animate-fadeIn" />
              )}
            </button>

            {isSelf && (
              <button
                onClick={() => setActiveTab('customize')}
                className={`pb-3 px-3 text-xs font-bold transition-all relative flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                  activeTab === 'customize' 
                    ? 'text-amber-400' 
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                <Palette className="w-4 h-4 text-amber-400" />
                <span>Кастомизация</span>
                {activeTab === 'customize' && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full animate-fadeIn" />
                )}
              </button>
            )}
          </div>

          {/* ================= TAB CONTENT SCROLLABLE AREA ================= */}
          <div className="p-6 overflow-y-auto flex-1 min-h-0 space-y-6">
            
            {/* 1. TAB: INFO & OVERVIEW */}
            {activeTab === 'info' && (
              <div className="space-y-6 animate-fadeIn">
                
                {/* Bio Block */}
                <div className="bg-[var(--surface)]/70 border border-[var(--border)] rounded-2xl p-4 shadow-sm">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-secondary)] mb-2 flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5 text-rose-400" />
                    <span>О себе</span>
                  </h3>
                  <p className="text-sm text-[var(--text-primary)] leading-relaxed font-sans whitespace-pre-wrap">
                    {displayUser.bio || 'Пользователь пока не добавил описание о себе.'}
                  </p>
                </div>

                {/* Details Grid (City, Birthday, Level Progress) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="bg-[var(--surface)]/70 border border-[var(--border)] rounded-2xl p-3.5 flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-bold text-[var(--text-secondary)]">Город / Страна</p>
                      <p className="text-xs font-bold text-[var(--text-primary)] mt-0.5">
                        {displayUser.location || 'Планета Земля'}
                      </p>
                    </div>
                  </div>

                  <div className="bg-[var(--surface)]/70 border border-[var(--border)] rounded-2xl p-3.5 flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-bold text-[var(--text-secondary)]">День рождения</p>
                      <p className="text-xs font-bold text-[var(--text-primary)] mt-0.5">
                        {displayUser.birthday || 'Не указан'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Social Integrations Cards */}
                <div className="space-y-3">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-1.5 ml-1">
                    <Globe className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Связь и соцсети</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Telegram */}
                    {displayUser.telegram ? (
                      <a
                        href={`https://${displayUser.telegram.replace('@', 't.me/')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-3 bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] rounded-2xl transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-sky-500/15 text-sky-400 rounded-xl">
                            <Send className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-[var(--text-primary)]">Telegram</p>
                            <p className="text-[11px] text-[var(--text-secondary)] font-mono">{displayUser.telegram}</p>
                          </div>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors" />
                      </a>
                    ) : null}

                    {/* Discord */}
                    {displayUser.discord ? (
                      <a
                        href={`https://${displayUser.discord}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-3 bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] rounded-2xl transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-indigo-500/15 text-indigo-400 rounded-xl">
                            <Gamepad2 className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-[var(--text-primary)]">Discord</p>
                            <p className="text-[11px] text-[var(--text-secondary)] font-mono">{displayUser.discord}</p>
                          </div>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors" />
                      </a>
                    ) : null}

                    {/* VK */}
                    {displayUser.vk ? (
                      <a
                        href={`https://${displayUser.vk.replace('@', 'vk.com/')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-3 bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] rounded-2xl transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-600/15 text-blue-400 rounded-xl">
                            <Globe className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-[var(--text-primary)]">ВКонтакте</p>
                            <p className="text-[11px] text-[var(--text-secondary)] font-mono">{displayUser.vk}</p>
                          </div>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors" />
                      </a>
                    ) : null}

                    {/* GitHub */}
                    {displayUser.github ? (
                      <a
                        href={`https://github.com/${displayUser.github.replace('@', '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-3 bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] rounded-2xl transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-zinc-600/15 text-[var(--text-primary)] rounded-xl">
                            <Github className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-[var(--text-primary)]">GitHub</p>
                            <p className="text-[11px] text-[var(--text-secondary)] font-mono">{displayUser.github}</p>
                          </div>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors" />
                      </a>
                    ) : null}
                  </div>

                  {!displayUser.telegram && !displayUser.discord && !displayUser.vk && !displayUser.github && (
                    <div className="p-4 rounded-2xl bg-[var(--surface)]/40 border border-dashed border-[var(--border)] text-center text-xs text-[var(--text-secondary)]">
                      Соцсети пока не подключены
                    </div>
                  )}
                </div>

                

              </div>
            )}

            {/* 2. TAB: MUSIC IN PROFILE */}
            {activeTab === 'music' && (
              <div className="space-y-6 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-[var(--text-primary)] flex items-center gap-2">
                      <Music className="w-4 h-4 text-indigo-400" />
                      <span>Музыкальный статус профиля</span>
                    </h3>
                    <p className="text-xs text-[var(--text-secondary)]">
                      Любимый трек, который играет в профиле
                    </p>
                  </div>

                  {isSelf && (
                    <button
                      onClick={() => setShowMusicPicker(true)}
                      className="px-3 py-1.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-400 border border-indigo-500/30 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{profileTrack ? 'Сменить трек' : 'Выбрать трек'}</span>
                    </button>
                  )}
                </div>

                {profileTrack ? (
                  <div className="relative overflow-hidden bg-gradient-to-br from-indigo-950/40 via-[var(--surface)] to-purple-950/30 border border-indigo-500/30 rounded-3xl p-5 shadow-xl">
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                      {/* Cover with spinning record */}
                      <div className="relative w-24 h-24 rounded-2xl overflow-hidden shrink-0 shadow-lg border border-white/10">
                        <img
                          src={profileTrack.cover}
                          alt={profileTrack.title}
                          className="w-full h-full object-cover"
                        />
                        {currentTrack?.url === profileTrack.url && isPlaying && (
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                            <Disc className="w-8 h-8 text-white animate-spin" />
                          </div>
                        )}
                      </div>

                      {/* Info & Controls */}
                      <div className="flex-1 text-center sm:text-left min-w-0">
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold uppercase tracking-wider mb-1">
                          <Radio className="w-3 h-3 animate-pulse" />
                          <span>Трек профиля</span>
                        </div>
                        <h4 className="text-base font-extrabold text-[var(--text-primary)] truncate">
                          {profileTrack.title}
                        </h4>
                        <p className="text-xs text-indigo-400 font-semibold truncate mt-0.5">
                          {profileTrack.artist}
                        </p>

                        {/* Controls */}
                        <div className="flex items-center justify-center sm:justify-start gap-2 mt-4">
                          <button
                            onClick={() => {
                              if (currentTrack?.url === profileTrack.url) {
                                togglePlay();
                              } else {
                                playTrack(profileTrack);
                              }
                            }}
                            className="px-5 py-2 rounded-2xl bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/30 active:scale-95 transition-all cursor-pointer"
                          >
                            {currentTrack?.url === profileTrack.url && isPlaying ? (
                              <>
                                <Pause className="w-4 h-4 fill-current" />
                                <span>Пауза</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-4 h-4 fill-current ml-0.5" />
                                <span>Слушать</span>
                              </>
                            )}
                          </button>

                          <button
                            onClick={() => handleDownloadProfileTrack(profileTrack)}
                            disabled={downloadingProfileMusic}
                            className="p-2 rounded-2xl bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-emerald-400 hover:border-emerald-500/40 transition-all cursor-pointer"
                            title="Скачать трек (MP3)"
                          >
                            <Download className={`w-4 h-4 ${downloadingProfileMusic ? 'animate-bounce text-emerald-400' : ''}`} />
                          </button>

                          {isSelf && (
                            <button
                              onClick={() => removeTrackFromProfile()}
                              className="p-2 rounded-2xl bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-red-400 hover:border-red-500/40 transition-all cursor-pointer"
                              title="Удалить из профиля"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-[var(--surface)]/50 border border-dashed border-[var(--border)] rounded-3xl p-8 text-center flex flex-col items-center justify-center gap-3">
                    <div className="w-14 h-14 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                      <Music className="w-7 h-7" />
                    </div>
                    <div>
                      <p className="font-bold text-sm text-[var(--text-primary)]">Трек не прикреплен</p>
                      <p className="text-xs text-[var(--text-secondary)] mt-1">
                        Прикрепите любимую песню, чтобы гости вашего профиля могли её послушать
                      </p>
                    </div>
                    {isSelf && (
                      <button
                        onClick={() => setShowMusicPicker(true)}
                        className="mt-2 px-5 py-2.5 rounded-2xl bg-indigo-500 text-white text-xs font-bold hover:bg-indigo-600 shadow-lg shadow-indigo-500/25 transition-all cursor-pointer flex items-center gap-2"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Выбрать музыку</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* 3. TAB: WALL & COMMENTS */}
            {activeTab === 'wall' && (
              <div className="space-y-4 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-[var(--text-primary)]">
                    Записи на стене
                  </h3>
                  <span className="text-xs text-[var(--text-secondary)] font-mono">
                    Всего: {comments.length}
                  </span>
                </div>

                {/* Add Comment Input */}
                <form onSubmit={handleAddComment} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Написать на стене профиля..."
                    value={newCommentText}
                    onChange={e => setNewCommentText(e.target.value)}
                    className="flex-1 px-4 py-3 rounded-2xl bg-[var(--surface)] border border-[var(--border)] text-xs text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                  />
                  <button
                    type="submit"
                    disabled={!newCommentText.trim()}
                    className="px-5 py-3 rounded-2xl bg-[var(--accent)] text-[var(--message-sent-text)] font-bold text-xs disabled:opacity-40 hover:opacity-90 active:scale-95 transition-all shrink-0 flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Отправить</span>
                  </button>
                </form>

                {/* Wall List */}
                <div className="space-y-3 pt-2">
                  {comments.length === 0 ? (
                    <div className="p-8 rounded-2xl bg-[var(--surface)]/40 border border-dashed border-[var(--border)] text-center text-xs text-[var(--text-secondary)]">
                      Стена пока пуста. Оставьте первый комментарий!
                    </div>
                  ) : (
                    comments.map((c, idx) => (
                      <div key={c.id || `wall-comment-${idx}`} className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-4 flex items-start gap-3.5 group relative hover:border-[var(--accent)]/30 transition-all">
                        <img
                          src={c.authorAvatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${c.authorUsername}`}
                          alt={c.authorName}
                          className="w-10 h-10 rounded-full object-cover border border-[var(--border)] shrink-0"
                        />
                        <div className="flex-1 min-w-0 pr-6">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-xs text-[var(--text-primary)] truncate">{c.authorName}</span>
                            <span className="text-[10px] text-[var(--text-secondary)] font-mono shrink-0">{c.date}</span>
                          </div>
                          <p className="text-xs text-[var(--text-primary)] mt-1.5 break-words leading-relaxed">{c.text}</p>
                        </div>

                        {(currentUser?.id === c.authorId || isSelf) && (
                          <button
                            onClick={() => handleDeleteComment(c.id)}
                            className="absolute top-3.5 right-3.5 p-1.5 text-[var(--text-secondary)] hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg hover:bg-[var(--surface-hover)] cursor-pointer"
                            title="Удалить запись"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* 4. TAB: CUSTOMIZE (ONLY FOR OWNER) */}
            {activeTab === 'customize' && isSelf && (
              <form onSubmit={handleSaveProfile} className="space-y-6 animate-fadeIn">
                
                {/* Banner Presets */}
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)] block">
                    Выберите стиль обложки профиля:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {DEFAULT_BANNERS.map(b => (
                      <button
                        type="button"
                        key={b.id}
                        onClick={() => setEditBanner(b.id)}
                        className={`h-16 rounded-2xl bg-gradient-to-r ${b.gradient} p-2 flex flex-col justify-end text-left border-2 transition-all cursor-pointer ${
                          editBanner === b.id ? 'border-white ring-2 ring-[var(--accent)] scale-[1.02]' : 'border-transparent opacity-80 hover:opacity-100'
                        }`}
                      >
                        <span className="text-[10px] font-bold text-white drop-shadow-md">{b.name}</span>
                      </button>
                    ))}
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => bannerInputRef.current?.click()}
                      className="w-full py-2.5 px-4 rounded-xl bg-[var(--surface-hover)] border border-[var(--border)] text-xs font-bold text-[var(--text-primary)] hover:bg-[var(--accent)] hover:text-[var(--message-sent-text)] transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Загрузить собственное фото на обложку</span>
                    </button>
                  </div>
                </div>

                {/* Identity Inputs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1">Имя в профиле:</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={e => setEditName(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-2xl bg-[var(--input)] border border-[var(--border)] text-xs font-bold text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                      placeholder="Ваше имя"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1">Юзернейм (@tag):</label>
                    <input
                      type="text"
                      value={editUsername}
                      onChange={e => setEditUsername(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-2xl bg-[var(--input)] border border-[var(--border)] text-xs font-mono text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                      placeholder="username"
                      required
                    />
                  </div>
                </div>

                {/* Custom Status Quote */}
                <div>
                  <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1">Кастомный статус (мысли/цитата):</label>
                  <input
                    type="text"
                    value={editCustomStatus}
                    onChange={e => setEditCustomStatus(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-[var(--input)] border border-[var(--border)] text-xs text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                    placeholder="Например: 🎧 В наушниках и на своей волне"
                  />
                </div>

                {/* Bio */}
                <div>
                  <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1">О себе (Bio):</label>
                  <textarea
                    rows={3}
                    value={editBio}
                    onChange={e => setEditBio(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-2xl bg-[var(--input)] border border-[var(--border)] text-xs text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] resize-none"
                    placeholder="Расскажите о себе, своих увлечениях и проектах..."
                  />
                </div>

                {/* Location & Birthday */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1">Город / Страна:</label>
                    <input
                      type="text"
                      value={editLocation}
                      onChange={e => setEditLocation(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-2xl bg-[var(--input)] border border-[var(--border)] text-xs text-[var(--text-primary)]"
                      placeholder="Москва / Санкт-Петербург"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1">День рождения:</label>
                    <input
                      type="text"
                      value={editBirthday}
                      onChange={e => setEditBirthday(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-2xl bg-[var(--input)] border border-[var(--border)] text-xs text-[var(--text-primary)]"
                      placeholder="15 июля"
                    />
                  </div>
                </div>

                {/* Socials Grid */}
                <div className="space-y-3">
                  <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block">Контакты и социальные сети:</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      type="text"
                      value={editTelegram}
                      onChange={e => setEditTelegram(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--input)] border border-[var(--border)] text-xs font-mono text-[var(--text-primary)]"
                      placeholder="Telegram: @username или t.me/..."
                    />
                    <input
                      type="text"
                      value={editDiscord}
                      onChange={e => setEditDiscord(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--input)] border border-[var(--border)] text-xs font-mono text-[var(--text-primary)]"
                      placeholder="Discord: username#0000"
                    />
                    <input
                      type="text"
                      value={editVk}
                      onChange={e => setEditVk(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--input)] border border-[var(--border)] text-xs font-mono text-[var(--text-primary)]"
                      placeholder="ВКонтакте: vk.com/id..."
                    />
                    <input
                      type="text"
                      value={editGithub}
                      onChange={e => setEditGithub(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--input)] border border-[var(--border)] text-xs font-mono text-[var(--text-primary)]"
                      placeholder="GitHub: github.com/..."
                    />
                  </div>
                </div>

                {/* Save Button */}
                <div className="pt-4 border-t border-[var(--border)] flex gap-3">
                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-2xl bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--message-sent-text)] font-bold text-xs flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Сохранить изменения профиля</span>
                  </button>
                </div>
              </form>
            )}

          </div>

        </div>
      </div>

      {/* Admin Info Modal */}
      <AdminInfoModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        adminName={displayUser.name}
      />

      {/* Avatar Choice Modal */}
      {showAvatarChoice && displayUser && (
        <AvatarChoiceModal
          user={displayUser}
          isSelf={isSelf}
          onClose={() => setShowAvatarChoice(false)}
          onViewAvatar={() => {
            if (isSelf) {
              avatarInputRef.current?.click();
            } else {
              setShowFullAvatar(true);
            }
          }}
          onOpenStories={(addStory) => {
            setIsAddStory(!!addStory);
            setShowStoriesModal(true);
          }}
        />
      )}

      {/* Stories Modal */}
      {showStoriesModal && currentUser && (
        <StoriesModal
          currentUser={currentUser}
          isOpen={showStoriesModal}
          initialAdd={isAddStory}
          onClose={() => setShowStoriesModal(false)}
        />
      )}

      {/* Full Size Avatar Viewer */}
      {showFullAvatar && displayUser && (
        <MediaViewer
          attachment={{
            id: 'full_avatar',
            type: 'image',
            url: displayUser.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${displayUser.username}`,
            name: displayUser.name
          }}
          allAttachments={[]}
          onClose={() => setShowFullAvatar(false)}
        />
      )}

      {/* Music Picker Modal (Выбор трека в профиль) */}
      {showMusicPicker && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-3xl p-5 shadow-2xl flex flex-col max-h-[85vh] animate-scaleUp text-[var(--text-primary)]">
            <div className="flex items-center justify-between pb-3 border-b border-[var(--border)]">
              <div className="flex items-center gap-2">
                <Music className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-sm text-[var(--text-primary)]">Выбрать музыку для профиля</h3>
              </div>
              <button
                onClick={() => setShowMusicPicker(false)}
                className="p-1.5 rounded-full hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Custom Upload Button */}
            <div className="my-3">
              <input
                type="file"
                ref={customMusicInputRef}
                accept="audio/*,.mp3,.wav,.ogg"
                onChange={handleCustomMusicUpload}
                className="hidden"
              />
              <button
                onClick={() => customMusicInputRef.current?.click()}
                className="w-full py-2.5 px-4 rounded-2xl bg-[var(--accent)] text-[var(--message-sent-text)] font-bold text-xs flex items-center justify-center gap-2 shadow-md hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Загрузить свой MP3 файл</span>
              </button>
            </div>

            <p className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-secondary)] mb-2">
              Или выберите из медиатеки:
            </p>

            {/* Playlist list */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 no-scrollbar min-h-0">
              {playlist.map((track) => {
                const isSelected = activeProfileUser.profileTrack?.id === track.id;
                const isCur = currentTrack?.id === track.id;
                return (
                  <div
                    key={track.id}
                    className={`flex items-center justify-between p-2.5 rounded-2xl border transition-all ${
                      isSelected
                        ? 'border-indigo-500 bg-indigo-500/10'
                        : 'border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-hover)]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <button
                        onClick={() => {
                          if (isCur) {
                            togglePlay();
                          } else {
                            playTrack(track);
                          }
                        }}
                        className="w-8 h-8 rounded-lg bg-[var(--accent)] text-[var(--message-sent-text)] flex items-center justify-center shrink-0 cursor-pointer shadow-sm"
                      >
                        {isCur && isPlaying ? (
                          <Pause className="w-3.5 h-3.5 fill-current" />
                        ) : (
                          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                        )}
                      </button>

                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-xs text-[var(--text-primary)] truncate">
                          {track.title}
                        </p>
                        <p className="text-[10px] text-[var(--text-secondary)] truncate">
                          {track.artist}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={async () => {
                        await setTrackToProfile(track);
                        setShowMusicPicker(false);
                      }}
                      className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-500 text-white shadow-sm'
                          : 'bg-[var(--surface-hover)] text-[var(--text-primary)] hover:bg-indigo-500 hover:text-white'
                      }`}
                    >
                      {isSelected ? 'Выбран' : 'Выбрать'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
