import React, { useState, useEffect, useRef } from 'react';
import { X, Plus, ChevronLeft, ChevronRight, Heart, Camera, Image, Trash2, RefreshCw, UploadCloud } from 'lucide-react';
import { Story, User } from '../types';
import { db } from '../lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy } from 'firebase/firestore';

interface StoriesModalProps {
  currentUser: User;
  isOpen: boolean;
  initialAdd?: boolean;
  onClose: () => void;
}

export const StoriesModal: React.FC<StoriesModalProps> = ({ currentUser, isOpen, initialAdd = false, onClose }) => {
  const [stories, setStories] = useState<Story[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAdding, setIsAdding] = useState(initialAdd);
  const [mediaUrl, setMediaUrl] = useState('');
  const [caption, setCaption] = useState('');

  // Camera capture state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraFileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setIsAdding(initialAdd);
    } else {
      stopCamera();
    }
  }, [isOpen, initialAdd]);

  useEffect(() => {
    if (!isOpen) return;
    const q = query(collection(db, 'stories'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: Story[] = [];
      snapshot.forEach(doc => {
        list.push({ id: doc.id, ...doc.data() } as Story);
      });
      setStories(list);
    }, (err) => {
      console.log('Stories sync fallback:', err);
    });
    return () => unsubscribe();
  }, [isOpen]);

  // Clean up camera stream on unmount or mode switch
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraActive(false);
    setCameraError(null);
  };

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      mediaStreamRef.current = stream;
      setIsCameraActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error('Camera access failed:', err);
      setCameraError('Не удалось получить доступ к камере. Используйте загрузку из галереи.');
      setIsCameraActive(false);
    }
  };

  const takePhotoFromCamera = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setMediaUrl(dataUrl);
      stopCamera();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 25 * 1024 * 1024) {
      alert('Размер файла превышает 25 МБ. Пожалуйста, выберите меньший файл.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setMediaUrl(event.target.result as string);
        stopCamera();
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePostStory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaUrl.trim()) return;
    try {
      await addDoc(collection(db, 'stories'), {
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${currentUser.username}`,
        mediaUrl: mediaUrl.trim(),
        caption: caption.trim(),
        createdAt: Date.now(),
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
        viewers: []
      });
      setMediaUrl('');
      setCaption('');
      setIsAdding(false);
      stopCamera();
    } catch (err) {
      console.error('Failed to post story', err);
    }
  };

  if (!isOpen) return null;

  const currentStory = stories[currentIndex];
  const isVideoMedia = !!(mediaUrl && (mediaUrl.startsWith('data:video') || mediaUrl.match(/\.(mp4|webm|mov)$/i)));

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 backdrop-blur-md animate-fadeIn">
      {/* Offscreen Canvas for Photo Capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Close Modal Button */}
      <button 
        onClick={() => {
          stopCamera();
          onClose();
        }}
        className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all z-50"
      >
        <X className="w-6 h-6" />
      </button>

      {isAdding ? (
        <div className="w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-3xl p-6 shadow-2xl text-[var(--text-primary)] max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">Опубликовать историю</h3>
            <span className="text-xs text-[var(--text-secondary)]">24 часа</span>
          </div>

          {/* Hidden File Inputs */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept="image/*,video/*"
            className="hidden"
          />
          <input
            type="file"
            ref={cameraFileInputRef}
            onChange={handleFileSelect}
            accept="image/*"
            capture="environment"
            className="hidden"
          />

          {/* Live Camera Viewfinder */}
          {isCameraActive ? (
            <div className="relative w-full aspect-[3/4] bg-black rounded-2xl overflow-hidden mb-4 border border-[var(--border)] flex flex-col justify-between">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 inset-x-0 flex items-center justify-center gap-4 z-10 px-4">
                <button
                  type="button"
                  onClick={stopCamera}
                  className="px-4 py-2.5 rounded-xl bg-black/60 text-white text-xs font-bold hover:bg-black/80 backdrop-blur-md"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  onClick={takePhotoFromCamera}
                  className="w-14 h-14 rounded-full bg-white border-4 border-emerald-500 shadow-2xl flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
                  title="Сделать фото"
                >
                  <div className="w-10 h-10 rounded-full bg-emerald-500" />
                </button>
              </div>
            </div>
          ) : mediaUrl ? (
            /* Media Preview Area */
            <div className="relative w-full aspect-[3/4] bg-black rounded-2xl overflow-hidden mb-4 border border-[var(--border)] group">
              {isVideoMedia ? (
                <video src={mediaUrl} controls autoPlay loop className="w-full h-full object-cover" />
              ) : (
                <img src={mediaUrl} alt="Preview" className="w-full h-full object-cover" />
              )}
              <button
                type="button"
                onClick={() => setMediaUrl('')}
                className="absolute top-3 right-3 p-2 rounded-full bg-red-600 text-white shadow-lg hover:bg-red-700 transition-colors"
                title="Удалить выбранное медиа"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ) : (
            /* Choose Source Buttons (Camera / Gallery) */
            <div className="grid grid-cols-2 gap-3 mb-4">
              <button
                type="button"
                onClick={() => {
                  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    startCamera();
                  } else {
                    cameraFileInputRef.current?.click();
                  }
                }}
                className="flex flex-col items-center justify-center gap-2.5 p-6 rounded-2xl bg-[var(--background)] border border-[var(--border)] hover:border-[var(--accent)] hover:bg-[var(--surface-hover)] transition-all text-center group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-full bg-[var(--accent)]/10 text-[var(--accent)] flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Camera className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm font-bold">Снять фото</p>
                  <p className="text-[10px] text-[var(--text-secondary)] mt-0.5">Включить камеру</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center justify-center gap-2.5 p-6 rounded-2xl bg-[var(--background)] border border-[var(--border)] hover:border-[var(--accent)] hover:bg-[var(--surface-hover)] transition-all text-center group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Image className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm font-bold">Из галереи</p>
                  <p className="text-[10px] text-[var(--text-secondary)] mt-0.5">Фото или видео</p>
                </div>
              </button>
            </div>
          )}

          {cameraError && (
            <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-500 text-xs text-center font-medium">
              {cameraError}
            </div>
          )}

          <form onSubmit={handlePostStory} className="space-y-4">
            {/* Direct URL Fallback input */}
            {!mediaUrl && !isCameraActive && (
              <div>
                <label className="text-xs font-bold text-[var(--text-secondary)] mb-1 block">Или вставьте ссылку на медиа</label>
                <input
                  type="url"
                  placeholder="https://..."
                  value={mediaUrl}
                  onChange={e => setMediaUrl(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-[var(--background)] border border-[var(--border)] text-xs focus:outline-none focus:border-[var(--accent)]"
                />
              </div>
            )}

            <div>
              <label className="text-xs font-bold text-[var(--text-secondary)] mb-1 block">Подпись к истории</label>
              <input
                type="text"
                placeholder="Мой яркий день..."
                value={caption}
                onChange={e => setCaption(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl bg-[var(--background)] border border-[var(--border)] text-sm focus:outline-none focus:border-[var(--accent)]"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  stopCamera();
                  setIsAdding(false);
                }}
                className="flex-1 py-3 rounded-2xl bg-[var(--surface-hover)] text-sm font-bold hover:bg-[var(--border)] transition-colors"
              >
                Отмена
              </button>
              <button
                type="submit"
                disabled={!mediaUrl}
                className="flex-1 py-3 rounded-2xl bg-[var(--accent)] text-white text-sm font-bold shadow-lg hover:opacity-90 disabled:opacity-40 transition-opacity"
              >
                Опубликовать
              </button>
            </div>
          </form>
        </div>
      ) : stories.length === 0 ? (
        <div className="text-center text-white space-y-4">
          <p className="text-lg font-medium opacity-80">Пока нет активных историй</p>
          <button
            onClick={() => setIsAdding(true)}
            className="px-6 py-3 rounded-2xl bg-[var(--accent)] text-white font-bold shadow-lg hover:opacity-95 flex items-center gap-2 mx-auto"
          >
            <Plus className="w-5 h-5" /> Добавить историю
          </button>
        </div>
      ) : currentStory ? (
        <div className="relative w-full max-w-sm h-[80vh] bg-neutral-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between border border-white/10">
          {/* Top Progress / Author info */}
          <div className="absolute top-0 inset-x-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={currentStory.userAvatar} alt={currentStory.userName} className="w-10 h-10 rounded-full object-cover border-2 border-[var(--accent)]" />
              <div>
                <p className="text-white font-bold text-sm">{currentStory.userName}</p>
                <p className="text-xs text-white/60 font-mono">{new Date(currentStory.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
              </div>
            </div>
            <button
              onClick={() => setIsAdding(true)}
              className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold flex items-center gap-1.5 transition-colors backdrop-blur-md"
            >
              <Plus className="w-4 h-4" /> Своя
            </button>
          </div>

          {/* Media Content */}
          <div className="absolute inset-0 flex items-center justify-center bg-black">
            {currentStory && currentStory.mediaUrl && (currentStory.mediaUrl.startsWith('data:video') || currentStory.mediaUrl.match(/\.(mp4|webm|mov)$/i)) ? (
              <video src={currentStory.mediaUrl} autoPlay loop muted playsInline className="w-full h-full object-cover" />
            ) : (
              <img 
                src={currentStory?.mediaUrl || ''} 
                alt="Story" 
                className="w-full h-full object-cover" 
                onError={(e)=>{(e.target as HTMLImageElement).src='https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe';}} 
              />
            )}
          </div>

          {/* Caption & Navigation */}
          {currentStory.caption && (
            <div className="absolute bottom-20 inset-x-4 p-4 rounded-2xl bg-black/50 backdrop-blur-md text-white text-center text-sm font-medium">
              {currentStory.caption}
            </div>
          )}

          {/* Navigation arrows */}
          {currentIndex > 0 && (
            <button
              onClick={() => setCurrentIndex(currentIndex - 1)}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60 transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}
          {currentIndex < stories.length - 1 && (
            <button
              onClick={() => setCurrentIndex(currentIndex + 1)}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60 transition-colors"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          )}

          {/* Footer reaction */}
          <div className="absolute bottom-4 inset-x-4 flex items-center gap-3 z-10">
            <input
              type="text"
              placeholder="Ответить на историю..."
              className="flex-1 py-3 px-4 rounded-2xl bg-white/20 backdrop-blur-md text-white text-sm placeholder-white/60 focus:outline-none border border-white/20"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  alert('Ответ отправлен автору истории!');
                  (e.target as HTMLInputElement).value = '';
                }
              }}
            />
            <button
              onClick={() => alert('❤️ История отмечена лайком!')}
              className="p-3 rounded-2xl bg-white/20 backdrop-blur-md text-white hover:bg-red-500/80 transition-colors"
            >
              <Heart className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
};
