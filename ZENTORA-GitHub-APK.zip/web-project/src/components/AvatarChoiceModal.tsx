import React from 'react';
import { X, Image, Film, Plus } from 'lucide-react';
import { User } from '../types';

interface AvatarChoiceModalProps {
  user: User | { id?: string; name: string; avatar?: string; username?: string };
  isSelf: boolean;
  onClose: () => void;
  onViewAvatar: () => void;
  onOpenStories: (addStory?: boolean) => void;
}

export const AvatarChoiceModal: React.FC<AvatarChoiceModalProps> = ({
  user,
  isSelf,
  onClose,
  onViewAvatar,
  onOpenStories,
}) => {
  const avatarUrl = user.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${user.name}`;

  return (
    <div className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-[var(--surface)] border border-[var(--border)] rounded-3xl p-6 shadow-2xl relative text-[var(--text-primary)]">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* User Info Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <img
            src={avatarUrl}
            alt={user.name}
            className="w-20 h-20 rounded-full object-cover border-4 border-[var(--accent)] shadow-md mb-3"
          />
          <h3 className="font-bold text-lg text-[var(--text-primary)]">{user.name}</h3>
          {user.username && (
            <p className="text-xs text-[var(--accent)] font-mono">@{user.username}</p>
          )}
        </div>

        {/* Action Choice Buttons */}
        <div className="space-y-3">
          {/* Avatar Option */}
          <button
            onClick={() => {
              onClose();
              onViewAvatar();
            }}
            className="w-full p-4 rounded-2xl bg-[var(--background)] border border-[var(--border)] hover:border-[var(--accent)] flex items-center gap-4 transition-all text-left group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold group-hover:scale-110 transition-transform">
              <Image className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-sm text-[var(--text-primary)]">
                {isSelf ? 'Аватарка профиля' : 'Посмотреть аватарку'}
              </p>
              <p className="text-xs text-[var(--text-secondary)]">
                {isSelf ? 'Просмотреть или изменить фото' : 'Открыть изображение во весь экран'}
              </p>
            </div>
          </button>

          {/* Story Option */}
          <button
            onClick={() => {
              onClose();
              onOpenStories(false);
            }}
            className="w-full p-4 rounded-2xl bg-[var(--background)] border border-[var(--border)] hover:border-[var(--accent)] flex items-center gap-4 transition-all text-left group"
          >
            <div className="w-10 h-10 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center font-bold group-hover:scale-110 transition-transform">
              <Film className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm text-[var(--text-primary)]">История</p>
              <p className="text-xs text-[var(--text-secondary)]">
                Смотреть историю {isSelf ? 'или выложить новую' : 'пользователя'}
              </p>
            </div>
          </button>

          {/* Add Story button for self */}
          {isSelf && (
            <button
              onClick={() => {
                onClose();
                onOpenStories(true);
              }}
              className="w-full py-3 px-4 rounded-2xl bg-[var(--accent)] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg hover:opacity-90 transition-opacity"
            >
              <Plus className="w-4 h-4" />
              <span>Опубликовать новую историю</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
