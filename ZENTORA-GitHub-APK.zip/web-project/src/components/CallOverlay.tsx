import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PhoneOff, 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Volume2, 
  VolumeX, 
  SwitchCamera, 
  Maximize2, 
  Minimize2, 
  UserPlus, 
  MoreHorizontal, 
  Share2, 
  Upload,
  Check,
  ChevronDown,
  Sparkles,
  Lock,
  Tv,
  Eye,
  EyeOff
} from 'lucide-react';
import { useCall } from '../context/CallContext';

export const CallOverlay: React.FC = () => {
  const {
    activeCall,
    localStream,
    remoteStream,
    isMuted,
    isVideoOff,
    isSpeakerOn,
    isMinimized,
    callDuration,
    connectionQuality,
    endCall,
    toggleMute,
    toggleVideo,
    switchCamera,
    toggleSpeaker,
    setMinimized
  } = useCall();

  const remoteAudioRef = useRef<HTMLAudioElement>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPipSwapped, setIsPipSwapped] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showShareToast, setShowShareToast] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [areControlsHidden, setAreControlsHidden] = useState(false);

  // Attach remote stream to audio element (ensures audio works in both audio calls & video calls)
  useEffect(() => {
    if (remoteAudioRef.current && remoteStream) {
      remoteAudioRef.current.srcObject = remoteStream;
      remoteAudioRef.current.play().catch(e => console.warn('Remote audio playback:', e));
    }
  }, [remoteStream]);

  // Handle speaker on/off
  useEffect(() => {
    if (remoteAudioRef.current) {
      remoteAudioRef.current.muted = !isSpeakerOn;
    }
  }, [isSpeakerOn]);

  // Attach local stream to video element
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream, activeCall?.type, isVideoOff]);

  // Attach remote stream to video element
  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream, activeCall?.type]);

  if (!activeCall) return null;

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    const hrs = Math.floor(mins / 60);
    if (hrs > 0) {
      return `${hrs.toString().padStart(2, '0')}:${(mins % 60).toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusText = () => {
    switch (activeCall.state) {
      case 'calling':
        return 'Исходящий звонок...';
      case 'ringing':
        return 'Соединение...';
      case 'accepted':
      case 'connecting':
        return 'Соединение...';
      case 'reconnecting':
        return 'Переподключение...';
      case 'declined':
      case 'rejected':
        return 'Отклонён';
      case 'cancelled':
        return 'Отменён';
      case 'missed':
        return 'Нет ответа';
      case 'busy':
        return 'Абонент занят';
      case 'ended':
        return 'Звонок завершён';
      case 'failed':
        return 'Ошибка соединения';
      case 'connected':
        return formatDuration(callDuration);
      default:
        return 'Соединение...';
    }
  };

  const isVideoCall = activeCall.type === 'video';
  const otherPersonName = activeCall.isIncoming ? activeCall.callerName : activeCall.recipientName;
  const otherPersonAvatar = (activeCall.isIncoming ? activeCall.callerAvatar : activeCall.recipientAvatar) || 
    `https://api.dicebear.com/7.x/identicon/svg?seed=${otherPersonName}`;

  // Share Screen / Share Call Handler
  const handleShare = async () => {
    if (navigator.mediaDevices && 'getDisplayMedia' in navigator.mediaDevices && !isScreenSharing) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const screenTrack = screenStream.getVideoTracks()[0];
        if (screenTrack && localStream) {
          const senderTrack = localStream.getVideoTracks()[0];
          if (senderTrack) {
            localStream.removeTrack(senderTrack);
            senderTrack.stop();
          }
          localStream.addTrack(screenTrack);
          setIsScreenSharing(true);
          screenTrack.onended = () => {
            setIsScreenSharing(false);
          };
        }
      } catch (err) {
        // Fallback: copy link
        copyCallLink();
      }
    } else {
      copyCallLink();
    }
  };

  const copyCallLink = () => {
    try {
      navigator.clipboard.writeText(window.location.href);
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 2500);
    } catch (e) {
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 2500);
    }
  };

  const toggleFullscreenHandler = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Mini Floating PiP Widget if minimized
  if (isMinimized) {
    return (
      <>
        <audio ref={remoteAudioRef} autoPlay playsInline className="hidden" />
        <motion.div
          drag
          dragConstraints={{ left: 10, right: window.innerWidth - 220, top: 10, bottom: window.innerHeight - 100 }}
          className="fixed bottom-6 right-6 z-[200] bg-slate-900/95 backdrop-blur-xl border border-white/20 rounded-3xl p-3 shadow-2xl flex items-center gap-3 cursor-pointer text-white ring-1 ring-cyan-500/30 select-none hover:border-cyan-400 transition-colors"
          onClick={() => setMinimized(false)}
        >
          <div className="relative">
            <img src={otherPersonAvatar} alt={otherPersonName} className="w-11 h-11 rounded-full object-cover border border-cyan-500/40" />
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-900 animate-pulse" />
          </div>
          <div className="flex-1 min-w-[90px]">
            <p className="font-bold text-xs truncate max-w-[110px]">{otherPersonName}</p>
            <p className="text-[11px] font-mono text-emerald-400">{getStatusText()}</p>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); endCall(); }}
            className="w-9 h-9 rounded-full bg-red-500/90 hover:bg-red-600 flex items-center justify-center text-white shadow-lg transition-transform active:scale-95 shrink-0"
            title="Завершить"
          >
            <PhoneOff className="w-4 h-4" />
          </button>
        </motion.div>
      </>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 z-[150] bg-[#0f141c] text-white flex flex-col justify-between overflow-hidden select-none"
      >
        {/* Dedicated Audio Element for Voice Stream Playback */}
        <audio ref={remoteAudioRef} autoPlay playsInline className="hidden" />

        {/* ========================================================================= */}
        {/* MODE 1: VIDEO CALL LAYOUT (Matching Screenshot 1: Fullscreen + Bottom Right PiP) */}
        {/* ========================================================================= */}
        {isVideoCall ? (
          <div 
            className="absolute inset-0 w-full h-full bg-black cursor-pointer"
            onClick={() => setAreControlsHidden(prev => !prev)}
          >
            {/* Fullscreen Remote Video feed */}
            <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
              <video
                ref={isPipSwapped ? localVideoRef : remoteVideoRef}
                autoPlay
                playsInline
                muted={isPipSwapped}
                className={`w-full h-full object-cover ${isPipSwapped ? 'scale-x-[-1]' : ''}`}
              />

              {/* Avatar fallback if remote camera is off or no video track */}
              {(!isPipSwapped && (activeCall.isRemoteVideoOff || !remoteStream)) && (
                <div className="absolute inset-0 bg-[#0c1017]/95 flex flex-col items-center justify-center">
                  <div className="relative mb-6">
                    <img
                      src={otherPersonAvatar}
                      alt={otherPersonName}
                      className="w-36 h-36 rounded-full object-cover border-4 border-slate-700/80 shadow-2xl"
                    />
                    <div className="absolute inset-0 rounded-full border-4 border-cyan-500/40 animate-ping" />
                  </div>
                  <h3 className="text-2xl font-bold">{otherPersonName}</h3>
                  <p className="text-sm text-slate-400 mt-1">Камера выключена</p>
                </div>
              )}
            </div>

            {/* Bottom-Right Floating PiP Preview (matching screenshot 1) */}
            <motion.div
              drag
              dragConstraints={{ left: 16, right: window.innerWidth - 150, top: 70, bottom: window.innerHeight - 200 }}
              onClick={(e) => {
                e.stopPropagation();
                setIsPipSwapped(!isPipSwapped);
              }}
              animate={{
                bottom: areControlsHidden ? '24px' : '128px',
                right: '16px'
              }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="absolute w-32 h-44 sm:w-36 sm:h-52 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20 bg-slate-900 cursor-pointer backdrop-blur-md z-20 group hover:border-cyan-400 transition-colors"
            >
              <video
                ref={isPipSwapped ? remoteVideoRef : localVideoRef}
                autoPlay
                playsInline
                muted={!isPipSwapped}
                className={`w-full h-full object-cover ${!isPipSwapped ? 'scale-x-[-1]' : ''}`}
              />
              {((isPipSwapped && activeCall.isRemoteVideoOff) || (!isPipSwapped && isVideoOff)) && (
                <div className="absolute inset-0 bg-slate-900 flex items-center justify-center text-xs text-slate-400">
                  <VideoOff className="w-6 h-6 text-slate-500" />
                </div>
              )}
              <div className="absolute bottom-1 right-1 bg-black/60 px-1.5 py-0.5 rounded text-[9px] text-white/80 opacity-0 group-hover:opacity-100 transition-opacity">
                Поменять
              </div>
            </motion.div>
          </div>
        ) : (
          /* ========================================================================= */
          /* MODE 2: AUDIO CALL LAYOUT (Matching Screenshot 2: Telegram Doodle Wallpaper) */
          /* ========================================================================= */
          <div className="absolute inset-0 w-full h-full bg-[#0e1621] overflow-hidden pointer-events-none">
            {/* Telegram Pattern Overlay */}
            <div 
              className="absolute inset-0 opacity-[0.06] bg-repeat"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='1' fill-rule='evenodd'%3E%3Ccircle cx='10' cy='10' r='3'/%3E%3Cpath d='M40 10l5 10h-10z'/%3E%3Cpath d='M65 20c0 4-3 7-7 7s-7-3-7-7 3-7 7-7 7 3 7 7zm-5 0c0-1.7-1.3-3-3-3s-3 1.3-3 3 1.3 3 3 3 3-1.3 3-3z'/%3E%3Ccircle cx='25' cy='45' r='4'/%3E%3Cpath d='M60 55l6-3v6z'/%3E%3Cpath d='M15 65c2 0 4-2 4-4s-2-4-4-4-4 2-4 4 2 4 4 4z'/%3E%3C/g%3E%3C/svg%3E")`,
                backgroundSize: '120px 120px'
              }}
            />
            {/* Ambient Center Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
          </div>
        )}

        {/* ========================================================================= */}
        {/* TOP HEADER BAR (Matching Screenshot 2: Minimize, Name/Status, Add User) */}
        {/* ========================================================================= */}
        <motion.div 
          animate={{
            y: areControlsHidden && isVideoCall ? -100 : 0,
            opacity: areControlsHidden && isVideoCall ? 0 : 1
          }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className={`relative z-30 flex items-center justify-between px-4 pt-4 sm:px-6 sm:pt-6 bg-gradient-to-b from-black/80 via-black/30 to-transparent ${
            areControlsHidden && isVideoCall ? 'pointer-events-none' : ''
          }`}
        >
          {/* Left: Star Fold / Minimize Button */}
          <button
            onClick={() => setMinimized(true)}
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md flex items-center justify-center transition-transform active:scale-95 text-white/90 border border-white/10"
            title="Свернуть звонок"
          >
            <Sparkles className="w-5 h-5 text-white/90" />
          </button>

          {/* Center: Contact Name & Status (e.g., Рома 5 / Соединение...) */}
          <div className="text-center flex flex-col items-center">
            <h2 className="text-base sm:text-lg font-bold text-white tracking-wide truncate max-w-[220px]">
              {otherPersonName}
            </h2>
            <p className="text-xs text-white/70 font-medium mt-0.5">
              {getStatusText()}
            </p>
          </div>

          {/* Right Actions: Add Participant Button & Hide Controls Button */}
          <div className="flex items-center gap-2">
            {isVideoCall && (
              <button
                onClick={() => setAreControlsHidden(true)}
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md flex items-center justify-center transition-transform active:scale-95 text-white/90 border border-white/10"
                title="Скрыть панель (для полного просмотра)"
              >
                <EyeOff className="w-5 h-5 text-white/90" />
              </button>
            )}
            <button
              onClick={copyCallLink}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md flex items-center justify-center transition-transform active:scale-95 text-white/90 border border-white/10"
              title="Добавить участника / Скопировать ссылку"
            >
              <UserPlus className="w-5 h-5 text-white/90" />
            </button>
          </div>
        </motion.div>

        {/* ========================================================================= */}
        {/* CENTER CONTENT (Audio Call Avatar matching Screenshot 2) */}
        {/* ========================================================================= */}
        {!isVideoCall && (
          <div className="relative z-20 flex-1 flex flex-col items-center justify-center px-4 my-auto">
            <div className="relative flex items-center justify-center">
              {/* Subtle pulsing outer ring */}
              <div className="absolute w-56 h-56 sm:w-64 sm:h-64 rounded-full bg-cyan-500/10 border border-cyan-500/20 animate-ping opacity-30" />
              <div className="absolute w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-slate-700/20 border border-white/10 animate-pulse" />
              
              {/* Main Circular Avatar */}
              <img
                src={otherPersonAvatar}
                alt={otherPersonName}
                className="w-40 h-40 sm:w-48 sm:h-48 rounded-full object-cover border-4 border-slate-700/80 shadow-[0_10px_40px_rgba(0,0,0,0.6)] relative z-10"
              />

              {activeCall.isRemoteMuted && (
                <div className="absolute bottom-2 right-2 z-20 bg-red-500 p-2.5 rounded-full border-2 border-[#0e1621] shadow-lg">
                  <MicOff className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Floating "Show Controls" pill button when controls are hidden in video mode */}
        <AnimatePresence>
          {areControlsHidden && isVideoCall && (
            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              onClick={() => setAreControlsHidden(false)}
              className="fixed bottom-6 left-6 z-40 bg-slate-900/80 hover:bg-slate-900 backdrop-blur-xl border border-white/20 text-white/90 text-xs px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-2 transition-all active:scale-95 hover:border-cyan-400"
            >
              <Eye className="w-4 h-4 text-cyan-400" />
              <span>Показать панель</span>
            </motion.button>
          )}
        </AnimatePresence>

        {/* Share Toast Feedback */}
        <AnimatePresence>
          {showShareToast && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute top-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white text-xs px-4 py-2 rounded-full shadow-2xl flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Ссылка на звонок скопирована</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* More Options Popover Menu */}
        <AnimatePresence>
          {showMoreMenu && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="absolute bottom-44 left-1/2 -translate-x-1/2 z-50 w-72 bg-[#1c242f]/95 backdrop-blur-xl border border-white/15 rounded-2xl p-3 shadow-2xl text-sm"
            >
              <div className="space-y-1">
                {isVideoCall && (
                  <button
                    onClick={() => { setAreControlsHidden(true); setShowMoreMenu(false); }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left"
                  >
                    <EyeOff className="w-4 h-4 text-amber-400" />
                    <span>Скрыть панель управления</span>
                  </button>
                )}
                <button
                  onClick={() => { switchCamera(); setShowMoreMenu(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left"
                >
                  <SwitchCamera className="w-4 h-4 text-cyan-400" />
                  <span>Переключить камеру</span>
                </button>
                <button
                  onClick={() => { toggleFullscreenHandler(); setShowMoreMenu(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left"
                >
                  <Maximize2 className="w-4 h-4 text-emerald-400" />
                  <span>{isFullscreen ? 'Выйти из полноэкранного' : 'Полноэкранный режим'}</span>
                </button>
                <button
                  onClick={() => { copyCallLink(); setShowMoreMenu(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left"
                >
                  <Share2 className="w-4 h-4 text-purple-400" />
                  <span>Скопировать ID звонка</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ========================================================================= */}
        {/* BOTTOM CONTROL PANEL (Matching Screenshot 2: Exact 6 Buttons Grid)        */}
        {/* ========================================================================= */}
        <motion.div 
          animate={{
            y: areControlsHidden && isVideoCall ? 140 : 0,
            opacity: areControlsHidden && isVideoCall ? 0 : 1
          }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className={`relative z-30 w-full max-w-md mx-auto px-4 pb-6 pt-2 ${
            areControlsHidden && isVideoCall ? 'pointer-events-none' : ''
          }`}
        >
          <div className="bg-[#18222d]/95 backdrop-blur-2xl border border-white/10 rounded-[32px] p-5 shadow-[0_20px_60px_rgba(0,0,0,0.8)]">
            <div className="grid grid-cols-3 gap-y-4 gap-x-2 text-center">
              
              {/* Button 1: Динамик */}
              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={toggleSpeaker}
                  className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-md active:scale-95 ${
                    isSpeakerOn 
                      ? 'bg-white/15 hover:bg-white/25 text-white' 
                      : 'bg-white/10 text-white/50'
                  }`}
                  title="Динамик"
                >
                  {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
                </button>
                <span className="text-[11px] text-white/80 font-medium">Динамик</span>
              </div>

              {/* Button 2: Видео */}
              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={toggleVideo}
                  className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-md active:scale-95 ${
                    !isVideoOff && isVideoCall
                      ? 'bg-cyan-600 hover:bg-cyan-500 text-white ring-2 ring-cyan-400/40' 
                      : 'bg-white/15 hover:bg-white/25 text-white'
                  }`}
                  title="Видео"
                >
                  {isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
                </button>
                <span className="text-[11px] text-white/80 font-medium">Видео</span>
              </div>

              {/* Button 3: Отключить звук */}
              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={toggleMute}
                  className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-md active:scale-95 ${
                    isMuted 
                      ? 'bg-red-500 text-white ring-2 ring-red-400/40' 
                      : 'bg-white/15 hover:bg-white/25 text-white'
                  }`}
                  title={isMuted ? 'Включить звук' : 'Отключить звук'}
                >
                  {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>
                <span className="text-[11px] text-white/80 font-medium truncate max-w-[80px]">
                  {isMuted ? 'Включить' : 'Отключить'}
                </span>
              </div>

              {/* Button 4: Ещё */}
              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={() => setShowMoreMenu(!showMoreMenu)}
                  className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-md active:scale-95 ${
                    showMoreMenu ? 'bg-white/30 text-white' : 'bg-white/15 hover:bg-white/25 text-white'
                  }`}
                  title="Ещё"
                >
                  <MoreHorizontal className="w-6 h-6" />
                </button>
                <span className="text-[11px] text-white/80 font-medium">Ещё</span>
              </div>

              {/* Button 5: Поделиться */}
              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={handleShare}
                  className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-md active:scale-95 ${
                    isScreenSharing ? 'bg-indigo-600 text-white' : 'bg-white/15 hover:bg-white/25 text-white'
                  }`}
                  title="Поделиться"
                >
                  <Upload className="w-5 h-5" />
                </button>
                <span className="text-[11px] text-white/80 font-medium">Поделиться</span>
              </div>

              {/* Button 6: Завершить (Red button matching screenshot 2) */}
              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={endCall}
                  className="w-14 h-14 rounded-full bg-[#ff3b30] hover:bg-red-600 text-white flex items-center justify-center transition-all shadow-xl hover:scale-105 active:scale-95 ring-4 ring-red-500/20"
                  title="Завершить"
                >
                  <PhoneOff className="w-6 h-6" />
                </button>
                <span className="text-[11px] text-white/80 font-medium">Завершить</span>
              </div>

            </div>
          </div>
        </motion.div>

      </motion.div>
    </AnimatePresence>
  );
};

