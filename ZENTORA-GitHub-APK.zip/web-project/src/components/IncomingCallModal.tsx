import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, PhoneOff, Video, Mic } from 'lucide-react';
import { useCall } from '../context/CallContext';

export const IncomingCallModal: React.FC = () => {
  const { incomingCall, acceptCall, declineCall } = useCall();

  if (!incomingCall) return null;

  const isVideo = incomingCall.type === 'video';
  const avatar = incomingCall.callerAvatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${incomingCall.callerName}`;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[180] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl select-none"
      >
        {/* Animated Background Ambience */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-purple-600/30 rounded-full blur-3xl animate-pulse" />
        </div>

        <motion.div
          initial={{ scale: 0.85, y: 30 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.85, y: 30 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-sm bg-slate-900/95 border border-white/15 rounded-[36px] p-8 text-white text-center shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] flex flex-col items-center"
        >
          {/* Pulsating Avatar */}
          <div className="relative my-4 flex items-center justify-center">
            <div className="absolute w-36 h-36 rounded-full bg-emerald-500/20 animate-ping" />
            <div className="absolute w-32 h-32 rounded-full bg-purple-500/20 animate-pulse" />
            <img
              src={avatar}
              alt={incomingCall.callerName}
              className="w-28 h-28 rounded-full object-cover border-4 border-emerald-500/60 shadow-2xl relative z-10"
            />
          </div>

          <h3 className="text-2xl font-bold text-white mb-1.5 tracking-tight truncate max-w-[260px]">
            {incomingCall.callerName}
          </h3>

          <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 text-emerald-300 text-xs font-semibold mb-8 border border-white/10">
            {isVideo ? <Video className="w-3.5 h-3.5" /> : <Phone className="w-3.5 h-3.5" />}
            <span>Входящий {isVideo ? 'видеозвонок' : 'голосовой звонок'}...</span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-center gap-8 w-full">
            {/* Decline */}
            <div className="flex flex-col items-center gap-2">
              <button
                onClick={declineCall}
                className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center transition-all shadow-xl hover:scale-110 active:scale-95 ring-4 ring-red-500/20"
                title="Отклонить"
              >
                <PhoneOff className="w-7 h-7" />
              </button>
              <span className="text-xs font-medium text-slate-400">Отклонить</span>
            </div>

            {/* Accept */}
            <div className="flex flex-col items-center gap-2">
              <button
                onClick={() => acceptCall(isVideo)}
                className="w-16 h-16 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center transition-all shadow-xl hover:scale-110 active:scale-95 ring-4 ring-emerald-500/30 animate-bounce"
                title="Принять"
              >
                {isVideo ? <Video className="w-7 h-7" /> : <Phone className="w-7 h-7" />}
              </button>
              <span className="text-xs font-medium text-emerald-400 font-bold">Принять</span>
            </div>
          </div>

          {/* If video call, allow audio-only answer */}
          {isVideo && (
            <button
              onClick={() => acceptCall(false)}
              className="mt-6 text-xs text-slate-400 hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Ответить без видео</span>
            </button>
          )}

        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
