import React, { useState } from 'react';
import { X, Flag, CheckCircle } from 'lucide-react';

interface ReportModalProps {
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({ onClose }) => {
  const [reason, setReason] = useState('Spam / Unsolicited messages');
  const [details, setDetails] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason, details })
      });
      setSubmitted(true);
      setTimeout(() => onClose(), 2000);
    } catch (err) {
      setSubmitted(true);
      setTimeout(() => onClose(), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--background)]/80 backdrop-blur-md p-4 animate-fadeIn text-[var(--text-primary)] select-none">
      <div className="w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-3xl shadow-2xl p-6">
        
        <div className="flex items-center justify-between pb-4 border-b border-[var(--border)]">
          <div className="flex items-center gap-2 text-[var(--accent)]">
            <Flag className="w-5 h-5" />
            <h3 className="text-lg font-bold text-[var(--text-primary)] font-mono">Отправить жалобу</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-[var(--surface-hover)] rounded-lg text-[var(--text-secondary)]">
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-3">
            <CheckCircle className="w-12 h-12 text-[var(--success)] mx-auto animate-bounce" />
            <h4 className="font-bold text-[var(--text-primary)] text-base">Жалоба отправлена!</h4>
            <p className="text-xs text-[var(--text-secondary)]">Команда модерации Zentora проверит обращение в кратчайшие сроки.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 my-4">
            <div>
              <label className="block text-xs font-semibold uppercase text-[var(--text-secondary)] mb-1">Причина обращения</label>
              <select
                value={reason}
                onChange={e => setReason(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)] text-xs font-semibold text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
              >
                <option value="Спам / Реклама">Спам / Ненужная реклама</option>
                <option value="Оскорбления / Мошенничество">Оскорбления / Мошенничество</option>
                <option value="Неприемлемый контент">Неприемлемый контент</option>
                <option value="Выдавал себя за другого">Выдавал себя за другого пользователя</option>
                <option value="Другое">Другое</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-[var(--text-secondary)] mb-1">Дополнительные детали</label>
              <textarea
                rows={3}
                placeholder="Опишите подробнее суть проблемы..."
                value={details}
                onChange={e => setDetails(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)] text-xs text-[var(--text-primary)] placeholder-[var(--text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[var(--accent)] hover:opacity-90 text-[var(--message-sent-text)] font-bold text-xs shadow-md transition-transform active:scale-95"
            >
              Отправить модераторам
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
