import React from 'react';
import { ShieldCheck, X, Zap, Lock, Scale, Wrench } from 'lucide-react';

interface AdminInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  adminName?: string;
}

export const AdminInfoModal: React.FC<AdminInfoModalProps> = ({ isOpen, onClose, adminName = 'Администратор Zentora' }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-3xl p-6 shadow-2xl relative overflow-hidden text-[var(--text-primary)]">
        
        {/* Glow effect */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--accent)]/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2.5 rounded-full bg-[var(--background)]/80 hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Badge */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 bg-red-500/15 text-red-500 rounded-2xl border border-red-500/30 flex items-center justify-center">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-400 font-bold text-xs uppercase tracking-wider mb-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              ADMIN
            </div>
            <h3 className="text-xl font-bold">{adminName}</h3>
          </div>
        </div>

        {/* Role & Description */}
        <div className="space-y-4 text-sm">
          <div className="p-4 rounded-2xl bg-[var(--background)] border border-[var(--border)]">
            <p className="font-semibold text-xs uppercase tracking-wider text-[var(--accent)] mb-1">
              Кто это:
            </p>
            <p className="text-[var(--text-primary)] leading-relaxed">
              Главный системный администратор и верифицированный регулятор безопасности сети Zentora Messenger.
            </p>
          </div>

          <div>
            <p className="font-semibold text-xs uppercase tracking-wider text-[var(--text-secondary)] mb-2.5 ml-1">
              За что отвечает:
            </p>

            <div className="grid grid-cols-1 gap-2.5">
              <div className="flex items-start gap-3 p-3 rounded-xl bg-[var(--background)]/60 border border-[var(--border)]">
                <Lock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs text-[var(--text-primary)]">Защита и шифрование</h4>
                  <p className="text-xs text-[var(--text-secondary)]">Контроль работы алгоритмов сквозного шифрования AES-256 для чатов и звонков.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-[var(--background)]/60 border border-[var(--border)]">
                <Zap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs text-[var(--text-primary)]">WebRTC и серверы</h4>
                  <p className="text-xs text-[var(--text-secondary)]">Мониторинг соединений высокой четкости для голосовых и видеовызовов.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-[var(--background)]/60 border border-[var(--border)]">
                <Scale className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs text-[var(--text-primary)]">Модерация и безопасность</h4>
                  <p className="text-xs text-[var(--text-secondary)]">Рассмотрение жалоб пользователей, блокировка спам-ботов и предотвращение атак.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-[var(--background)]/60 border border-[var(--border)]">
                <Wrench className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs text-[var(--text-primary)]">Управление платформой</h4>
                  <p className="text-xs text-[var(--text-secondary)]">Выдача статусов верификации, поддержка серверов и системные обновления.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 py-3 rounded-2xl bg-[var(--accent)] hover:opacity-90 text-[var(--message-sent-text)] font-bold text-sm shadow-lg transition-transform active:scale-95"
        >
          Понятно
        </button>
      </div>
    </div>
  );
};
