import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, 
  Send, Music, Disc, Repeat, Download, Plus, Check, Trash2, 
  Upload, Sparkles, UserCheck, Radio, Square
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';
import { useMusic } from '../context/MusicContext';
import { MusicTrack } from '../types';

interface MusicPlayerModalProps {
  onClose?: () => void;
}

export const MusicPlayerModal: React.FC<MusicPlayerModalProps> = ({ onClose }) => {
  const { user } = useAuth();
  const { activeChatId, sendMessage } = useChat();
  const {
    playlist,
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isLooping,
    isFullPlayerOpen,
    setIsFullPlayerOpen,
    playTrack,
    togglePlay,
    pauseTrack,
    stopMusic,
    nextTrack,
    prevTrack,
    seek,
    setVolume,
    toggleMute,
    toggleLoop,
    downloadTrack,
    setTrackToProfile,
    uploadCustomTrack
  } = useMusic();

  const [shareSuccess, setShareSuccess] = useState(false);
  const [pinnedSuccess, setPinnedSuccess] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleClose = () => {
    setIsFullPlayerOpen(false);
    if (onClose) onClose();
  };

  useEffect(() => {
    if (!isFullPlayerOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullPlayerOpen]);

  if (!isFullPlayerOpen) return null;

  const track = currentTrack || playlist[0];

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = Number(e.target.value);
    seek(targetTime);
  };

  const handleShareToChat = async () => {
    if (!activeChatId || !track) return;
    await sendMessage(
      `🎵 Музыкальный трек: ${track.artist} - ${track.title}`,
      undefined,
      [{
        id: `att_mus_${Date.now()}`,
        name: `${track.artist} - ${track.title}.mp3`,
        size: 3500000,
        mimeType: 'audio/mp3',
        url: track.url,
        type: 'audio',
        duration: track.duration
      }]
    );
    setShareSuccess(true);
    setTimeout(() => setShareSuccess(false), 3000);
  };

  const handlePinToProfile = async (targetTrack: MusicTrack) => {
    try {
      await setTrackToProfile(targetTrack);
      setPinnedSuccess(true);
      setTimeout(() => setPinnedSuccess(false), 3000);
    } catch (e) {
      alert("Не удалось прикрепить трек к профилю");
    }
  };

  const handleDownload = async (targetTrack: MusicTrack) => {
    setDownloadingId(targetTrack.id);
    await downloadTrack(targetTrack);
    setTimeout(() => setDownloadingId(null), 1000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsUploading(true);
      const newTrack = await uploadCustomTrack(file);
      playTrack(newTrack);
    } catch (err) {
      console.error(err);
      alert("Ошибка при загрузке аудиофайла");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const isCurrentPinnedToProfile = user?.profileTrack?.id === track?.id;

  return (
    <div 
      onClick={handleClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fadeIn select-none"
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-[32px] shadow-2xl overflow-hidden flex flex-col text-[var(--text-primary)] max-h-[90vh]"
      >
        
        {/* Header */}
        <div className="p-4 px-6 border-b border-[var(--border)] flex items-center justify-between bg-[var(--background)]/40 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30 shadow-inner">
              <Music className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[var(--text-primary)] leading-tight">ВК & Telegram Музыка</h3>
              <p className="text-[10px] text-[var(--text-secondary)]">Слушай, скачивай и вставляй в профиль</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Upload MP3 button */}
            <input
              type="file"
              ref={fileInputRef}
              accept="audio/*,.mp3,.wav,.ogg,.m4a"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="p-2 rounded-full hover:bg-[var(--surface-hover)] text-[var(--accent)] transition-colors cursor-pointer"
              title="Загрузить свой трек (MP3)"
            >
              <Upload className="w-4 h-4" />
            </button>

            <button
              onClick={handleClose}
              className="p-2 rounded-full hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer"
              title="Закрыть (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Main Area */}
        <div className="flex-1 overflow-y-auto">
          {/* Current Track Display */}
          {track && (
            <div className="p-6 flex flex-col items-center text-center">
              <div className="relative w-44 h-44 rounded-3xl overflow-hidden shadow-2xl border border-white/10 group mb-4">
                <img
                  src={track.cover}
                  alt={track.title}
                  className={`w-full h-full object-cover transition-transform duration-700 ${isPlaying ? 'scale-105 rotate-1' : ''}`}
                />
                <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Disc className={`w-12 h-12 text-white ${isPlaying ? 'animate-spin' : ''}`} />
                </div>
              </div>

              <h2 className="font-extrabold text-lg text-[var(--text-primary)] truncate max-w-xs">{track.title}</h2>
              <p className="text-xs font-semibold text-[var(--accent)] mt-0.5">{track.artist}</p>

              {/* Progress Slider */}
              <div className="w-full mt-5 space-y-1">
                <input
                  type="range"
                  min={0}
                  max={duration || track.duration || 100}
                  value={currentTime}
                  onChange={handleSeek}
                  className="w-full h-1.5 bg-[var(--border)] rounded-lg appearance-none cursor-pointer accent-[var(--accent)]"
                />
                <div className="flex justify-between text-[11px] font-mono text-[var(--text-secondary)]">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration || track.duration || 0)}</span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4 mt-3">
                <button
                  onClick={toggleLoop}
                  className={`p-2 rounded-full transition-colors cursor-pointer ${isLooping ? 'text-[var(--accent)] bg-[var(--accent)]/15' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}`}
                  title={isLooping ? 'Повтор включен' : 'Повтор выключен'}
                >
                  <Repeat className="w-4 h-4" />
                </button>

                <button
                  onClick={prevTrack}
                  className="p-3 rounded-full hover:bg-[var(--surface-hover)] text-[var(--text-primary)] transition-all active:scale-90 cursor-pointer"
                  title="Предыдущий трек"
                >
                  <SkipBack className="w-5 h-5 fill-current" />
                </button>

                <button
                  onClick={togglePlay}
                  className="w-14 h-14 rounded-full bg-[var(--accent)] text-[var(--message-sent-text)] shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center justify-center cursor-pointer"
                  title={isPlaying ? 'Пауза' : 'Воспроизвести'}
                >
                  {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-0.5" />}
                </button>

                <button
                  onClick={nextTrack}
                  className="p-3 rounded-full hover:bg-[var(--surface-hover)] text-[var(--text-primary)] transition-all active:scale-90 cursor-pointer"
                  title="Следующий трек"
                >
                  <SkipForward className="w-5 h-5 fill-current" />
                </button>

                <button
                  onClick={toggleMute}
                  className={`p-2 rounded-full transition-colors cursor-pointer ${isMuted ? 'text-red-400' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}`}
                  title={isMuted ? 'Включить звук' : 'Без звука'}
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>

              {/* Action Buttons: Download & Pin to Profile */}
              <div className="grid grid-cols-2 gap-2.5 w-full mt-5">
                <button
                  onClick={() => handleDownload(track)}
                  disabled={downloadingId === track.id}
                  className="py-2.5 px-3 rounded-2xl bg-[var(--surface-hover)] border border-[var(--border)] hover:border-[var(--accent)] text-[var(--text-primary)] text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer shadow-sm"
                  title="Скачать трек в MP3 на устройство"
                >
                  <Download className={`w-4 h-4 text-emerald-400 ${downloadingId === track.id ? 'animate-bounce' : ''}`} />
                  <span>{downloadingId === track.id ? 'Скачивание...' : 'Скачать MP3'}</span>
                </button>

                <button
                  onClick={() => handlePinToProfile(track)}
                  className={`py-2.5 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer shadow-sm ${
                    isCurrentPinnedToProfile || pinnedSuccess
                      ? 'bg-blue-600/20 border-blue-500/50 text-blue-400'
                      : 'bg-[var(--surface-hover)] border-[var(--border)] hover:border-[var(--accent)] text-[var(--text-primary)]'
                  }`}
                  title="Установить этот трек главным в свой профиль"
                >
                  {isCurrentPinnedToProfile || pinnedSuccess ? (
                    <>
                      <Check className="w-4 h-4 text-blue-400" />
                      <span>В профиле ✓</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>В профиль</span>
                    </>
                  )}
                </button>
              </div>

              {/* Share to Chat button */}
              {activeChatId && (
                <button
                  onClick={handleShareToChat}
                  className={`mt-3 w-full py-2.5 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer ${
                    shareSuccess
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[var(--accent)] text-[var(--message-sent-text)] hover:opacity-90'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  <span>{shareSuccess ? '✓ Отправлено в чат!' : 'Отправить трек в чат'}</span>
                </button>
              )}
            </div>
          )}

          {/* Playlist Drawer */}
          <div className="border-t border-[var(--border)] p-4 bg-[var(--background)]/40 space-y-2">
            <div className="flex items-center justify-between mb-2">
              <p className="text-[11px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">
                Медиатека ({playlist.length})
              </p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="text-[11px] text-[var(--accent)] hover:underline font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Добавить MP3</span>
              </button>
            </div>

            {playlist.map((t) => {
              const isCurrent = t.id === track?.id;
              return (
                <div
                  key={t.id}
                  onClick={() => {
                    playTrack(t);
                  }}
                  className={`flex items-center justify-between p-2.5 rounded-2xl cursor-pointer transition-all border ${
                    isCurrent
                      ? 'bg-[var(--accent)]/15 border-[var(--accent)]/40 text-[var(--accent)] font-bold'
                      : 'bg-[var(--surface)] border-[var(--border)] hover:bg-[var(--surface-hover)] text-[var(--text-primary)]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="relative w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-white/10">
                      <img src={t.cover} alt={t.title} className="w-full h-full object-cover" />
                      {isCurrent && isPlaying && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <Disc className="w-4 h-4 text-white animate-spin" />
                        </div>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs truncate font-bold">{t.title}</p>
                      <p className="text-[10px] text-[var(--text-secondary)] truncate">{t.artist}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 ml-2" onClick={e => e.stopPropagation()}>
                    <button
                      onClick={() => handleDownload(t)}
                      className="p-2 rounded-xl text-[var(--text-secondary)] hover:text-emerald-400 hover:bg-[var(--surface-hover)] transition-colors cursor-pointer"
                      title="Скачать трек"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => handlePinToProfile(t)}
                      className={`p-2 rounded-xl transition-colors cursor-pointer ${
                        user?.profileTrack?.id === t.id
                          ? 'text-blue-400 bg-blue-500/10'
                          : 'text-[var(--text-secondary)] hover:text-amber-400 hover:bg-[var(--surface-hover)]'
                      }`}
                      title="Вставить в профиль"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                    </button>

                    <span className="text-[10px] font-mono text-[var(--text-secondary)] opacity-60 ml-1">
                      {formatTime(t.duration)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom footer for easy exit and stopping */}
        <div className="p-3 px-5 border-t border-[var(--border)] bg-[var(--background)]/60 flex items-center justify-between gap-2 shrink-0">
          <button
            onClick={() => {
              stopMusic();
              handleClose();
            }}
            className="py-2 px-3.5 rounded-xl border border-red-500/20 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Остановить воспроизведение и закрыть"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Остановить</span>
          </button>

          <button
            onClick={handleClose}
            className="py-2 px-4 rounded-xl bg-[var(--surface-hover)] hover:bg-[var(--accent)] hover:text-[var(--message-sent-text)] text-[var(--text-primary)] text-xs font-bold transition-all cursor-pointer shadow-sm"
          >
            Свернуть в фон
          </button>
        </div>

      </div>
    </div>
  );
};
