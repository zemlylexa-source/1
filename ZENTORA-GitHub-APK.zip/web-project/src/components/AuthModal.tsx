import React, { useState } from 'react';
import { ZentoraLogo } from './ZentoraLogo';
import { useAuth } from '../context/AuthContext';
import { Lock, Mail, User, ArrowRight, ShieldCheck, Zap } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { login, register } = useAuth();
  const [isRegistering, setIsRegistering] = useState(false);

  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isRegistering) {
      if (!name || !username || !email || !password || !confirmPassword) {
        setError('Заполните все обязательные поля.');
        return;
      }
      if (password.length < 8) {
        setError('Пароль должен содержать минимум 8 символов.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Пароли не совпадают.');
        return;
      }

      setLoading(true);
      const res = await register(name, username, email, password);
      setLoading(false);
      if (!res.success) {
        setError(res.error || 'Ошибка при регистрации.');
      }
    } else {
      if (!email || !password) {
        setError('Введите Email/Имя пользователя и пароль.');
        return;
      }

      setLoading(true);
      const res = await login(email, password);
      setLoading(false);
      if (!res.success) {
        setError(res.error || 'Неверные данные для входа.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--background)]/95 p-4 sm:p-8 animate-fadeIn select-none overflow-y-auto">
      <div className="w-full max-w-[1000px] h-[600px] max-h-full flex rounded-3xl overflow-hidden shadow-2xl bg-[var(--surface)] border border-[var(--border)]">
        
        {/* Left Side - Brand & Graphics */}
        <div className="hidden md:flex flex-col justify-between w-5/12 bg-gradient-to-br from-[#1e1b4b] via-[#312e81] to-[#4c1d95] relative p-12 overflow-hidden border-r border-[#334155]/50">
          <div className="absolute top-0 left-0 w-full h-full opacity-30 mix-blend-overlay" style={{ backgroundImage: 'radial-gradient(circle at center, white 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
          
          <div className="relative z-10">
            <ZentoraLogo size={48} className="mb-8" />
            <h1 className="text-4xl font-bold text-white tracking-tight mb-4 leading-tight">
              Общение<br/>нового<br/>поколения
            </h1>
            <p className="text-white/80 text-sm leading-relaxed">
              Zentora обеспечивает сквозное шифрование, кристально чистые звонки и непревзойденную приватность ваших данных.
            </p>
          </div>

          <div className="relative z-10 flex flex-col gap-4">
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10">
              <ShieldCheck className="w-5 h-5 text-[var(--success)]" />
              <span className="text-sm font-medium text-white">Военное шифрование AES-256</span>
            </div>
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10">
              <Zap className="w-5 h-5 text-[var(--accent)]" />
              <span className="text-sm font-medium text-white">Сверхбыстрые WebRTC звонки</span>
            </div>
          </div>
        </div>

        {/* Right Side - Auth Forms */}
        <div className="w-full md:w-7/12 flex flex-col justify-center p-8 sm:p-12 bg-[var(--surface)] relative overflow-y-auto">
          
          {/* Mobile Logo */}
          <div className="md:hidden flex flex-col items-center mb-8">
            <ZentoraLogo size={48} className="mb-4" />
            <h2 className="text-2xl font-bold text-[var(--text-primary)] text-center">Zentora</h2>
          </div>

          <div className="max-w-sm mx-auto w-full">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-[var(--text-primary)] tracking-tight mb-2">
                {isRegistering ? 'Создать аккаунт' : 'Добро пожаловать назад'}
              </h2>
              <p className="text-[var(--text-secondary)] text-sm">
                {isRegistering ? 'Присоединяйтесь к защищенной сети сообщений' : 'Введите данные для входа в ваш аккаунт'}
              </p>
            </div>

            {error && (
              <div className="w-full p-3 mb-6 bg-[var(--danger)]/10 border border-[var(--danger)]/20 text-[var(--danger)] rounded-xl text-sm font-medium animate-fadeIn flex items-center justify-center">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {isRegistering && (
                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="block text-[11px] font-bold tracking-wider uppercase text-[var(--text-secondary)] mb-1.5 ml-1">Имя</label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-3 w-4 h-4 text-[var(--text-secondary)]" />
                      <input
                        type="text"
                        required
                        placeholder="Александр"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)]/50 text-sm focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)] text-[var(--text-primary)] transition-colors"
                      />
                    </div>
                  </div>

                  <div className="flex-1">
                    <label className="block text-[11px] font-bold tracking-wider uppercase text-[var(--text-secondary)] mb-1.5 ml-1">Никнейм</label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-2.5 text-[var(--accent)] font-mono text-sm">@</span>
                      <input
                        type="text"
                        required
                        placeholder="alex"
                        value={username}
                        onChange={e => setUsername(e.target.value)}
                        className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)]/50 text-sm font-mono text-[var(--accent)] focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)] transition-colors"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold tracking-wider uppercase text-[var(--text-secondary)] mb-1.5 ml-1">
                  {isRegistering ? 'Email' : 'Email или Имя пользователя'}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3 w-4 h-4 text-[var(--text-secondary)]" />
                  <input
                    type="text"
                    required
                    placeholder={isRegistering ? 'alex@zentora.io' : 'alexander или alex@zentora.io'}
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)]/50 text-sm focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)] text-[var(--text-primary)] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold tracking-wider uppercase text-[var(--text-secondary)] mb-1.5 ml-1">Пароль</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-[var(--text-secondary)]" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)]/50 text-sm focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)] text-[var(--text-primary)] font-mono transition-colors"
                  />
                </div>
              </div>

              {isRegistering && (
                <div>
                  <label className="block text-[11px] font-bold tracking-wider uppercase text-[var(--text-secondary)] mb-1.5 ml-1">Подтвердите пароль</label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-3 w-4 h-4 text-[var(--text-secondary)]" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)]/50 text-sm focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)] text-[var(--text-primary)] font-mono transition-colors"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 mt-4 rounded-xl bg-[var(--accent)] hover:opacity-90 text-[var(--message-sent-text)] font-bold text-sm shadow-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    Загрузка...
                  </span>
                ) : (
                  <>
                    <span>{isRegistering ? 'Создать аккаунт' : 'Войти в систему'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-8 flex items-center justify-center">
              <button
                type="button"
                onClick={() => {
                  setIsRegistering(prev => !prev);
                  setError('');
                }}
                className="text-sm text-[var(--text-secondary)] hover:text-[var(--accent)] transition-colors"
              >
                {isRegistering ? (
                  <span>Уже есть аккаунт? <span className="font-semibold text-[var(--text-primary)]">Войти</span></span>
                ) : (
                  <span>Нет аккаунта? <span className="font-semibold text-[var(--text-primary)]">Зарегистрироваться</span></span>
                )}
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

