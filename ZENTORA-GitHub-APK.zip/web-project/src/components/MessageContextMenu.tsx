import React from 'react';
import { Reply, Copy, Forward, Edit3, Pin, Trash2 } from 'lucide-react';
import { Message } from '../types';
import { useAuth } from '../context/AuthContext';

interface MessageContextMenuProps {
  message: Message;
  x: number;
  y: number;
  onClose: () => void;
  onReply: (msg: Message) => void;
  onCopy: (msg: Message) => void;
  onForward: (msg: Message) => void;
  onEdit: (msg: Message) => void;
  onPin: (msg: Message) => void;
  onDelete: (msg: Message) => void;
  onReact: (msg: Message, emoji: string) => void;
}

export const MessageContextMenu: React.FC<MessageContextMenuProps> = ({
  message,
  x,
  y,
  onClose,
  onReply,
  onCopy,
  onForward,
  onEdit,
  onPin,
  onDelete,
  onReact
}) => {
  const { user } = useAuth();
  const isMine = message.senderId === user?.id || user?.isAdmin;

  const EMOJI_REACTIONS = ['🔥', '❤️', '👍', '😂', '😮', '🎉', '💩'];

  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      
      <div
        className="fixed z-50 w-60 rounded-2xl bg-[var(--surface)] border border-[var(--border)] shadow-2xl py-2 text-xs text-[var(--text-primary)] animate-fadeIn backdrop-blur-md"
        style={{
          top: Math.max(12, Math.min(y, window.innerHeight - 340)),
          left: Math.max(12, Math.min(x, window.innerWidth - 256))
        }}
      >
        {/* Quick Reactions Bar */}
        <div className="flex items-center justify-between px-3 pb-2 border-b border-[var(--border)]">
          {EMOJI_REACTIONS.map(emoji => (
            <button
              key={emoji}
              onClick={() => {
                onReact(message, emoji);
                onClose();
              }}
              className="text-base hover:scale-125 transition-transform p-1"
            >
              {emoji}
            </button>
          ))}
        </div>

        <button
          onClick={() => { onReply(message); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
        >
          <Reply className="w-4 h-4 text-[var(--accent)]" />
          <span>Ответить</span>
        </button>

        <button
          onClick={() => { onCopy(message); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
        >
          <Copy className="w-4 h-4 text-[var(--text-secondary)]" />
          <span>Копировать текст</span>
        </button>

        <button
          onClick={() => { onForward(message); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
        >
          <Forward className="w-4 h-4 text-[var(--success)]" />
          <span>Переслать в Избранное</span>
        </button>

        <button
          onClick={() => { onPin(message); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
        >
          <Pin className="w-4 h-4 text-[var(--accent)]" />
          <span>{message.isPinned ? 'Открепить' : 'Закрепить'}</span>
        </button>

        {isMine && (
          <button
            onClick={() => { onEdit(message); onClose(); }}
            className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
          >
            <Edit3 className="w-4 h-4 text-[var(--accent)]" />
            <span>Редактировать</span>
          </button>
        )}

        {isMine && (
          <button
            onClick={() => { onDelete(message); onClose(); }}
            className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--danger)]/10 text-[var(--danger)] text-left font-semibold border-t border-[var(--border)] mt-1 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Удалить сообщение</span>
          </button>
        )}
      </div>
    </>
  );
};
