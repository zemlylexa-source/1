import React, { useState, useRef } from 'react';
import { 
  X, ShieldCheck, Bell, Flag, Image as ImageIcon, FileText, Search, 
  Users, UserCheck, Ban, Trash2, Smartphone, Link, Mic, Lock, 
  CheckCircle2, Phone, Video, Music, Play, Pause, Download, Sparkles, Check, Upload, Disc 
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';
import { useCall } from '../context/CallContext';
import { useMusic } from '../context/MusicContext';
import { Attachment, MusicTrack } from '../types';
import { AdminInfoModal } from './AdminInfoModal';
import { AvatarChoiceModal } from './AvatarChoiceModal';
import { StoriesModal } from './StoriesModal';

interface InfoPanelProps {
  onClose: () => void;
  onOpenReport: () => void;
  onOpenMediaViewer: (att: Attachment) => void;
  onOpenSearch?: () => void;
}

export const InfoPanel: React.FC<InfoPanelProps> = ({ onClose, onOpenReport, onOpenMediaViewer, onOpenSearch }) => {
  const { user, registeredUsers } = useAuth();
  const { activeChat, messages, toggleMuteChat, deleteChat, chats, sendMessage } = useChat();
  const { startCall } = useCall();
  const { 
    playlist, 
    currentTrack, 
    isPlaying, 
    playTrack, 
    togglePlay, 
    downloadTrack, 
    setTrackToProfile,
    uploadCustomTrack 
  } = useMusic();

  const [activeMediaTab, setActiveMediaTab] = useState<'photos' | 'files' | 'links' | 'voice' | 'music'>('photos');
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [showAvatarChoice, setShowAvatarChoice] = useState(false);
  const [showStoriesModal, setShowStoriesModal] = useState(false);
  const [isAddStory, setIsAddStory] = useState(false);
  const [pinnedId, setPinnedId] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!activeChat) return null;

  const targetMember = activeChat.type === 'direct' ? activeChat.members?.find(m => m.userId !== user?.id) : null;
  const targetUser = targetMember ? registeredUsers.find(u => u.id === targetMember.userId) : null;

  const allAttachments: Attachment[] = messages.flatMap(m => m.attachments || []);
  const photoAttachments = allAttachments.filter(a => a.type === 'image' || a.type === 'video');
  const fileAttachments = allAttachments.filter(a => a.type === 'document');
  const voiceAttachments = allAttachments.filter(a => a.type === 'voice');
  const chatMusicAttachments = allAttachments.filter(a => a.type === 'audio' || a.mimeType?.includes('audio') || a.name?.toLowerCase().endsWith('.mp3'));

  const linkMatches: { id: string; url: string; text: string; time: string }[] = [];
  messages.forEach(m => {
    if (m.text) {
      const urlRegex = /(https?:\/\/[^\s]+)/g;
      const matches = m.text.match(urlRegex);
      if (matches) {
        matches.forEach(url => {
          linkMatches.push({
            id: `link_${m.id}_${url}`,
            url,
            text: m.text,
            time: m.time
          });
        });
      }
    }
  });

  // Common groups logic
  const commonGroups = chats.filter(c => 
    (c.type === 'group' || c.type === 'channel') && 
    c.members?.some(m => m.userId === targetUser?.id)
  );

  const handlePinTrack = async (track: MusicTrack) => {
    try {
      await setTrackToProfile(track);
      setPinnedId(track.id);
      setTimeout(() => setPinnedId(null), 3000);
    } catch (e) {
      alert("Не удалось прикрепить трек к профилю");
    }
  };

  const handleDownload = async (track: MusicTrack) => {
    setDownloadingId(track.id);
    await downloadTrack(track);
    setTimeout(() => setDownloadingId(null), 1000);
  };

  const handleUploadAndSendMusic = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const newTrack = await uploadCustomTrack(file);
      await sendMessage(
        `🎵 Музыкальный трек: ${newTrack.artist} - ${newTrack.title}`,
        undefined,
        [{
          id: `att_mus_${Date.now()}`,
          name: `${newTrack.artist} - ${newTrack.title}.mp3`,
          size: file.size || 3500000,
          mimeType: 'audio/mp3',
          url: newTrack.url,
          type: 'audio',
          duration: newTrack.duration
        }]
      );
    } catch (err) {
      console.error(err);
      alert("Ошибка при загрузке аудиофайла");
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full md:w-80 lg:w-96 bg-[var(--background)] border-l border-[var(--border)] flex flex-col h-full overflow-y-auto animate-fadeIn shrink-0 text-[var(--text-primary)] select-none pb-[calc(env(safe-area-inset-bottom)+8px)] md:pb-0 z-50 fixed inset-0 md:relative">
      
      {/* Top Header */}
      <div className="p-4 border-b border-[var(--border)] flex items-center justify-between shrink-0 bg-[var(--background)] pt-6 md:pt-4">
        <h3 className="font-semibold text-[15px] text-[var(--text-primary)] tracking-tight px-2">
          {activeChat.type === 'direct' ? 'Профиль пользователя' : 'Информация о чате'}
        </h3>
        <button onClick={onClose} className="p-2 hover:bg-[var(--surface-hover)] rounded-full text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Profile Overview */}
      <div className="p-6 flex flex-col items-center text-center shrink-0">
        <div 
          onClick={() => setShowAvatarChoice(true)} 
          className="relative mb-4 cursor-pointer group"
          title="Нажмите для выбора: Аватарка или История"
        >
          <img
            src={activeChat.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${activeChat.name}`}
            alt={activeChat.name}
            className="w-28 h-28 rounded-full object-cover border-4 border-[var(--border)] shadow-xl group-hover:border-[var(--accent)] transition-all"
          />
          <span className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-[var(--success)] border-4 border-[var(--background)]" />
          <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white text-[10px] font-bold">
            <span>Аватарка / История</span>
          </div>
        </div>

        <div className="flex items-center justify-center gap-1.5">
          <h2 className="text-xl font-bold text-[var(--text-primary)] tracking-tight">{activeChat.name}</h2>
          {(targetUser?.isAdmin || (activeChat.type === 'direct' && activeChat.username?.toLowerCase() === 'den')) && (
            <CheckCircle2 className="w-5 h-5 fill-blue-500 text-white shrink-0" title="Подтверждённый профиль (Администратор)" />
          )}
          {targetUser?.isModerator && !targetUser?.isAdmin && (
            <CheckCircle2 className="w-5 h-5 fill-emerald-500 text-white shrink-0" title="Модератор системы Zentora" />
          )}
        </div>

        {/* Username */}
        {(activeChat.username || targetUser?.username) && (
          <p className="text-[13px] font-mono text-[var(--accent)] mt-1">
            @{activeChat.username || targetUser?.username}
          </p>
        )}

        {/* Status */}
        <p className="text-xs text-[var(--success)] font-bold mt-1">В сети</p>

        {/* Quick Call Actions for Direct Chat */}
        {activeChat.type === 'direct' && targetMember && (
          <div className="flex items-center justify-center gap-3 w-full mt-4">
            <button
              onClick={() => {
                startCall(
                  activeChat.id,
                  {
                    id: targetMember.userId,
                    name: activeChat.name,
                    avatar: activeChat.avatar || ''
                  },
                  'audio'
                );
                onClose();
              }}
              className="flex-1 py-2 px-3 rounded-xl bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-xs font-semibold text-[var(--accent)] flex items-center justify-center gap-1.5 transition-all shadow-sm active:scale-95"
            >
              <Phone className="w-4 h-4" />
              <span>Звонок</span>
            </button>

            <button
              onClick={() => {
                startCall(
                  activeChat.id,
                  {
                    id: targetMember.userId,
                    name: activeChat.name,
                    avatar: activeChat.avatar || ''
                  },
                  'video'
                );
                onClose();
              }}
              className="flex-1 py-2 px-3 rounded-xl bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-xs font-semibold text-[var(--accent)] flex items-center justify-center gap-1.5 transition-all shadow-sm active:scale-95"
            >
              <Video className="w-4 h-4" />
              <span>Видео</span>
            </button>
          </div>
        )}

        {/* Description / Bio */}
        <div className="w-full mt-3 text-left px-1">
          <p className="text-[11px] font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-1">Обо мне:</p>
          <p className="text-[13px] text-[var(--text-primary)] font-mono bg-[var(--surface)] p-2.5 rounded-xl border border-[var(--border)]">
            {activeChat.description || targetUser?.bio || 'mrz.whathefuck?'}
          </p>
        </div>

        {/* Integrations (Screenshot 4) */}
        {activeChat.type === 'direct' && (
          <div className="w-full mt-4 text-left">
            <p className="text-[11px] font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-2">Интеграции:</p>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--surface)] border border-[var(--border)]">
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">Ds</div>
                  <div>
                    <div className="flex items-center gap-1">
                      <p className="text-xs font-bold text-[var(--text-primary)]">Discord</p>
                      <span className="text-indigo-400 text-xs">✓</span>
                    </div>
                    <p className="text-[10px] text-[var(--text-secondary)] font-mono">discord.gg/U3VvcfN2HR</p>
                  </div>
                </div>
                <span className="text-xs text-[var(--text-secondary)]">↗</span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--surface)] border border-[var(--border)]">
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs">Tg</div>
                  <div>
                    <div className="flex items-center gap-1">
                      <p className="text-xs font-bold text-[var(--text-primary)]">Telegram</p>
                      <span className="text-sky-400 text-xs">✓</span>
                    </div>
                    <p className="text-[10px] text-[var(--text-secondary)] font-mono">t.me/Les4iyBIO</p>
                  </div>
                </div>
                <span className="text-xs text-[var(--text-secondary)]">↗</span>
              </div>
            </div>
          </div>
        )}

        {/* Comments / Wall (Screenshot 4) */}
        {activeChat.type === 'direct' && (
          <div className="w-full mt-4 text-left">
            <p className="text-[11px] font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-2">Комментарии:</p>
            <div className="space-y-2">
              {[
                { name: 'Kazoo', date: '17.07.2026', text: 'фимоз', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=Kazoo' },
                { name: 'FeeNick22', date: '05.06.2026', text: 'laptop top leshiy', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=FeeNick22' },
                { name: 'Profit77', date: '10.04.2026', text: 'сладкий', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=Profit77' },
                { name: 'senliks', date: '09.04.2026', text: '...', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=senliks' }
              ].map((c, idx) => (
                <div key={idx} className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--surface)] border border-[var(--border)]">
                  <div className="flex items-center gap-2.5">
                    <img src={c.avatar} alt={c.name} className="w-7 h-7 rounded-full object-cover" />
                    <div>
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-[var(--text-primary)]">{c.name}</span>
                        <span className="text-[10px] text-purple-400">👤✓</span>
                      </div>
                      <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">{c.text}</p>
                    </div>
                  </div>
                  <span className="text-[10px] text-[var(--text-secondary)] font-mono">{c.date}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Phone number */}
        <div className="flex items-center gap-2 mt-3 text-xs text-[var(--text-primary)] bg-[var(--surface)] px-3 py-1.5 rounded-2xl border border-[var(--border)]">
          <Smartphone className="w-4 h-4 text-[var(--accent)]" />
          <span>{targetUser?.phone || '+7 (999) 123-45-67'}</span>
        </div>

        {/* Shared Groups & Contacts */}
        {activeChat.type === 'direct' && (
          <div className="w-full mt-4 grid grid-cols-2 gap-2 text-left text-xs">
            <div className="bg-[var(--surface)] p-3 rounded-2xl border border-[var(--border)]">
              <div className="flex items-center gap-1.5 text-[var(--text-secondary)] mb-1 font-bold">
                <Users className="w-4 h-4 text-[var(--accent)]" />
                <span>Общие группы</span>
              </div>
              <p className="font-bold text-sm text-[var(--text-primary)]">{commonGroups.length || 1}</p>
            </div>
            <div className="bg-[var(--surface)] p-3 rounded-2xl border border-[var(--border)]">
              <div className="flex items-center gap-1.5 text-[var(--text-secondary)] mb-1 font-bold">
                <UserCheck className="w-4 h-4 text-[var(--success)]" />
                <span>Общие контакты</span>
              </div>
              <p className="font-bold text-sm text-[var(--text-primary)]">3</p>
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="px-4 pb-6 border-b border-[var(--border)] grid grid-cols-3 gap-2 shrink-0 text-xs font-medium">
        <button
          onClick={() => toggleMuteChat(activeChat.id)}
          className="flex flex-col items-center gap-1.5 py-2.5 bg-[var(--surface)] border border-[var(--border)] rounded-2xl hover:bg-[var(--surface-hover)] transition-colors active:scale-95 text-[var(--text-primary)]"
        >
          <Bell className={`w-4 h-4 ${activeChat.isMuted ? 'text-[var(--danger)]' : 'text-[var(--text-secondary)]'}`} />
          <span className="text-[11px]">{activeChat.isMuted ? 'Вкл звук' : 'Без звука'}</span>
        </button>

        {onOpenSearch && (
          <button
            onClick={onOpenSearch}
            className="flex flex-col items-center gap-1.5 py-2.5 bg-[var(--surface)] border border-[var(--border)] rounded-2xl hover:bg-[var(--surface-hover)] transition-colors text-[var(--text-secondary)] active:scale-95"
          >
            <Search className="w-4 h-4" />
            <span className="text-[11px]">Поиск</span>
          </button>
        )}

        <button
          onClick={() => setIsBlocked(!isBlocked)}
          className={`flex flex-col items-center gap-1.5 py-2.5 bg-[var(--surface)] border border-[var(--border)] rounded-2xl transition-colors active:scale-95 ${
            isBlocked ? 'text-[var(--danger)] bg-[var(--danger)]/10 border-[var(--danger)]/30' : 'text-[var(--text-secondary)] hover:bg-[var(--surface-hover)]'
          }`}
        >
          <Ban className="w-4 h-4" />
          <span className="text-[11px]">{isBlocked ? 'Заблок.' : 'Блок'}</span>
        </button>

        <button
          onClick={onOpenReport}
          className="flex flex-col items-center gap-1.5 py-2.5 bg-[var(--surface)] border border-[var(--border)] rounded-2xl hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] transition-colors active:scale-95"
        >
          <Flag className="w-4 h-4 text-[var(--danger)]/80" />
          <span className="text-[11px]">Жалоба</span>
        </button>

        <button
          onClick={() => {
            deleteChat(activeChat.id);
            onClose();
          }}
          className="flex flex-col items-center gap-1.5 py-2.5 bg-[var(--danger)]/10 text-[var(--danger)] border border-[var(--danger)]/20 rounded-2xl hover:bg-[var(--danger)]/20 transition-colors active:scale-95"
        >
          <Trash2 className="w-4 h-4" />
          <span className="text-[11px]">Удалить</span>
        </button>
      </div>

      {/* Encryption Indicator Card */}
      <div className="mx-4 mt-4 p-3 bg-[var(--accent)]/[0.04] border border-dashed border-[var(--accent)]/25 rounded-2xl flex items-center gap-3">
        <Lock className="w-4 h-4 text-[var(--accent)] shrink-0" />
        <div className="min-w-0">
          <p className="text-xs font-bold text-[var(--text-primary)]">End-to-End шифрование</p>
          <p className="text-[10px] text-[var(--text-secondary)]">Сообщения защищены сквозным шифрованием.</p>
        </div>
      </div>

      {/* Media Tabs Header & Content */}
      <div className="p-4 md:p-6 flex-1 flex flex-col min-h-0 overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[var(--border)] mb-4 text-xs font-semibold overflow-x-auto no-scrollbar gap-1">
          {[
            { id: 'photos', label: 'Медиа' },
            { id: 'files', label: 'Файлы' },
            { id: 'links', label: 'Ссылки' },
            { id: 'voice', label: 'Голосовые' },
            { id: 'music', label: 'Музыка' }
          ].map(t => {
            const isSel = activeMediaTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveMediaTab(t.id as any)}
                className={`pb-2 px-2.5 relative transition-all whitespace-nowrap cursor-pointer text-xs ${
                  isSel
                    ? 'text-[#0090FF] font-bold border-b-2 border-[#0090FF]'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Photos / Media Grid */}
        {activeMediaTab === 'photos' && (
          <div className="grid grid-cols-3 gap-2">
            {photoAttachments.length === 0 ? (
              <p className="col-span-3 text-center text-xs text-[var(--text-secondary)] py-6">Нет отправленных медиафайлов.</p>
            ) : (
              photoAttachments.map(att => (
                <div
                  key={att.id}
                  onClick={() => onOpenMediaViewer(att)}
                  className="aspect-square rounded-xl overflow-hidden bg-[var(--surface-hover)] cursor-pointer hover:opacity-80 transition-opacity border border-[var(--border)]"
                >
                  <img src={att.url} alt={att.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              ))
            )}
          </div>
        )}

        {/* Files List */}
        {activeMediaTab === 'files' && (
          <div className="space-y-2">
            {fileAttachments.length === 0 ? (
              <p className="text-center text-xs text-[var(--text-secondary)] py-6">Нет отправленных документов.</p>
            ) : (
              fileAttachments.map(att => (
                <a
                  key={att.id}
                  href={att.url}
                  download={att.name}
                  className="flex items-center gap-3 p-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)] hover:bg-[var(--surface-hover)] transition-colors text-xs"
                >
                  <FileText className="w-5 h-5 text-[var(--accent)] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-[var(--text-primary)] truncate">{att.name}</p>
                    <p className="text-[10px] text-[var(--text-secondary)]">{Math.round(att.size / 1024)} КБ</p>
                  </div>
                </a>
              ))
            )}
          </div>
        )}

        {/* Links List */}
        {activeMediaTab === 'links' && (
          <div className="space-y-2">
            {linkMatches.length === 0 ? (
              <p className="text-center text-xs text-[var(--text-secondary)] py-6">Нет отправленных ссылок.</p>
            ) : (
              linkMatches.map(link => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 p-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)] hover:bg-[var(--surface-hover)] transition-colors text-xs"
                >
                  <Link className="w-5 h-5 text-[var(--accent)] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-[var(--text-primary)] truncate">{link.url}</p>
                    <p className="text-[10px] text-[var(--text-secondary)] truncate">{link.text}</p>
                  </div>
                </a>
              ))
            )}
          </div>
        )}

        {/* Voice List */}
        {activeMediaTab === 'voice' && (
          <div className="space-y-2">
            {voiceAttachments.length === 0 ? (
              <p className="text-center text-xs text-[var(--text-secondary)] py-6">Нет голосовых сообщений.</p>
            ) : (
              voiceAttachments.map(att => (
                <div
                  key={att.id}
                  className="flex items-center gap-3 p-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)] text-xs"
                >
                  <Mic className="w-5 h-5 text-[var(--accent)] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-[var(--text-primary)] truncate">Голосовое сообщение</p>
                    <p className="text-[10px] text-[var(--text-secondary)]">{att.duration ? `${Math.floor(att.duration / 60)}:${String(Math.floor(att.duration % 60)).padStart(2, '0')}` : 'Голосовое'}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Music Tab (Listen, Download, Pin to Profile) */}
        {activeMediaTab === 'music' && (
          <div className="space-y-3">
            {/* Action to upload custom music to chat */}
            <input
              type="file"
              ref={fileInputRef}
              accept="audio/*,.mp3,.wav,.ogg"
              onChange={handleUploadAndSendMusic}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-2 px-3 rounded-xl bg-[var(--accent)]/15 border border-[var(--accent)]/30 text-[var(--accent)] hover:bg-[var(--accent)] hover:text-[var(--message-sent-text)] transition-all text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <Upload className="w-4 h-4" />
              <span>Загрузить MP3 в чат</span>
            </button>

            {/* List Chat Music & Playlist */}
            {chatMusicAttachments.length > 0 && (
              <div className="space-y-2">
                <p className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                  Из сообщений чата:
                </p>
                {chatMusicAttachments.map(att => {
                  const asTrack: MusicTrack = {
                    id: att.id,
                    title: att.name || 'Аудиозапись',
                    artist: activeChat.name,
                    url: att.url,
                    cover: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
                    duration: att.duration || 180
                  };
                  const isCur = currentTrack?.url === att.url;
                  return (
                    <div
                      key={att.id}
                      className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                        isCur
                          ? 'bg-[var(--accent)]/15 border-[var(--accent)]/30 text-[var(--accent)]'
                          : 'bg-[var(--surface)] border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--surface-hover)]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <button
                          onClick={() => {
                            if (isCur) {
                              togglePlay();
                            } else {
                              playTrack(asTrack);
                            }
                          }}
                          className="w-8 h-8 rounded-lg bg-[var(--accent)] text-[var(--message-sent-text)] flex items-center justify-center shrink-0 cursor-pointer shadow-sm"
                        >
                          {isCur && isPlaying ? (
                            <Pause className="w-4 h-4 fill-current" />
                          ) : (
                            <Play className="w-4 h-4 fill-current ml-0.5" />
                          )}
                        </button>
                        <div className="min-w-0 flex-1">
                          <p className="font-bold text-xs truncate">{att.name}</p>
                          <p className="text-[10px] text-[var(--text-secondary)] truncate">
                            {Math.round(att.size / 1024)} КБ
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0 ml-2">
                        <button
                          onClick={() => handleDownload(asTrack)}
                          className="p-1.5 rounded-lg text-[var(--text-secondary)] hover:text-emerald-400 hover:bg-[var(--surface-hover)] transition-colors cursor-pointer"
                          title="Скачать трек"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handlePinTrack(asTrack)}
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            user?.profileTrack?.url === att.url || pinnedId === att.id
                              ? 'text-blue-400 bg-blue-500/10'
                              : 'text-[var(--text-secondary)] hover:text-amber-400 hover:bg-[var(--surface-hover)]'
                          }`}
                          title="Вставить в профиль"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Recommended / Library Tracks */}
            <div className="space-y-2 pt-1">
              <p className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                Популярная музыка:
              </p>
              {playlist.slice(0, 5).map(t => {
                const isCur = currentTrack?.id === t.id;
                return (
                  <div
                    key={t.id}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                      isCur
                        ? 'bg-[var(--accent)]/15 border-[var(--accent)]/30 text-[var(--accent)]'
                        : 'bg-[var(--surface)] border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--surface-hover)]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <button
                        onClick={() => {
                          if (isCur) {
                            togglePlay();
                          } else {
                            playTrack(t);
                          }
                        }}
                        className="w-8 h-8 rounded-lg bg-[var(--accent)] text-[var(--message-sent-text)] flex items-center justify-center shrink-0 cursor-pointer shadow-sm"
                      >
                        {isCur && isPlaying ? (
                          <Pause className="w-4 h-4 fill-current" />
                        ) : (
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        )}
                      </button>
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-xs truncate">{t.title}</p>
                        <p className="text-[10px] text-[var(--text-secondary)] truncate">{t.artist}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      <button
                        onClick={() => handleDownload(t)}
                        className="p-1.5 rounded-lg text-[var(--text-secondary)] hover:text-emerald-400 hover:bg-[var(--surface-hover)] transition-colors cursor-pointer"
                        title="Скачать трек"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handlePinTrack(t)}
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                          user?.profileTrack?.id === t.id || pinnedId === t.id
                            ? 'text-blue-400 bg-blue-500/10'
                            : 'text-[var(--text-secondary)] hover:text-amber-400 hover:bg-[var(--surface-hover)]'
                        }`}
                        title="Вставить в профиль"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>

      <AdminInfoModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        adminName={activeChat.name}
      />

      {/* Avatar Choice Modal (Аватарка или История) */}
      {showAvatarChoice && (
        <AvatarChoiceModal
          user={{
            id: activeChat.id,
            name: activeChat.name,
            avatar: activeChat.avatar,
            username: activeChat.username || targetUser?.username
          }}
          isSelf={user?.id === targetUser?.id}
          onClose={() => setShowAvatarChoice(false)}
          onViewAvatar={() => {
            if (activeChat.avatar) {
              onOpenMediaViewer({
                id: 'active_avatar',
                type: 'image',
                url: activeChat.avatar,
                name: activeChat.name
              });
            }
          }}
          onOpenStories={(addStory) => {
            setIsAddStory(!!addStory);
            setShowStoriesModal(true);
          }}
        />
      )}

      {/* Stories Modal */}
      {showStoriesModal && user && (
        <StoriesModal
          currentUser={user}
          isOpen={showStoriesModal}
          initialAdd={isAddStory}
          onClose={() => setShowStoriesModal(false)}
        />
      )}

    </div>
  );
};
