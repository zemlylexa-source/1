import React from 'react';
import { Play, Pause, SkipForward, X, Music, Download, Maximize2, Disc } from 'lucide-react';
import { useMusic } from '../context/MusicContext';

export const FloatingMusicBar: React.FC = () => {
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    togglePlay,
    stopMusic,
    nextTrack,
    downloadTrack,
    setIsFullPlayerOpen,
    isMiniPlayerOpen,
    setIsMiniPlayerOpen
  } = useMusic();

  if (!isMiniPlayerOpen || !currentTrack) return null;

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed bottom-20 md:bottom-4 left-1/2 -translate-x-1/2 z-40 w-[92%] max-w-md bg-[var(--surface)]/95 backdrop-blur-xl border border-[var(--border)] rounded-2xl shadow-2xl overflow-hidden p-2.5 flex flex-col gap-1.5 animate-fadeIn select-none text-[var(--text-primary)]">
      
      {/* Tiny top progress line */}
      <div className="w-full bg-[var(--border)] h-1 rounded-full overflow-hidden">
        <div
          className="bg-[var(--accent)] h-full transition-all duration-300 rounded-full"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="flex items-center justify-between gap-3 px-1">
        {/* Cover & Info (clickable to open full player) */}
        <div
          onClick={() => setIsFullPlayerOpen(true)}
          className="flex items-center gap-2.5 min-w-0 flex-1 cursor-pointer group"
          title="Открыть полный плеер"
        >
          <div className="relative w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-white/10 shadow-sm">
            <img
              src={currentTrack.cover}
              alt={currentTrack.title}
              className={`w-full h-full object-cover ${isPlaying ? 'scale-105' : ''}`}
            />
            {isPlaying && (
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                <Disc className="w-4 h-4 text-white animate-spin" />
              </div>
            )}
          </div>

          <div className="min-w-0 flex-1">
            <h4 className="font-bold text-xs truncate group-hover:text-[var(--accent)] transition-colors">
              {currentTrack.title}
            </h4>
            <p className="text-[10px] text-[var(--text-secondary)] truncate">
              {currentTrack.artist} • <span className="font-mono">{formatTime(currentTime)}</span>
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => downloadTrack(currentTrack)}
            className="p-2 rounded-xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-hover)] transition-all cursor-pointer"
            title="Скачать трек (MP3)"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={togglePlay}
            className="w-9 h-9 rounded-xl bg-[var(--accent)] text-[var(--message-sent-text)] flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer"
            title={isPlaying ? 'Пауза' : 'Воспроизвести'}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          <button
            onClick={nextTrack}
            className="p-2 rounded-xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-hover)] transition-all cursor-pointer"
            title="Следующий трек"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsFullPlayerOpen(true)}
            className="p-2 rounded-xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-hover)] transition-all cursor-pointer hidden sm:block"
            title="Развернуть"
          >
            <Maximize2 className="w-4 h-4" />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsMiniPlayerOpen(false);
            }}
            className="p-2 rounded-xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-hover)] transition-all cursor-pointer"
            title="Закрыть мини-плеер"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
