import React, { useState, useEffect } from 'react';
import { X, ShieldAlert, Users, Radio, AlertOctagon, Ban, RefreshCw, ShieldCheck, UserPlus, UserMinus, CheckCircle2, Trash2, UserX, AlertTriangle } from 'lucide-react';
import { User, Report } from '../types';
import { useAuth } from '../context/AuthContext';
import { db, cleanObject } from '../lib/firebase';
import { UserAvatar, DELETED_ACCOUNT_NAME } from './UserAvatar';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  query, 
  orderBy,
  getDocs
} from 'firebase/firestore';

interface AdminPanelModalProps {
  onClose: () => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({ onClose }) => {
  const { user: curdentUser, setUserModeratorStatus, banUser, unbanUser } = useAuth();
  const [stats, setStats] = useState({
    totalUsers: 0,
    onlineUsers: 0,
    activeSessions: 0,
    reportsCount: 0,
    systemUptime: 3600
  });

  const [users, setUsers] = useState<User[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [activeAdminTab, setActiveAdminTab] = useState<'users' | 'reports'>('users');
  const [loading, setLoading] = useState(false);
  const [targetUserToDelete, setTargetUserToDelete] = useState<User | null>(null);
  const [deleteReasonInput, setDeleteReasonInput] = useState('Нарушение правил сообщества Zentora');
  const [banDurationMinutes, setBanDurationMinutes] = useState<number>(0); // 0 = permanent
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!curdentUser?.isAdmin && curdentUser?.username?.toLowerCase() !== 'den') {
      onClose();
      return;
    }

    setLoading(true);
    
    // Listen to all users
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const usersList: User[] = [];
      let online = 0;
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as Partial<User>;
        delete data.twoFASecret;
        delete (data as any)._pwdHash;
        const u: User = {
          ...data,
          id: data.id || docSnap.id,
          name: data.name || data.username || 'Пользователь',
          username: data.username || 'user',
          email: data.email || '',
          avatar: data.avatar || '',
          status: data.status || 'offline',
          createdAt: data.createdAt ? String(data.createdAt) : Date.now().toString()
        } as User;
        usersList.push(u);
        if (u.status === 'online' && !u.isDeleted) online++;
      });
      setUsers(usersList);
      setStats(prev => ({
        ...prev,
        totalUsers: usersList.length,
        onlineUsers: online,
        activeSessions: online + 1
      }));
      setLoading(false);
    }, (err) => {
      console.warn("Admin panel users error:", err);
      setLoading(false);
    });

    // Listen to reports
    const unsubReports = onSnapshot(collection(db, 'reports'), (snapshot) => {
      const reportsList: Report[] = [];
      snapshot.forEach(docSnap => reportsList.push({ ...docSnap.data(), id: docSnap.id } as Report));
      setReports(reportsList);
      setStats(prev => ({ ...prev, reportsCount: reportsList.length }));
    }, (err) => {
      console.warn("Admin panel reports error:", err);
    });

    return () => {
      unsubUsers();
      unsubReports();
    };
  }, [curdentUser, onClose]);

  const showNotification = (msg: string) => {
    setActionSuccessMessage(msg);
    setTimeout(() => setActionSuccessMessage(null), 3500);
  };

  // Soft deletion / block (Telegram-style): Deletes personal info, sets Deleted Account avatar & specific deletion reason in Bio
  const handleDeleteAndBlockUser = async (targetUser: User, customReason?: string, customDuration?: number) => {
    if (targetUser.username?.toLowerCase() === 'den' || targetUser.isAdmin) {
      alert('Нельзя заблокировать главного администратора Den!');
      return;
    }

    const reason = customReason || deleteReasonInput.trim() || 'Нарушение правил сообщества Zentora';
    const duration = customDuration !== undefined ? customDuration : banDurationMinutes;

    try {
      await banUser(targetUser.id, duration === 0 ? { isPermanent: true } : { minutes: duration }, reason);
      setTargetUserToDelete(null);
      showNotification(`Аккаунт @${targetUser.username} заблокирован${duration > 0 ? ` на ${duration} мин.` : ' навсегда'}.`);
    } catch (e) {
      console.error("Error banning user:", e);
      alert("Ошибка при блокировке аккаунта");
    }
  };

  // Restore deleted user back to active
  const handleRestoreUser = async (targetUser: User) => {
    try {
      await unbanUser(targetUser.id);
      showNotification(`Аккаунт @${targetUser.username} успешно восстановлен.`);
    } catch (e) {
      console.error(e);
      alert("Ошибка при восстановлении");
    }
  };

  const handleToggleModerator = async (userId: string, isCurdentlyModerator: boolean) => {
    if (curdentUser?.username?.toLowerCase() !== 'den' && curdentUser?.id !== 'usr_admin_den') {
      alert('Только Den может изменять права модераторов');
      return;
    }
    const newModerState = !isCurdentlyModerator;
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, isModerator: newModerState } : u));
    await setUserModeratorStatus(userId, newModerState);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--background)]/80 backdrop-blur-md p-4 animate-fadeIn text-[var(--text-primary)] select-none">
      <div className="w-full max-w-4xl h-[85vh] max-h-[700px] bg-[var(--surface)] border border-[var(--border)] rounded-3xl shadow-2xl overflow-hidden flex flex-col relative">
        
        {/* Toast Alert */}
        {actionSuccessMessage && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white px-4 py-2 rounded-2xl shadow-xl text-xs font-bold flex items-center gap-2 animate-fadeIn border border-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>{actionSuccessMessage}</span>
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[var(--background)] border-b border-[var(--border)] shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-[var(--danger)]/10 text-[var(--danger)] border border-[var(--danger)]/30">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[var(--text-primary)] font-mono">Консоль администратора Zentora</h2>
              <p className="text-xs text-[var(--text-secondary)]">Управление безопасностью и модерацией</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={onClose} className="p-2 rounded-xl hover:bg-[var(--surface-hover)] cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-6 bg-[var(--background)]/50 border-b border-[var(--border)] shrink-0 text-xs">
          <div className="p-3 bg-[var(--surface)] rounded-2xl border border-[var(--border)] flex items-center gap-3">
            <Users className="w-5 h-5 text-[var(--accent)]" />
            <div>
              <p className="text-[var(--text-secondary)]">Пользователи</p>
              <p className="text-lg font-bold font-mono text-[var(--text-primary)]">{stats.totalUsers}</p>
            </div>
          </div>

          <div className="p-3 bg-[var(--surface)] rounded-2xl border border-[var(--border)] flex items-center gap-3">
            <Radio className="w-5 h-5 text-[var(--success)]" />
            <div>
              <p className="text-[var(--text-secondary)]">В сети</p>
              <p className="text-lg font-bold font-mono text-[var(--success)]">{stats.onlineUsers}</p>
            </div>
          </div>

          <div className="p-3 bg-[var(--surface)] rounded-2xl border border-[var(--border)] flex items-center gap-3">
            <AlertOctagon className="w-5 h-5 text-[var(--accent)]" />
            <div>
              <p className="text-[var(--text-secondary)]">Жалобы</p>
              <p className="text-lg font-bold font-mono text-[var(--accent)]">{stats.reportsCount}</p>
            </div>
          </div>

          <div className="p-3 bg-[var(--surface)] rounded-2xl border border-[var(--border)] flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-[var(--accent)]" />
            <div>
              <p className="text-[var(--text-secondary)]">Активные сессии</p>
              <p className="text-lg font-bold font-mono text-[var(--text-primary)]">{stats.activeSessions}</p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs inside Modal */}
        <div className="flex border-b border-[var(--border)] px-6 bg-[var(--background)]/30 text-xs font-bold">
          <button
            onClick={() => setActiveAdminTab('users')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeAdminTab === 'users'
                ? 'border-[var(--accent)] text-[var(--accent)]'
                : 'border-transpadent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Управление аккаунтами ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('reports')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeAdminTab === 'reports'
                ? 'border-[var(--accent)] text-[var(--accent)]'
                : 'border-transpadent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <AlertOctagon className="w-4 h-4" />
            <span>Жалобы ({reports.length})</span>
          </button>
        </div>

        {/* Modal Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeAdminTab === 'users' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[var(--accent)]/10 border border-[var(--accent)]/30 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-[var(--accent)] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <p className="font-bold text-[var(--accent)] mb-1">Система управления и удаления аккаунтов (Telegram-стиль)</p>
                  <p className="text-[var(--text-secondary)] leading-relaxed">
                    При блокировке аккаунт превращается в <strong className="text-[var(--text-primary)]">«Удалённый аккаунт»</strong>. Аватарка заменяется на специальную заглушку удалённого профиля, а в описании (Bio) выводится официальное сообщение о том, что данный аккаунт был удален за иную причину.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {users.map((u, idx) => {
                  const isDeleted = u.isDeleted || u.status === 'deleted';
                  return (
                    <div
                      key={u.id || `admin-user-${u.username || idx}`}
                      className={`flex items-center justify-between p-4 rounded-2xl border text-xs transition-all ${
                        isDeleted 
                          ? 'bg-red-500/5 border-red-500/30 dark:border-red-900/40' 
                          : 'bg-[var(--background)] border-[var(--border)]'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <UserAvatar
                          user={u}
                          isDeleted={isDeleted}
                          size="md"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`font-bold text-sm ${isDeleted ? 'text-slate-400 line-through' : 'text-[var(--text-primary)]'}`}>
                              {isDeleted ? DELETED_ACCOUNT_NAME : u.name}
                            </span>
                            <span className="text-[var(--accent)] font-mono">@{u.username}</span>
                            {u.isAdmin && (
                              <CheckCircle2 className="w-4 h-4 fill-blue-500 text-white shrink-0" title="Главный администратор" />
                            )}
                            {u.isModerator && !u.isAdmin && (
                              <CheckCircle2 className="w-4 h-4 fill-emerald-500 text-white shrink-0" title="Модератор" />
                            )}
                            {isDeleted && (
                              <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 font-bold text-[10px] border border-red-500/30">
                                Удалён / Заблокирован
                              </span>
                            )}
                          </div>
                          <p className="text-[var(--text-secondary)] mt-0.5 truncate">
                            {isDeleted 
                              ? `Статус: Данный аккаунт был удален (${u.deleteReason || 'Администрацией'})` 
                              : `${u.email} • Зарегистрирован ${new Date(Number(u.createdAt) || Date.now()).toLocaleDateString()}`}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 ml-2">
                        {/* Only den can toggle moderators, and cannot toggle himself */}
                        {curdentUser?.username?.toLowerCase() === 'den' && u.username?.toLowerCase() !== 'den' && !isDeleted && (
                          <button
                            onClick={() => handleToggleModerator(u.id, !!u.isModerator)}
                            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                              u.isModerator 
                                ? 'bg-[var(--success)]/10 hover:bg-[var(--success)]/20 text-[var(--success)]' 
                                : 'bg-[var(--accent)]/10 hover:bg-[var(--accent)]/20 text-[var(--accent)]'
                            }`}
                          >
                            {u.isModerator ? <UserMinus className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                            <span>{u.isModerator ? 'Снять Moder' : 'Выдать Moder'}</span>
                          </button>
                        )}

                        {u.username?.toLowerCase() !== 'den' && (
                          isDeleted ? (
                            <button
                              onClick={() => handleRestoreUser(u)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                              title="Восстановить аккаунт"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>Восстановить</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setTargetUserToDelete(u);
                                setDeleteReasonInput('Нарушение правил сообщества Zentora');
                              }}
                              className="px-3 py-1.5 rounded-xl bg-[var(--danger)]/10 hover:bg-[var(--danger)]/20 text-[var(--danger)] border border-[var(--danger)]/30 font-bold flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95"
                              title="Заблокировать и удалить аккаунт"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>Заблокировать</span>
                            </button>
                          )
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeAdminTab === 'reports' && (
            <div className="space-y-3">
              {reports.length === 0 ? (
                <div className="p-8 text-center text-[var(--text-secondary)] text-xs">Нет новых жалоб.</div>
              ) : (
                reports.map((r, idx) => (
                  <div
                    key={r.id || `admin-report-${idx}`}
                    className="p-4 rounded-2xl bg-[var(--background)] border border-[var(--border)] text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[var(--accent)]">Жалоба #{r.id.slice(0, 6)}</span>
                      <span className="text-[var(--text-secondary)] font-mono">{new Date(r.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-[var(--text-primary)] font-semibold">{r.reason}</p>
                    {r.details && <p className="text-[var(--text-secondary)] bg-[var(--surface)] p-2.5 rounded-xl border border-[var(--border)]">{r.details}</p>}
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Confirmation Modal for Block/Delete (Telegram-style) */}
        {targetUserToDelete && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fadeIn">
            <div className="w-full max-w-md bg-[var(--surface)] border border-red-500/40 rounded-3xl p-6 shadow-2xl space-y-4 animate-scaleUp">
              <div className="flex items-center gap-3 text-red-500">
                <div className="p-2.5 rounded-2xl bg-red-500/15 border border-red-500/30">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-[var(--text-primary)]">Заблокировать и удалить аккаунт?</h3>
                  <p className="text-xs text-[var(--text-secondary)]">Действие в стиле Telegram (Deleted Account)</p>
                </div>
              </div>

              <div className="p-3.5 bg-[var(--background)] rounded-2xl border border-[var(--border)] space-y-2 text-xs">
                <div className="flex items-center gap-3">
                  <UserAvatar user={targetUserToDelete} size="md" />
                  <div>
                    <p className="font-bold text-[var(--text-primary)]">{targetUserToDelete.name}</p>
                    <p className="text-[var(--accent)] font-mono">@{targetUserToDelete.username}</p>
                  </div>
                </div>
                <p className="text-[var(--text-secondary)] leading-relaxed text-[11px] pt-1 border-t border-[var(--border)]">
                  • Имя сменится на <strong>«Удалённый аккаунт»</strong><br/>
                  • Аватарка будет заменена на значок удаленного пользователя<br/>
                  • В описании появится статус: <em>«Данный аккаунт был удален за иную причину...»</em>
                </p>
              </div>

              <div>
                <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1.5">
                  Причина удаления (будет видна в профиле):
                </label>
                <input
                  type="text"
                  value={deleteReasonInput}
                  onChange={e => setDeleteReasonInput(e.target.value)}
                  placeholder="Укажите причину..."
                  className="w-full px-4 py-2.5 rounded-xl bg-[var(--input)] border border-[var(--border)] text-xs text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider block mb-1.5">
                  Срок блокировки:
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { label: 'Навсегда', value: 0 },
                    { label: '1 минута', value: 1 },
                    { label: '10 минут', value: 10 },
                    { label: '1 час', value: 60 },
                    { label: '24 часа', value: 1440 },
                    { label: '7 дней', value: 10080 },
                  ].map(d => (
                    <button
                      key={d.value}
                      type="button"
                      onClick={() => setBanDurationMinutes(d.value)}
                      className={`py-1.5 px-2 rounded-xl text-[11px] font-semibold transition-all border ${
                        banDurationMinutes === d.value
                          ? 'bg-red-500/20 text-red-300 border-red-500/50 shadow-sm'
                          : 'bg-[var(--surface-hover)] text-[var(--text-secondary)] border-transpadent hover:text-[var(--text-primary)]'
                      }`}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setTargetUserToDelete(null)}
                  className="flex-1 py-2.5 rounded-xl bg-[var(--surface-hover)] border border-[var(--border)] text-xs font-bold text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteAndBlockUser(targetUserToDelete, deleteReasonInput, banDurationMinutes)}
                  className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <Ban className="w-4 h-4" />
                  <span>{banDurationMinutes === 0 ? 'Удалить навсегда' : `Заблокировать`}</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
