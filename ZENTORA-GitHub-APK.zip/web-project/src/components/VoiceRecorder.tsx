import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, Send, Mic, Square } from 'lucide-react';
import { Attachment } from '../types';

interface VoiceRecorderProps {
  onSendVoice: (attachment: Attachment) => void;
  onCancel: () => void;
}

function createSyntheticVoiceWavUrl(seconds: number): string {
  const durationSecs = Math.max(1, Math.min(seconds, 60));
  const sampleRate = 8000;
  const numSamples = sampleRate * durationSecs;
  const buffer = new ArrayBuffer(44 + numSamples);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + numSamples, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate, true);
  view.setUint16(32, 1, true);
  view.setUint16(34, 8, true);
  writeString(36, 'data');
  view.setUint32(40, numSamples, true);

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const val = (Math.sin(2 * Math.PI * 280 * t) * 0.4 + Math.sin(2 * Math.PI * 440 * t) * 0.2 + Math.sin(2 * Math.PI * 180 * t) * 0.3) * (0.8 + 0.2 * Math.sin(t * 5));
    const sample = Math.floor(Math.max(-1, Math.min(1, val)) * 127 + 128);
    view.setUint8(44 + i, sample);
  }

  const blob = new Blob([buffer], { type: 'audio/wav' });
  return URL.createObjectURL(blob);
}

export const VoiceRecorder: React.FC<VoiceRecorderProps> = ({ onSendVoice, onCancel }) => {
  const [isRecording, setIsRecording] = useState(true);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [micVolume, setMicVolume] = useState(0); // 0 to 1

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const smoothVolRef = useRef(0);

  const waveformDataRef = useRef<number[]>([]);

  useEffect(() => {
    startRecording();

    return () => {
      stopRecordingCleanup();
    };
  }, []);

  const startRecording = async () => {
    waveformDataRef.current = [];

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("MediaDevices API unavailable");
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      audioChunksRef.current = [];

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      };

      mediaRecorder.start(100);
      setIsRecording(true);

      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const audioCtx = new AudioCtx();
        audioContextRef.current = audioCtx;
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 64;
        analyser.smoothingTimeConstant = 0.6;
        analyserRef.current = analyser;

        const source = audioCtx.createMediaStreamSource(stream);
        source.connect(analyser);
      }

      visualizeWaveform();

    } catch (err) {
      console.warn("Microphone access notice:", err);
      // Fallback timer if mic permissions blocked in iframe
      setIsRecording(true);
      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      visualizeWaveform();
    }
  };

  const visualizeWaveform = () => {
    const draw = () => {
      animationFrameRef.current = requestAnimationFrame(draw);
      if (!canvasRef.current) return;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let currentAvgVolume = 0;

      if (analyserRef.current) {
        const bufferLength = analyserRef.current.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyserRef.current.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        currentAvgVolume = (sum / bufferLength) / 255;
        const avgPercent = Math.round(currentAvgVolume * 100);
        waveformDataRef.current.push(avgPercent);
      } else {
        // Subtle fallback simulation if audio context is blocked
        currentAvgVolume = 0.15 + 0.15 * Math.sin(Date.now() / 200);
        waveformDataRef.current.push(Math.floor(Math.random() * 40) + 15);
      }

      // Smooth volume for UI reactive animations
      smoothVolRef.current = smoothVolRef.current * 0.7 + currentAvgVolume * 0.3;
      setMicVolume(smoothVolRef.current);

      // Render Dynamic Waveform on Canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const totalBars = 36;
      const barWidth = 3;
      const spacing = (canvas.width - totalBars * barWidth) / (totalBars - 1);
      const centerY = canvas.height / 2;
      const history = waveformDataRef.current;

      for (let i = 0; i < totalBars; i++) {
        const x = i * (barWidth + spacing);
        const dataIdx = history.length - totalBars + i;
        const rawVal = dataIdx >= 0 && history[dataIdx] ? history[dataIdx] : 10;
        
        // Voice-reactive bar height calculation
        const minHeight = 4;
        const dynamicBoost = smoothVolRef.current * 18;
        const calculatedHeight = Math.min(canvas.height - 2, Math.max(minHeight, (rawVal / 100) * (canvas.height - 4) + dynamicBoost));

        ctx.fillStyle = '#ffffff';
        ctx.globalAlpha = 0.75 + smoothVolRef.current * 0.25;

        // Rounded pill bars
        const radius = barWidth / 2;
        const yTop = centerY - calculatedHeight / 2;
        ctx.beginPath();
        ctx.roundRect(x, yTop, barWidth, calculatedHeight, radius);
        ctx.fill();
      }
    };

    draw();
  };

  const stopRecordingCleanup = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      } catch (e) {
        console.warn("Cleanup stream notice:", e);
      }
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (e) {
        console.warn("AudioContext close notice:", e);
      }
    }
  };

  const handleStopRecording = () => {
    stopRecordingCleanup();
    setIsRecording(false);
    setMicVolume(0);
    if (!audioUrl) {
      const simUrl = createSyntheticVoiceWavUrl(recordingTime || 2);
      setAudioUrl(simUrl);
    }
  };

  const handleTogglePlayPreview = () => {
    const playUrl = audioUrl || createSyntheticVoiceWavUrl(recordingTime || 2);
    if (!playUrl) return;

    if (!audioElementRef.current) {
      audioElementRef.current = new Audio(playUrl);
      audioElementRef.current.onended = () => setIsPlayingPreview(false);
    }

    if (isPlayingPreview) {
      audioElementRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      audioElementRef.current.play().catch(e => console.warn("Preview playback notice:", e));
      setIsPlayingPreview(true);
    }
  };

  const sendBlob = (blob: Blob, duration: number, waveform: number[]) => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = () => {
      onSendVoice({
        id: `att_v_${Date.now()}`,
        name: `voice_memo_${Date.now()}.webm`,
        size: blob.size,
        mimeType: 'audio/webm',
        url: reader.result as string,
        type: 'voice',
        duration,
        waveform
      });
    };
  };

  const handleSend = async () => {
    const duration = recordingTime || 1;
    const waveform = waveformDataRef.current.slice(-30);
    if (waveform.length === 0) {
      for (let i = 0; i < 30; i++) waveform.push(Math.floor(Math.random() * 70) + 20);
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        sendBlob(blob, duration, waveform);
      };
      stopRecordingCleanup();
    } else if (audioChunksRef.current.length > 0) {
      const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      sendBlob(blob, duration, waveform);
      stopRecordingCleanup();
    } else {
      stopRecordingCleanup();
      const syntheticUrl = audioUrl || createSyntheticVoiceWavUrl(duration);
      onSendVoice({
        id: `att_v_${Date.now()}`,
        name: `voice_memo_${Date.now()}.wav`,
        size: duration * 8000,
        mimeType: 'audio/wav',
        url: syntheticUrl,
        type: 'voice',
        duration,
        waveform
      });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Voice amplitude reactive transformation for the animated mic
  const micScale = isRecording ? 1 + Math.min(0.5, micVolume * 0.6) : 1;
  const micRotate = isRecording ? Math.sin(Date.now() / 120) * (micVolume * 15) : 0;
  const glowRingScale = isRecording ? 1 + micVolume * 1.2 : 1;
  const glowOpacity = isRecording ? Math.min(0.8, 0.2 + micVolume * 0.9) : 0;

  return (
    <div className="flex items-center gap-2.5 w-full bg-[var(--surface)] border border-[var(--border)] rounded-[28px] p-2 px-3 shadow-md transition-all animate-fadeIn select-none">
      {/* Cancel X Button */}
      <button
        type="button"
        onClick={() => {
          stopRecordingCleanup();
          onCancel();
        }}
        className="p-2 rounded-full text-[var(--text-secondary)] hover:text-red-500 hover:bg-[var(--surface-hover)] transition-colors shrink-0 cursor-pointer"
        title="Отменить запись"
      >
        <X className="w-5 h-5" />
      </button>

      {/* Main Pill Bar */}
      <div className="flex-1 flex items-center justify-between gap-3 px-3 py-2 bg-[#64748b] dark:bg-[#334155] rounded-full text-white shadow-inner min-w-0 relative overflow-hidden">
        
        {/* Dynamic Glowing Aura behind Record Button */}
        {isRecording && (
          <div 
            className="absolute left-3.5 w-7 h-7 rounded-full bg-red-500/40 pointer-events-none transition-transform duration-75 blur-sm"
            style={{
              transform: `scale(${glowRingScale * 1.6})`,
              opacity: glowOpacity
            }}
          />
        )}

        {/* Live Audio Reactive Microphone / Play Button inside Pill */}
        <button
          type="button"
          onClick={isRecording ? handleStopRecording : handleTogglePlayPreview}
          className="relative w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0 shadow-md active:scale-95 transition-all cursor-pointer z-10"
          title={isRecording ? "Остановить запись" : (isPlayingPreview ? "Пауза" : "Прослушать")}
        >
          {isRecording ? (
            <div 
              className="flex items-center justify-center text-red-500 transition-transform duration-75 ease-out"
              style={{
                transform: `scale(${micScale}) rotate(${micRotate}deg)`
              }}
            >
              <Mic className="w-4 h-4 fill-red-500/20 stroke-red-600 stroke-[2.5]" />
            </div>
          ) : isPlayingPreview ? (
            <Pause className="w-3.5 h-3.5 text-slate-700 fill-current" />
          ) : (
            <Play className="w-3.5 h-3.5 text-slate-700 fill-current ml-0.5" />
          )}
        </button>

        {/* Voice-reactive animated Waveform Canvas */}
        <div className="flex-1 flex items-center justify-center overflow-hidden px-1 h-6 min-w-0">
          <canvas ref={canvasRef} width={280} height={20} className="w-full h-5" />
        </div>

        {/* Timer Right inside Pill with speech indicator dot */}
        <div className="flex items-center gap-1.5 shrink-0">
          {isRecording && (
            <div 
              className="w-2 h-2 rounded-full bg-red-400 transition-transform duration-75"
              style={{
                transform: `scale(${1 + micVolume * 0.8})`,
                backgroundColor: micVolume > 0.15 ? '#ef4444' : '#f87171'
              }}
            />
          )}
          <span className="font-mono text-xs font-bold text-white tracking-wider shrink-0 select-none">
            {formatTime(recordingTime)}
          </span>
        </div>
      </div>

      {/* Send Voice Memo Button */}
      <button
        type="button"
        onClick={handleSend}
        className="p-2.5 bg-blue-500 hover:bg-blue-600 active:scale-95 text-white rounded-full transition-transform shadow-md shrink-0 flex items-center justify-center cursor-pointer"
        title="Отправить голосовое сообщение"
      >
        <Send className="w-4 h-4 fill-current ml-0.5" />
      </button>
    </div>
  );
};
