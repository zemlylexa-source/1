import React, { useState } from 'react';
import {
  X,
  User,
  Shield,
  Palette,
  Bell,
  MessageSquare,
  Lock,
  Laptop,
  Check,
  ChevronRight,
  LogOut,
  Camera
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SettingsModalProps {
  onClose: () => void;
  isPhoneFrame?: boolean;
  onTogglePhoneFrame?: (val: boolean) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose, isPhoneFrame, onTogglePhoneFrame }) => {
  const { user, settings, updateSettings, updateProfile, sessions, terminateSession, terminateAllOtherSessions, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'profile' | 'privacy' | 'security' | 'appearance' | 'chat'>('profile');
  const [showMobileMenu, setShowMobileMenu] = useState(true);
  const [nameInput, setNameInput] = useState(user?.name || '');
  const [usernameInput, setUsernameInput] = useState(user?.username || '');
  const [bioInput, setBioInput] = useState(user?.bio || '');
  const [discordInput, setDiscordInput] = useState(user?.discord || '');
  const [telegramInput, setTelegramInput] = useState(user?.telegram || '');
  const [avatarInput, setAvatarInput] = useState(user?.avatar || '');
  const [show2FASecret, setShow2FASecret] = useState(false);
  const [is2FAGenerating, setIs2FAGenerating] = useState(false);

  const handleSaveProfile = () => {
    updateProfile({
      name: nameInput,
      username: usernameInput.toLowerCase().replace(/[^a-z0-9_]/g, ''),
      bio: bioInput,
      discord: discordInput,
      telegram: telegramInput,
      avatar: avatarInput || user?.avatar
    });
  };

  const handleToggle2FA = () => {
    if (user?.is2FAEnabled) {
      updateProfile({ is2FAEnabled: false, twoFASecret: undefined });
      setShow2FASecret(false);
    } else {
      setIs2FAGenerating(true);
      setTimeout(() => {
        updateProfile({ is2FAEnabled: true, twoFASecret: 'JBSWY3DPEHPK3PXP' });
        setIs2FAGenerating(false);
        setShow2FASecret(true);
      }, 800);
    }
  };

  const tabs = [
    { id: 'profile', label: 'Изменить профиль', icon: User, color: 'text-[var(--accent)]', bg: 'bg-[var(--accent)]/10' },
    { id: 'privacy', label: 'Конфиденциальность', icon: Shield, color: 'text-[var(--success)]', bg: 'bg-[var(--success)]/10' },
    { id: 'security', label: 'Безопасность', icon: Lock, color: 'text-[var(--danger)]', bg: 'bg-[var(--danger)]/10' },
    { id: 'appearance', label: 'Оформление', icon: Palette, color: 'text-[var(--accent)]', bg: 'bg-[var(--accent)]/10' },
    { id: 'chat', label: 'Настройки чатов', icon: MessageSquare, color: 'text-[var(--accent)]', bg: 'bg-[var(--accent)]/10' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 bg-[var(--background)]/80 backdrop-blur-xl animate-fadeIn">
      <div className="w-full h-full md:max-w-4xl md:h-[85vh] bg-[var(--surface)] border-0 md:border border-[var(--border)] md:rounded-3xl shadow-2xl flex flex-col md:flex-row overflow-hidden">
        
        {/* Sidebar */}
        <div className={`w-full md:w-1/3 md:min-w-[280px] border-b md:border-r border-[var(--border)] flex flex-col bg-[var(--surface)]/50 ${!showMobileMenu && 'hidden md:flex'}`}>
          <div className="p-6 border-b border-[var(--border)] shrink-0 flex items-center justify-between">
            <div className='flex items-center gap-4'>
                <div className="relative group cursor-pointer">
                <img
                    src={user?.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${user?.username}`}
                    alt={user?.name}
                    className="w-12 h-12 rounded-full object-cover border border-[var(--border)]"
                />
                </div>
                <div>
                <h2 className="text-[var(--text-primary)] font-bold text-lg">{user?.name}</h2>
                <p className="text-[var(--text-secondary)] text-xs font-mono">@{user?.username}</p>
                </div>
            </div>
            <button onClick={onClose} className="md:hidden p-2 hover:bg-[var(--surface-hover)] rounded-full transition-colors">
              <X className="w-5 h-5 text-[var(--text-secondary)]" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-1">
            {tabs.map(t => {
              const Icon = t.icon;
              const isActive = activeTab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => { setActiveTab(t.id as any); setShowMobileMenu(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all ${
                    isActive ? 'bg-[var(--surface-hover)] text-[var(--text-primary)]' : 'text-[var(--text-secondary)] hover:bg-[var(--surface-hover)]/50'
                  }`}
                >
                  <div className={`p-2 rounded-xl ${t.bg}`}>
                    <Icon className={`w-5 h-5 ${t.color}`} />
                  </div>
                  <span className="font-semibold text-sm flex-1 text-left">{t.label}</span>
                  <ChevronRight className={`w-4 h-4 ${isActive ? 'text-[var(--text-primary)]' : 'text-[var(--text-secondary)]/50'}`} />
                </button>
              );
            })}
          </div>
          <div className="p-4 border-t border-[var(--border)]">
            <button
              onClick={() => { logout(); onClose(); }}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-[var(--danger)] hover:bg-[var(--danger)]/10 font-bold transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span>Выйти из аккаунта</span>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className={`flex-1 flex flex-col bg-[var(--background)] relative ${showMobileMenu && 'hidden md:flex'}`}>
          <div className="flex items-center justify-between p-4 md:p-6 border-b border-[var(--border)]/50">
            <button onClick={() => setShowMobileMenu(true)} className="md:hidden p-2 hover:bg-[var(--surface-hover)] rounded-full transition-colors">
              <ChevronRight className="w-6 h-6 text-[var(--text-secondary)] rotate-180" />
            </button>
            <h3 className="text-xl font-bold text-[var(--text-primary)] tracking-tight">
              {tabs.find(t => t.id === activeTab)?.label}
            </h3>
            <button onClick={onClose} className="hidden md:block p-2 hover:bg-[var(--surface-hover)] rounded-full transition-colors">
              <X className="w-5 h-5 text-[var(--text-secondary)]" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 md:p-8">
            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="max-w-xl mx-auto space-y-5 animate-fadeIn">
                <div>
                  <label className="block text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-2 ml-1">Имя</label>
                  <input
                    type="text"
                    value={nameInput}
                    onChange={e => setNameInput(e.target.value)}
                    className="w-full bg-[var(--surface)] border border-[var(--border)] px-4 py-3 rounded-2xl text-[var(--text-primary)] focus:outline-none focus:border-[var(--accent)] transition-colors font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-2 ml-1">Юзернейм (@tag)</label>
                  <input
                    type="text"
                    value={usernameInput}
                    onChange={e => setUsernameInput(e.target.value)}
                    className="w-full bg-[var(--surface)] border border-[var(--border)] px-4 py-3 rounded-2xl text-[var(--text-primary)] font-mono text-sm focus:outline-none focus:border-[var(--accent)] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-2 ml-1">О себе (Био)</label>
                  <textarea
                    value={bioInput}
                    onChange={e => setBioInput(e.target.value)}
                    rows={3}
                    className="w-full bg-[var(--surface)] border border-[var(--border)] px-4 py-3 rounded-2xl text-[var(--text-primary)] focus:outline-none focus:border-[var(--accent)] transition-colors resize-none font-mono text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-1 ml-1">Discord</label>
                    <input
                      type="text"
                      value={discordInput}
                      onChange={e => setDiscordInput(e.target.value)}
                      className="w-full bg-[var(--surface)] border border-[var(--border)] px-3 py-2.5 rounded-xl text-xs font-mono text-[var(--text-primary)]"
                      placeholder="discord.gg/..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-1 ml-1">Telegram</label>
                    <input
                      type="text"
                      value={telegramInput}
                      onChange={e => setTelegramInput(e.target.value)}
                      className="w-full bg-[var(--surface)] border border-[var(--border)] px-3 py-2.5 rounded-xl text-xs font-mono text-[var(--text-primary)]"
                      placeholder="t.me/..."
                    />
                  </div>
                </div>
                <div className="pt-4 border-t border-[var(--border)]">
                  <button
                    onClick={handleSaveProfile}
                    className="w-full md:w-auto px-6 py-3 bg-[var(--accent)] hover:opacity-90 text-[var(--message-sent-text)] font-bold rounded-xl shadow-lg transition-transform active:scale-95"
                  >
                    Сохранить изменения
                  </button>
                </div>
              </div>
            )}


            {/* Privacy Tab */}
            {activeTab === 'privacy' && (
              <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
                <div className="bg-[var(--surface)] border border-[var(--border)] rounded-3xl overflow-hidden divide-y divide-[var(--border)]">
                  <div className="flex items-center justify-between p-5">
                    <div>
                      <h4 className="font-bold text-[var(--text-primary)] mb-0.5">Кто видит мое время захода</h4>
                      <p className="text-xs text-[var(--text-secondary)]">Настройка видимости статуса "Онлайн"</p>
                    </div>
                    <select
                      value={settings.lastSeenPrivacy}
                      onChange={e => updateSettings({ lastSeenPrivacy: e.target.value as any })}
                      className="bg-[var(--surface-hover)] text-[var(--text-primary)] text-sm font-semibold px-4 py-2 rounded-xl border border-[var(--border)] outline-none"
                    >
                      <option value="everyone">Все</option>
                      <option value="contacts">Мои контакты</option>
                      <option value="nobody">Никто</option>
                    </select>
                  </div>
                  <div className="flex items-center justify-between p-5">
                    <div>
                      <h4 className="font-bold text-[var(--text-primary)] mb-0.5">Кто может писать сообщения</h4>
                      <p className="text-xs text-[var(--text-secondary)]">Ограничения входящих чатов</p>
                    </div>
                    <select
                      value={settings.whoCanMessageMe}
                      onChange={e => updateSettings({ whoCanMessageMe: e.target.value as any })}
                      className="bg-[var(--surface-hover)] text-[var(--text-primary)] text-sm font-semibold px-4 py-2 rounded-xl border border-[var(--border)] outline-none"
                    >
                      <option value="everyone">Все</option>
                      <option value="contacts">Контакты</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="max-w-xl mx-auto space-y-8 animate-fadeIn">
                <div className="bg-[var(--surface)] border border-[var(--border)] rounded-3xl p-5 flex items-center justify-between cursor-pointer" onClick={handleToggle2FA}>
                  <div>
                    <h4 className="font-bold text-[var(--text-primary)] mb-0.5">Двухэтапная аутентификация</h4>
                    <p className="text-xs text-[var(--text-secondary)]">Защита с помощью облачного пароля</p>
                  </div>
                  <div className={`w-12 h-6 rounded-full p-1 transition-colors shrink-0 ${user?.is2FAEnabled ? 'bg-[var(--success)]' : 'bg-[var(--surface-hover)]'}`}>
                    <div className={`w-4 h-4 bg-white rounded-full transition-transform ${user?.is2FAEnabled ? 'translate-x-6' : 'translate-x-0'}`} />
                  </div>
                  {show2FASecret && user?.twoFASecret && (
                    <div className="mt-4 p-4 bg-[var(--background)] border border-[var(--accent)]/30 rounded-2xl">
                      <p className="text-xs text-[var(--accent)] font-bold mb-2 uppercase tracking-wider">Ваш секретный ключ TOTP:</p>
                      <code className="text-lg bg-[var(--surface)] px-3 py-1.5 rounded-lg text-[var(--text-primary)] border border-[var(--border)] block text-center font-mono tracking-[0.2em]">{user.twoFASecret}</code>
                    </div>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-4 px-2">
                    <h4 className="font-bold text-[var(--text-primary)] flex items-center gap-2">
                      <Laptop className="w-5 h-5 text-[var(--text-secondary)]" />
                      Активные сеансы
                    </h4>
                    <button
                      onClick={terminateAllOtherSessions}
                      className="text-sm font-bold text-[var(--danger)] hover:opacity-80"
                    >
                      Завершить другие
                    </button>
                  </div>
                  <div className="space-y-3">
                    {sessions.map(sess => (
                      <div key={sess.id} className="bg-[var(--surface)] border border-[var(--border)] rounded-3xl p-5 flex items-center justify-between">
                        <div>
                          <div className="font-bold text-[var(--text-primary)] flex items-center gap-2 mb-1">
                            {sess.device}
                            {sess.isCurrent && (
                              <span className="px-2 py-0.5 rounded-md bg-[var(--success)]/20 text-[var(--success)] font-black text-[10px] tracking-wider uppercase">Текущий</span>
                            )}
                          </div>
                          <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                            {sess.browser} • {sess.os}<br/>
                            {sess.location} • IP: {sess.ip}<br/>
                            <span className="text-[var(--text-secondary)]/60">Активность: {sess.lastActive}</span>
                          </p>
                        </div>
                        {!sess.isCurrent && (
                          <button
                            onClick={() => terminateSession(sess.id)}
                            className="text-[var(--danger)] hover:bg-[var(--danger)]/10 p-2 rounded-xl transition-colors"
                            title="Завершить сеанс"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Appearance Tab */}
            {activeTab === 'appearance' && (
              <div className="max-w-xl mx-auto space-y-8 animate-fadeIn">
                {onTogglePhoneFrame && (
                  <div>
                    <h4 className="font-bold text-[var(--text-primary)] mb-3 ml-1">Режим отображения</h4>
                    <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-2 flex gap-2">
                      <button
                        type="button"
                        onClick={() => onTogglePhoneFrame(false)}
                        className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 font-bold text-xs transition-all ${
                          !isPhoneFrame
                            ? 'bg-[var(--accent)] text-[var(--message-sent-text)] shadow-md'
                            : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-hover)]'
                        }`}
                      >
                        <Laptop className="w-4 h-4" />
                        <span>Десктопный вид</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onTogglePhoneFrame(true)}
                        className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 font-bold text-xs transition-all ${
                          isPhoneFrame
                            ? 'bg-[var(--accent)] text-[var(--message-sent-text)] shadow-md'
                            : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-hover)]'
                        }`}
                      >
                        <Camera className="w-4 h-4" />
                        <span>Экран смартфона</span>
                      </button>
                    </div>
                  </div>
                )}

                <div>
                  <h4 className="font-bold text-[var(--text-primary)] mb-6 ml-1">Цветовая тема</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      {[
                        { id: 'max', label: 'MAX (Telegram+VK)', colors: 'bg-[#090d16]' },
                        { id: 'dark', label: 'Тёмная', colors: 'bg-[#0d1117]' },
                        { id: 'light', label: 'Светлая', colors: 'bg-[#f8fafc]' },
                        { id: 'black', label: 'Чёрная', colors: 'bg-black' },
                        { id: 'cyber', label: 'Кибер', colors: 'bg-[#05010a]' },
                        { id: 'green', label: 'Зелёная', colors: 'bg-[#061006]' },
                        { id: 'purple', label: 'Фиолетовая', colors: 'bg-[#0f071a]' },
                        { id: 'darkblue', label: 'Тёмно-синяя', colors: 'bg-[#0b132b]' }
                      ].map(t => (
                      <button
                        key={t.id}
                        onClick={() => updateSettings({ theme: t.id as any })}
                        className={`aspect-square rounded-3xl border-2 flex flex-col items-center justify-center gap-3 transition-all ${
                          settings.theme === t.id
                            ? 'border-[var(--accent)] bg-[var(--accent)]/10 text-[var(--accent)]'
                            : 'border-[var(--border)] bg-[var(--surface)] text-[var(--text-secondary)] hover:border-[var(--text-secondary)]/50'
                        }`}
                      >
                        <div className={`w-12 h-12 rounded-full border border-[var(--border)] ${t.colors} ${settings.theme === t.id ? 'ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--background)]' : ''}`} />
                        <span className="font-bold text-[13px]">{t.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Chat Tab */}
            {activeTab === 'chat' && (
              <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
                <div className="bg-[var(--surface)] border border-[var(--border)] rounded-3xl p-5 flex items-center justify-between cursor-pointer" onClick={() => updateSettings({ enterToSend: !settings.enterToSend })}>
                  <div>
                    <h4 className="font-bold text-[var(--text-primary)] mb-0.5">Отправка по Enter</h4>
                    <p className="text-xs text-[var(--text-secondary)]">Используйте Shift+Enter для переноса строки</p>
                  </div>
                  <div className={`w-12 h-6 rounded-full p-1 transition-colors ${settings.enterToSend ? 'bg-[var(--success)]' : 'bg-[var(--surface-hover)]'}`}>
                    <div className={`w-4 h-4 bg-white rounded-full transition-transform ${settings.enterToSend ? 'translate-x-6' : 'translate-x-0'}`} />
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};
