import React from 'react';
import { X, ShieldCheck, Zap, Globe, Sparkles } from 'lucide-react';
import { ZentoraLogo } from './ZentoraLogo';

interface AboutModalProps {
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-[var(--background)]/80 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-lg bg-[var(--surface)] border border-[var(--border)] rounded-3xl overflow-hidden shadow-2xl relative flex flex-col">
        
        {/* Background Effects */}
        <div className="absolute top-0 left-0 w-full h-48 bg-gradient-to-b from-[var(--accent)]/10 to-transparent pointer-events-none" />
        <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none mix-blend-overlay" style={{ backgroundImage: 'radial-gradient(circle at center, white 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
        
        <div className="flex items-center justify-between p-4 relative z-10">
          <div className="flex items-center gap-2">
            <div className="px-2.5 py-1 rounded-full bg-[var(--surface-hover)] text-[10px] font-bold text-[var(--text-secondary)] font-mono tracking-wider">
              ZENTORA v1.2.0
            </div>
          </div>
          <button onClick={onClose} className="p-2 bg-[var(--surface-hover)]/50 hover:bg-[var(--surface-hover)] rounded-full transition-colors text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-8 pb-8 pt-4 flex flex-col items-center text-center relative z-10">
          <ZentoraLogo size={80} className="mb-6 drop-shadow-[0_0_20px_rgba(79,70,229,0.5)]" />
          
          <h2 className="text-3xl font-black text-[var(--text-primary)] tracking-tight mb-2">
            Zentora Messenger
          </h2>
          <p className="text-[var(--text-secondary)] text-sm max-w-sm mx-auto mb-8">
            Защищенный мессенджер нового поколения с поддержкой WebRTC, оконечного шифрования и мгновенной доставкой.
          </p>

          <div className="grid grid-cols-2 gap-4 w-full text-left mb-8">
            <div className="bg-[var(--background)]/50 p-4 rounded-2xl border border-[var(--border)]">
              <ShieldCheck className="w-6 h-6 text-[var(--success)] mb-2" />
              <h4 className="text-[var(--text-primary)] font-bold text-sm mb-1">AES-256</h4>
              <p className="text-xs text-[var(--text-secondary)]">Военное шифрование всех ваших данных.</p>
            </div>
            <div className="bg-[var(--background)]/50 p-4 rounded-2xl border border-[var(--border)]">
              <Zap className="w-6 h-6 text-[var(--accent)] mb-2" />
              <h4 className="text-[var(--text-primary)] font-bold text-sm mb-1">WebRTC</h4>
              <p className="text-xs text-[var(--text-secondary)]">Прямые и быстрые аудио и видео звонки.</p>
            </div>
            <div className="bg-[var(--background)]/50 p-4 rounded-2xl border border-[var(--border)]">
              <Sparkles className="w-6 h-6 text-[var(--accent)] mb-2" />
              <h4 className="text-[var(--text-primary)] font-bold text-sm mb-1">Дизайн</h4>
              <p className="text-xs text-[var(--text-secondary)]">Уникальный, красивый и плавный интерфейс.</p>
            </div>
            <div className="bg-[var(--background)]/50 p-4 rounded-2xl border border-[var(--border)]">
              <Globe className="w-6 h-6 text-[var(--accent)] mb-2" />
              <h4 className="text-[var(--text-primary)] font-bold text-sm mb-1">Cloud Run</h4>
              <p className="text-xs text-[var(--text-secondary)]">Быстрые серверы, работающие без задержек.</p>
            </div>
          </div>
          
          <div className="text-[11px] text-[var(--text-secondary)] font-medium">
            Сделано с любовью для общения.<br/>
            © 2026 Zentora Inc. Все права защищены.
          </div>
        </div>
      </div>
    </div>
  );
};
