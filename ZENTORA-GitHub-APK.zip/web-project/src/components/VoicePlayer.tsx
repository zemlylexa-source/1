import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Sparkles, ChevronDown, ChevronUp } from 'lucide-react';

interface VoicePlayerProps {
  url: string;
  duration?: number;
  waveform?: number[];
  isSent?: boolean;
}

const DEFAULT_WAVEFORM = [15, 25, 40, 30, 55, 75, 50, 85, 45, 70, 60, 95, 80, 40, 20, 45, 65, 85, 50, 70, 90, 35, 55, 75, 40, 60, 45, 30, 20, 15];

const SAMPLE_TRANSCRIPTS = [
  "Привет! Давай согласуем проект на завтра в 15:00.",
  "Отличная идея, я уже закончил работу над новым дизайном!",
  "Голосовое сообщение расшифровано через AI Zentora Recognition.",
  "Всё супер, жду ответы от нашей команды!"
];

export const VoicePlayer: React.FC<VoicePlayerProps> = ({
  url,
  duration = 10,
  waveform = DEFAULT_WAVEFORM,
  isSent = false
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [showTranscribe, setShowTranscribe] = useState(false);
  const [transcribedText, setTranscribedText] = useState('');
  const [isTranscribing, setIsTranscribing] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = new Audio(url);
    audioRef.current = audio;

    audio.ontimeupdate = () => {
      setCurrentTime(audio.currentTime);
    };

    audio.onended = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, [url]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(e => {
          setIsPlaying(false);
          console.warn("Audio playback Notice:", e);
        });
    }
  };

  const toggleRate = () => {
    const nextRate = playbackRate === 1 ? 1.5 : playbackRate === 1.5 ? 2 : playbackRate === 2 ? 0.5 : 1;
    setPlaybackRate(nextRate);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextRate;
    }
  };

  const handleTranscribe = () => {
    if (showTranscribe) {
      setShowTranscribe(false);
      return;
    }

    if (transcribedText) {
      setShowTranscribe(true);
      return;
    }

    setIsTranscribing(true);
    setTimeout(() => {
      const randomText = SAMPLE_TRANSCRIPTS[Math.floor(Math.random() * SAMPLE_TRANSCRIPTS.length)];
      setTranscribedText(randomText);
      setIsTranscribing(false);
      setShowTranscribe(true);
    }, 800);
  };

  const handleSeek = (index: number) => {
    if (!audioRef.current) return;
    const progressPct = index / waveform.length;
    const targetTime = progressPct * (duration || 10);
    audioRef.current.currentTime = targetTime;
    setCurrentTime(targetTime);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const progressPct = (currentTime / (duration || 10)) * 100;

  return (
    <div className="flex flex-col w-full my-1">
      <div className={`flex items-center gap-3 p-3 rounded-2xl select-none w-full border transition-all ${
        isSent 
          ? 'bg-[var(--accent)] border-[var(--accent)]/35 text-[var(--message-sent-text)] shadow-sm' 
          : 'bg-[var(--surface-hover)] border-[var(--border)] text-[var(--text-primary)]'
      }`}>
        <button
          onClick={togglePlay}
          className={`w-9 h-9 rounded-full shrink-0 shadow-md flex items-center justify-center transition-all active:scale-90 ${
            isSent 
              ? 'bg-white text-[var(--accent)] hover:bg-white/90' 
              : 'bg-[var(--accent)] text-white hover:opacity-90'
          }`}
        >
          {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
        </button>

        <div className="flex-1 flex flex-col gap-1 min-w-[130px]">
          {/* Waveform Bars */}
          <div className="flex items-end gap-[2px] h-6 cursor-pointer" title="Перемотка">
            {waveform.map((bar, idx) => {
              const barPct = (idx / waveform.length) * 100;
              const isPlayed = barPct <= progressPct;

              return (
                <div
                  key={idx}
                  onClick={() => handleSeek(idx)}
                  className={`flex-1 rounded-full transition-all hover:scale-y-125 ${
                    isPlayed 
                      ? (isSent ? 'bg-white' : 'bg-[var(--accent)]')
                      : (isSent ? 'bg-white/30' : 'bg-[var(--text-secondary)]/30')
                  }`}
                  style={{ height: `${Math.max(25, bar)}%` }}
                />
              );
            })}
          </div>

          <div className="flex items-center justify-between text-[10px] font-mono opacity-85">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Speed button */}
        <button
          onClick={toggleRate}
          className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold font-mono border shrink-0 transition-colors ${
            isSent
              ? 'border-white/30 hover:bg-white/10 text-white'
              : 'border-[var(--border)] hover:bg-[var(--surface)] text-[var(--text-secondary)]'
          }`}
          title="Скорость речи"
        >
          {playbackRate}x
        </button>

        {/* Telegram/VK Speech-to-Text Transcribe button */}
        <button
          onClick={handleTranscribe}
          disabled={isTranscribing}
          className={`p-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 shrink-0 transition-all ${
            isSent
              ? 'border-white/30 bg-white/10 hover:bg-white/20 text-white'
              : 'border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-hover)] text-[var(--accent)]'
          }`}
          title="Расшифровать текст сообщения (VK AI)"
        >
          <Sparkles className={`w-3 h-3 ${isTranscribing ? 'animate-spin text-amber-300' : ''}`} />
          <span className="hidden sm:inline font-mono">АБВ</span>
        </button>
      </div>

      {/* Expanded Transcribed Text */}
      {showTranscribe && transcribedText && (
        <div className={`mt-1 p-2.5 px-3 rounded-xl border text-xs leading-relaxed animate-fadeIn backdrop-blur-sm ${
          isSent
            ? 'bg-black/20 border-white/15 text-white/90'
            : 'bg-[var(--surface)] border-[var(--border)] text-[var(--text-primary)]'
        }`}>
          <div className="flex items-center justify-between text-[9px] font-bold uppercase tracking-wider opacity-60 mb-1">
            <span>Расшифровка аудио</span>
            <span>AI Zentora</span>
          </div>
          <p className="font-serif italic font-medium">"{transcribedText}"</p>
        </div>
      )}
    </div>
  );
};

