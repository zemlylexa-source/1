import React, { useState, useEffect } from 'react';
import { ZentoraLogo } from './ZentoraLogo';
import { AboutModal } from './AboutModal';
import { useAuth } from '../context/AuthContext';
import { useChat, SidebarTab } from '../context/ChatContext';
import { useMusic } from '../context/MusicContext';
import { Search, Plus, Bookmark, MessageSquare, Settings, ShieldAlert, LogOut, Pin, VolumeX, Contact, ShieldCheck, User as UserIcon, FileText, File as FileIcon, Music, CheckCircle2, Phone } from 'lucide-react';
import { UserProfileModal } from './UserProfileModal';
import { ChatContextMenu } from './ChatContextMenu';
import { AdminInfoModal } from './AdminInfoModal';
import { Chat, Message } from '../types';
import { collection, query as firestoreQuery, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { UserAvatar, DELETED_ACCOUNT_NAME } from './UserAvatar';

interface SidebarProps {
  onOpenCreateChat: () => void;
  onOpenSettings: () => void;
  onOpenAdmin: () => void;
  activeSection: 'chats' | 'contacts' | 'calls';
  setActiveSection: (sec: 'chats' | 'contacts' | 'calls') => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  onOpenCreateChat,
  onOpenSettings,
  onOpenAdmin,
  activeSection,
  setActiveSection
}) => {
  const { user, logout, registeredUsers } = useAuth();
  const { setIsFullPlayerOpen } = useMusic();
  const {
    chats,
    activeChatId,
    setActiveChatId,
    activeTab,
    setActiveTab,
    searchQuery,
    setSearchQuery,
    onlineUsers,
    createChat,
    getOrCreateDirectChat,
    getOrCreateSavedMessages,
    togglePinChat,
    toggleMuteChat,
    archiveChat,
    unarchiveChat,
    messagesMap
  } = useChat();

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [chatContextMenu, setChatContextMenu] = useState<{ chat: Chat, x: number, y: number } | null>(null);

  const [debouncedQuery, setDebouncedQuery] = useState(searchQuery);
      
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);

    return () => clearTimeout(handler);
  }, [searchQuery]);


  const query = searchQuery.toLowerCase().trim();
  const qClean = query.replace(/^@+/, '').trim();

  // Filter chats by search query & sidebar tab
  const filteredChats = chats.filter(chat => {
    // Search match
    if (qClean) {
      let chatMatch = false;
      const matchName = chat.name?.toLowerCase().includes(qClean);
      const matchDesc = chat.description?.toLowerCase().includes(qClean);
      const matchChatUser = chat.username?.toLowerCase().includes(qClean);
      chatMatch = !!matchName || !!matchDesc || !!matchChatUser;
      
      if (!chatMatch && chat.type === 'direct') {
        const targetId = chat.members?.find(m => m.userId !== user?.id)?.userId || chat.memberIds?.find(id => id !== user?.id);
        if (targetId) {
          const u = registeredUsers.find(ru => ru.id === targetId);
          if (u) {
            const matchUName = u.name?.toLowerCase().includes(qClean);
            const matchUUser = u.username?.toLowerCase().includes(qClean);
            if (matchUName || matchUUser) chatMatch = true;
          }
        }
      }
      if (!chatMatch) return false;
    }

    // Tab filter (when searching, ignore strict tab filters like 'groups' or 'unread', but respect archive)
    if (activeTab === 'archive') return !!chat.isArchived;
    if (chat.isArchived) return false;

    if (!qClean) {
      if (activeTab === 'unread') return chat.unreadCount > 0;
      if (activeTab === 'personal') return chat.type === 'direct';
      if (activeTab === 'groups') return chat.type === 'group';
      if (activeTab === 'channels') return chat.type === 'channel';
      if (activeTab === 'saved') return chat.type === 'saved';
    }

    return true; // 'all' tab or active search query
  }).sort((a, b) => {
    // Pinned chats first
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    
    // Then by last message timestamp
    const timeA = a.lastMessage?.timestamp || 0;
    const timeB = b.lastMessage?.timestamp || 0;
    return timeB - timeA;
  });

  const globalUserMap = new Map<string, any>();

  if (qClean) {
    registeredUsers.forEach(u => {
      if (u.id !== user?.id) {
        const uName = (u.name || '').toLowerCase();
        const uUsername = (u.username || '').toLowerCase();
        if (uName.includes(qClean) || uUsername.includes(qClean)) {
          globalUserMap.set(u.id, u);
        }
      }
    });
  }

  const globalFoundUsers = Array.from(globalUserMap.values());

  // Search messages & files across all chats
  const searchedMessages: { id: string; text: string; senderName: string; time: string; chatId: string; chatName: string }[] = [];
  const searchedFiles: { id: string; name: string; size: number; url: string; chatId: string; chatName: string }[] = [];

  if (qClean) {
    Object.entries(messagesMap).forEach(([cId, msgs]) => {
      const chat = chats.find(c => c.id === cId);
      const cName = chat?.name || 'Чат';
      (msgs as Message[]).forEach(msg => {
        if (msg.text?.toLowerCase().includes(qClean)) {
          searchedMessages.push({
            id: msg.id,
            text: msg.text,
            senderName: msg.senderName,
            time: msg.time,
            chatId: cId,
            chatName: cName
          });
        }
        msg.attachments?.forEach(att => {
          if (att.name?.toLowerCase().includes(qClean)) {
            searchedFiles.push({
              id: att.id,
              name: att.name,
              size: att.size,
              url: att.url,
              chatId: cId,
              chatName: cName
            });
          }
        });
      });
    });
  }

  const selectedUser = selectedProfileId 
    ? (selectedProfileId === user?.id ? user : (registeredUsers.find(u => u.id === selectedProfileId) )) 
    : null;

  return (
    <div className="w-full h-full bg-[var(--background)] border-r border-[var(--border)] flex flex-col shrink-0 select-none text-[var(--text-primary)]">
      
      {/* Top Header */}
      <div className="p-4 border-b border-[var(--border)] shrink-0 bg-[var(--background)] pt-[calc(env(safe-area-inset-top)+16px)] md:pt-4">
        <div className="flex items-center justify-between mb-5 px-1">
          
          {/* Single Avatar on Left */}
          <div className="relative shrink-0 flex items-center">
            <button
              onClick={() => setShowUserMenu(prev => !prev)}
              className="relative shrink-0 transition-transform active:scale-95"
            >
              <img
                src={user?.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${user?.username}`}
                alt={user?.name}
                className="w-10 h-10 rounded-full object-cover border border-[var(--border)] shadow-md"
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[var(--success)] border-2 border-[var(--background)]" />
            </button>
            {user?.isAdmin && (
              <button
                onClick={(e) => { e.stopPropagation(); setIsAdminModalOpen(true); }}
                className="ml-1 text-blue-400 hover:scale-110 active:scale-95 transition-transform cursor-pointer"
                title="Подтверждённый аккаунт (Администратор)"
              >
                <CheckCircle2 className="w-4 h-4 fill-blue-500 text-white shrink-0" />
              </button>
            )}
            {user?.isModerator && !user?.isAdmin && (
              <div
                className="ml-1 text-emerald-400"
                title="Модератор системы"
              >
                <CheckCircle2 className="w-4 h-4 fill-emerald-500 text-white shrink-0" />
              </div>
            )}
          </div>

          {/* Center Pill Badge Header */}
          <div 
            className="flex flex-col items-center justify-center bg-[var(--surface-hover)]/80 border border-[var(--border)] backdrop-blur-md px-5 py-1.5 rounded-full cursor-pointer hover:bg-[var(--surface-hover)] transition-all shadow-sm"
            onClick={(e) => { e.stopPropagation(); setShowAbout(true); }}
          >
             <h1 className="font-bold text-[13px] text-[var(--text-primary)] tracking-tight leading-tight">Zentora Client</h1>
             <p className="text-[10px] text-[var(--text-secondary)] font-medium leading-none">Мессенджер</p>
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => setIsFullPlayerOpen(true)}
              className="w-10 h-10 bg-[var(--surface)] hover:bg-[var(--surface-hover)] rounded-full text-indigo-400 hover:text-indigo-300 transition-all flex items-center justify-center border border-[var(--border)] shadow-sm active:scale-95 cursor-pointer"
              title="Музыкальный плеер"
            >
              <Music className="w-5 h-5" />
            </button>
            <button
              onClick={onOpenSettings}
              className="w-10 h-10 bg-[var(--surface)] hover:bg-[var(--surface-hover)] rounded-full text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all flex items-center justify-center border border-[var(--border)] shadow-sm active:scale-95 cursor-pointer"
              title="Настройки"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>

          {/* User Menu Dropdown (if active) */}
          {showUserMenu && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setShowUserMenu(false)} />
              <div className="absolute top-16 left-4 z-40 w-56 bg-[var(--surface)] border border-[var(--border)] rounded-2xl shadow-2xl py-2 text-xs text-[var(--text-primary)] animate-fadeIn backdrop-blur-md">
                <button
                  onClick={async () => { if (user) setSelectedProfileId(user.id); setShowUserMenu(false); }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-bold text-[var(--text-primary)] cursor-pointer"
                >
                  <UserIcon className="w-4 h-4 text-[var(--text-primary)]" />
                  <span>Мой профиль</span>
                </button>

                <button
                  onClick={() => { setIsFullPlayerOpen(true); setShowUserMenu(false); }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-semibold text-indigo-400 cursor-pointer"
                >
                  <Music className="w-4 h-4 text-indigo-400" />
                  <span>Музыка</span>
                </button>

                <button
                  onClick={async () => { getOrCreateSavedMessages(); setShowUserMenu(false); }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-bold text-[var(--accent)] cursor-pointer"
                >
                  <Bookmark className="w-4 h-4 text-[var(--accent)]" />
                  <span>Избранное</span>
                </button>

                <button
                  onClick={() => { setActiveSection('calls'); setShowUserMenu(false); }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-semibold text-[var(--text-primary)] cursor-pointer"
                >
                  <Phone className="w-4 h-4 text-purple-400" />
                  <span>Звонки</span>
                </button>

                <button
                  onClick={() => { setActiveSection('contacts'); setShowUserMenu(false); }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-semibold text-[var(--text-primary)] cursor-pointer"
                >
                  <Contact className="w-4 h-4 text-blue-400" />
                  <span>Контакты</span>
                </button>

                <button
                  onClick={async () => { onOpenSettings(); setShowUserMenu(false); }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors cursor-pointer"
                >
                  <Settings className="w-4 h-4 text-[var(--text-secondary)]" />
                  <span>Настройки профиля</span>
                </button>

                {(user?.isAdmin || user?.isModerator) && (
                  <button
                    onClick={async () => { onOpenAdmin(); setShowUserMenu(false); }}
                    className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left text-[var(--danger)] font-semibold transition-colors"
                  >
                    <ShieldAlert className="w-4 h-4 text-[var(--danger)]" />
                    <span>Панель администратора</span>
                  </button>
                )}

                <button
                  onClick={async () => { logout(); setShowUserMenu(false); }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--danger)]/10 text-[var(--danger)] text-left font-semibold border-t border-[var(--border)] mt-1 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Выйти из аккаунта</span>
                </button>
              </div>
            </>
          )}
        </div>

        {/* Global Search */}
        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-4 h-4 text-[var(--text-secondary)]" />
          <input
            type="text"
            placeholder="Поиск пользователей..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 rounded-full bg-[var(--surface)] border border-[var(--border)] focus:border-[var(--accent)]/60 text-sm text-[var(--text-primary)] placeholder-[var(--text-secondary)]/50 focus:outline-none transition-all shadow-inner"
          />
        </div>
      </div>

      {/* Tabs Row */}
      {activeSection === 'chats' && (
        <div className="flex items-center gap-1.5 p-2 overflow-x-auto border-b border-[var(--border)] shrink-0 text-xs font-medium [::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          {[
            { id: 'all', label: 'Все' },
            { id: 'unread', label: 'Непрочитанные' },
            { id: 'personal', label: 'Личные' },
            { id: 'groups', label: 'Группы' },
            { id: 'saved', label: 'Избранное' },
            { id: 'archive', label: 'Архив' }
          ].map(t => {
            const isSel = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id as SidebarTab)}
                className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap transition-all ${
                  isSel
                    ? 'bg-[var(--accent)] text-[var(--message-sent-text)] shadow-sm font-semibold'
                    : 'text-[var(--text-secondary)] hover:bg-[var(--surface-hover)]'
                }`}
              >
                {t.label}
              </button>
            );
          })}
        </div>
      )}

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto p-2 pb-20 md:pb-2 space-y-1">
        {filteredChats.length === 0 && globalFoundUsers.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <MessageSquare className="w-10 h-10 text-[var(--text-secondary)] mx-auto mb-2 opacity-60" />
            <p className="text-sm font-bold text-[var(--text-secondary)]">Ничего не найдено</p>
            <p className="text-xs text-[var(--text-secondary)]/60 mt-1">Попробуйте изменить запрос поиска или создать новый чат.</p>
            <button
              onClick={onOpenCreateChat}
              className="mt-4 px-4 py-2 bg-[var(--accent)] hover:opacity-90 text-[var(--message-sent-text)] text-xs font-bold rounded-xl shadow-lg transition-transform active:scale-95"
            >
              Начать новый чат
            </button>
          </div>
        ) : (
          <>
            {query && (filteredChats.length > 0 || globalFoundUsers.length > 0) && (
              <div className="px-3 py-1.5 text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">
                Чаты и Каналы
              </div>
            )}
            
            {filteredChats.map(chat => {
              const isActive = activeChatId === chat.id;
              const targetUserId = chat.type === 'direct' 
                ? (chat.members?.find(m => m.userId !== user?.id)?.userId || chat.memberIds?.find(id => id !== user?.id) || null)
                : null;
              const targetUserObj = targetUserId ? registeredUsers.find(ru => ru.id === targetUserId) : null;
              const displayUsername = targetUserObj?.username || chat.username;
              const isOnline = targetUserId ? onlineUsers.has(targetUserId) : false;

              return (
                <div
                  key={chat.id}
                  onClick={async () => {
                    setActiveChatId(chat.id);
                    setActiveSection('chats');
                  }}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setChatContextMenu({ chat, x: e.clientX, y: e.clientY });
                  }}
                  className={`relative flex items-center gap-4 p-4 mx-2 mb-2 rounded-[24px] cursor-pointer transition-all ${
                    isActive
                      ? 'bg-[var(--surface-hover)] border border-[var(--accent)]/30 text-[var(--text-primary)] shadow-lg'
                      : chat.isPinned
                        ? 'bg-[var(--accent)]/[0.03] border border-dashed border-[var(--accent)]/20 text-[var(--text-secondary)] hover:bg-[var(--accent)]/[0.07]'
                        : 'bg-[var(--surface)]/50 border border-[var(--border)] hover:bg-[var(--surface-hover)]/50 text-[var(--text-secondary)]'
                  }`}
                >
                  {/* Active Left Vertical Accent Bar */}
                  {isActive && (
                    <div className="absolute left-0 top-4 bottom-4 w-1 bg-[var(--accent)] rounded-r-md" />
                  )}
                  {/* Avatar */}
                  <div 
                    className="relative shrink-0"
                    onClick={(e) => {
                      if (targetUserId) {
                        e.stopPropagation();
                        setSelectedProfileId(targetUserId);
                      }
                    }}
                  >
                    {chat.type === 'saved' ? (
                      <div className={`w-14 h-14 rounded-full flex items-center justify-center ${isActive ? 'bg-[var(--accent)]/20 text-[var(--accent)]' : 'bg-[var(--surface-hover)] text-[var(--text-secondary)]'}`}>
                        <Bookmark className="w-6 h-6 fill-current" />
                      </div>
                    ) : (
                      <img
                        src={chat.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${chat.name}`}
                        alt={chat.name}
                        className={`w-14 h-14 rounded-full object-cover border border-[var(--border)] ${targetUserId ? 'hover:opacity-80' : ''}`}
                      />
                    )}

                    {isOnline && chat.type === 'direct' && (
                      <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-[var(--success)] border-2 border-[var(--background)]" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <h4 className={`font-bold text-[15px] truncate ${isActive ? 'text-[var(--text-primary)]' : 'text-[var(--text-primary)]/90'}`}>
                          {chat.name}
                        </h4>
                        {displayUsername && (
                          <span className="text-[11px] font-mono font-semibold text-[var(--accent)] opacity-80 shrink-0">
                            @{displayUsername}
                          </span>
                        )}
                      </div>
                      <span className={`text-[11px] font-mono shrink-0 ml-1 ${isActive ? 'text-[var(--accent)]' : 'text-[var(--text-secondary)]'}`}>
                        {chat.lastMessage?.time || 'Только что'}
                      </span>
                    </div>

                  <div className="flex items-center justify-between">
                    <p className={`text-sm truncate ${isActive ? 'text-[var(--accent)]/80' : 'text-[var(--text-secondary)]'}`}>
                      {chat.lastMessage?.text || 'Здесь будет последнее сообщение...'}
                    </p>

                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      {chat.isMuted && <VolumeX className={`w-3.5 h-3.5 ${isActive ? 'text-[var(--text-primary)]/70' : 'text-[var(--text-secondary)]'}`} />}
                      {chat.isPinned && <Pin className={`w-3.5 h-3.5 ${isActive ? 'text-[var(--text-primary)]' : 'text-[var(--accent)]'}`} />}
                      {chat.unreadCount > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full bg-[var(--accent)] text-[var(--message-sent-text)] font-bold text-[10px] min-w-[18px] text-center shadow-sm">
                          {chat.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {qClean && globalFoundUsers.length > 0 && (
            <>
              <div className="px-3 py-1.5 mt-3 text-[10px] font-bold text-[var(--accent)] uppercase tracking-wider flex items-center gap-1.5">
                <UserIcon className="w-3.5 h-3.5" />
                <span>Пользователи (@username)</span>
              </div>
              {globalFoundUsers.map(foundU => {
                const isDeleted = foundU.isDeleted || foundU.status === 'deleted';
                return (
                  <div
                    key={foundU.id}
                    onClick={async () => {
                      const chatId = await getOrCreateDirectChat({
                        id: foundU.id,
                        name: isDeleted ? DELETED_ACCOUNT_NAME : foundU.name,
                        avatar: isDeleted ? '' : foundU.avatar,
                        username: foundU.username
                      });
                      setActiveSection('chats');
                      setSearchQuery('');
                    }}
                    className={`flex items-center gap-3 p-3.5 rounded-2xl cursor-pointer transition-all hover:bg-[var(--surface-hover)] text-[var(--text-primary)] border my-1.5 shadow-sm hover:border-[var(--accent)]/40 group ${
                      isDeleted ? 'bg-red-500/5 border-red-500/20' : 'bg-[var(--surface)] border-[var(--border)]'
                    }`}
                  >
                    <div 
                      className="relative shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedProfileId(foundU.id);
                      }}
                    >
                      <UserAvatar
                        user={foundU}
                        isDeleted={isDeleted}
                        size="md"
                      />
                      {!isDeleted && (
                        <span className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[var(--background)] ${
                          onlineUsers.has(foundU.id) ? 'bg-[var(--success)]' : 'bg-gray-400'
                        }`} />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <h4 className={`font-bold text-xs truncate ${isDeleted ? 'text-slate-400' : 'text-[var(--text-primary)]'}`}>
                          {isDeleted ? DELETED_ACCOUNT_NAME : foundU.name}
                        </h4>
                        <span className={`text-[10px] font-bold ${
                          isDeleted 
                            ? 'text-red-400' 
                            : onlineUsers.has(foundU.id) ? 'text-[var(--success)]' : 'text-[var(--text-secondary)]'
                        }`}>
                          {isDeleted ? 'Удалён' : onlineUsers.has(foundU.id) ? '🟢 В сети' : '⚫ Не в сети'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs truncate text-[var(--accent)] font-mono font-semibold">
                          @{foundU.username || 'user'}
                        </p>
                        <button
                          type="button"
                          className="text-[11px] bg-[var(--accent)] text-[var(--message-sent-text)] px-3 py-1 rounded-xl font-bold shadow-sm transition-transform active:scale-95 shrink-0 cursor-pointer"
                        >
                          Написать
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          )}

          {qClean && globalFoundUsers.length === 0 && filteredChats.length === 0 && (
            <div className="p-6 text-center text-[var(--text-secondary)] my-2 bg-[var(--surface)] rounded-2xl border border-[var(--border)]">
              <p className="font-bold text-sm text-[var(--text-primary)] mb-1">Пользователь не найден</p>
              <p className="text-xs">Пользователь с ником @{qClean} не найден.</p>
            </div>
          )}

          {query && searchedMessages.length > 0 && (
            <>
              <div className="px-3 py-1.5 mt-4 text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider flex items-center gap-1.5">
                <MessageSquare className="w-3 h-3 text-[var(--accent)]" />
                <span>Найденные сообщения ({searchedMessages.length})</span>
              </div>
              {searchedMessages.slice(0, 10).map(sm => (
                <div
                  key={sm.id}
                  onClick={async () => {
                    setActiveChatId(sm.chatId);
                    setActiveSection('chats');
                    setSearchQuery('');
                  }}
                  className="p-3 rounded-2xl cursor-pointer transition-all hover:bg-[var(--surface-hover)] text-[var(--text-primary)] border-b border-[var(--border)]/50"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-bold text-[var(--accent)] truncate">{sm.chatName}</span>
                    <span className="text-[10px] text-[var(--text-secondary)] font-mono">{sm.time}</span>
                  </div>
                  <p className="text-xs text-[var(--text-primary)] font-medium line-clamp-2">{sm.text}</p>
                  <p className="text-[10px] text-[var(--text-secondary)] mt-1">От: {sm.senderName}</p>
                </div>
              ))}
            </>
          )}

          {query && searchedFiles.length > 0 && (
            <>
              <div className="px-3 py-1.5 mt-4 text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3 h-3 text-[var(--accent)]" />
                <span>Найденные файлы ({searchedFiles.length})</span>
              </div>
              {searchedFiles.slice(0, 10).map(sf => (
                <div
                  key={sf.id}
                  onClick={async () => {
                    setActiveChatId(sf.chatId);
                    setActiveSection('chats');
                    setSearchQuery('');
                  }}
                  className="flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-all hover:bg-[var(--surface-hover)] text-[var(--text-primary)] border-b border-[var(--border)]/50"
                >
                  <div className="p-2.5 rounded-xl bg-[var(--accent)]/10 text-[var(--accent)] shrink-0">
                    <FileIcon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-xs truncate text-[var(--text-primary)]">{sf.name}</p>
                    <div className="flex items-center gap-2 text-[10px] text-[var(--text-secondary)] mt-0.5">
                      <span>{Math.round(sf.size / 1024)} КБ</span>
                      <span>•</span>
                      <span className="text-[var(--accent)]">{sf.chatName}</span>
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
          </>
        )}
      </div>
      {showAbout && <AboutModal onClose={() => setShowAbout(false)} />}
      
      {selectedProfileId && (
        <UserProfileModal 
          user={selectedUser || null} 
          onClose={() => setSelectedProfileId(null)}
          onMessage={async (u) => {
             const chatId = await getOrCreateDirectChat(u);
             setActiveSection('chats');
             setSelectedProfileId(null);
          }}
        />
      )}

      <AdminInfoModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        adminName={user?.name || 'Администратор'}
      />

      {chatContextMenu && (
        <ChatContextMenu
          chat={chatContextMenu.chat}
          x={chatContextMenu.x}
          y={chatContextMenu.y}
          onClose={() => setChatContextMenu(null)}
          onPin={togglePinChat}
          onMute={toggleMuteChat}
          onArchive={(id) => {
            if (chatContextMenu.chat.isArchived) unarchiveChat(id);
            else archiveChat(id);
          }}
          onDelete={(id) => {
            // Delete logic usually handled by a confirm modal or simple state filter
            // For now just archive it as a soft delete placeholder or we can implement real delete
            archiveChat(id);
          }}
        />
      )}
    </div>
  );
};
