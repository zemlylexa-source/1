import React from 'react';

interface ZentoraLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export const ZentoraLogo: React.FC<ZentoraLogoProps> = ({ className = '', size = 32, showText = true }) => {
  return (
    <div className={`flex items-center gap-2.5 font-bold tracking-tight select-none ${className}`}>
      <div 
        className="relative flex items-center justify-center rounded-xl bg-[var(--accent)] text-[var(--message-sent-text)] shadow-md shadow-[var(--accent)]/20 shrink-0"
        style={{ width: size, height: size }}
      >
        <svg 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2.5" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          className="w-3/5 h-3/5"
        >
          {/* Custom Zentora Signal Z icon */}
          <path d="M4 6h16L7 18h13" />
          <circle cx="12" cy="12" r="1" fill="currentColor" />
        </svg>
      </div>
      {showText && (
        <span className="text-xl font-extrabold tracking-wider text-[var(--text-primary)] uppercase font-mono">
          ZENTORA
        </span>
      )}
    </div>
  );
};
