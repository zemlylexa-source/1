import React, { useState } from 'react';
import { Search, UserPlus, MessageSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import { UserProfileModal } from './UserProfileModal';
import { UserAvatar, DELETED_ACCOUNT_NAME } from './UserAvatar';

interface ContactsViewProps {
  onChatStart?: () => void;
}

export const ContactsView: React.FC<ContactsViewProps> = ({ onChatStart }) => {
  const { user, registeredUsers } = useAuth();
  const { chats, createChat, setActiveChatId, setActiveTab, onlineUsers, getOrCreateDirectChat } = useChat();
  const [search, setSearch] = useState('');
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);

  const query = search.toLowerCase().trim();
  const qClean = query.replace(/^@+/, '').trim();

  const filteredContacts = registeredUsers.filter(u => {
    if (u.id === user?.id) return false;
    if (!qClean) return true;
    return (
      u.name?.toLowerCase().includes(qClean) ||
      u.username?.toLowerCase().includes(qClean)
    );
  });

  const handleMessageUser = async (contact: any) => {
    const chatId = await getOrCreateDirectChat({
      id: contact.id,
      name: contact.isDeleted ? DELETED_ACCOUNT_NAME : contact.name,
      avatar: contact.isDeleted ? '' : contact.avatar,
      username: contact.username
    });
    if (onChatStart) onChatStart();
  };

  const selectedUser = selectedProfileId ? registeredUsers.find(u => u.id === selectedProfileId) : null;

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-[var(--background)] text-[var(--text-primary)] select-none">
      <div className="max-w-2xl mx-auto space-y-6 pt-6 md:pt-4">
        <div className="flex items-center justify-between mb-2 px-1">
          <h2 className="text-xl md:text-2xl font-bold text-[var(--text-primary)] tracking-tight">Контакты</h2>
          <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-[var(--surface)] border border-[var(--border)] text-[var(--text-primary)] font-bold text-[13px] shadow-sm hover:bg-[var(--surface-hover)] transition-all active:scale-95">
            <UserPlus className="w-4 h-4" />
            <span className="hidden sm:inline">Пригласить</span>
          </button>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-4 top-3.5 w-4 h-4 text-[var(--text-secondary)]" />
          <input
            type="text"
            placeholder="Поиск людей по имени или @username..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-11 pr-4 py-3 rounded-full bg-[var(--surface)] border border-[var(--border)] text-sm text-[var(--text-primary)] placeholder-[var(--text-secondary)] focus:outline-none focus:border-[var(--accent)]/60 shadow-inner transition-colors"
          />
        </div>

        <div className="space-y-3">
          {filteredContacts.length === 0 ? (
             <div className="py-10 text-center text-[var(--text-secondary)] text-sm bg-[var(--surface)] rounded-[24px] border border-[var(--border)]">
               Пользователи не найдены.
             </div>
          ) : (
            filteredContacts.map(contact => {
              const isDeleted = contact.isDeleted || contact.status === 'deleted';
              return (
                <div
                  key={contact.id}
                  className={`flex items-center justify-between p-4 px-5 rounded-[24px] border shadow-sm transition-all ${
                    isDeleted 
                      ? 'bg-red-500/5 border-red-500/20' 
                      : 'bg-[var(--surface)] border-[var(--border)] hover:bg-[var(--surface-hover)]'
                  }`}
                >
                  <div 
                    className="flex items-center gap-4 cursor-pointer group flex-1 min-w-0"
                    onClick={() => setSelectedProfileId(contact.id)}
                  >
                    <div className="relative shrink-0">
                      <UserAvatar
                        user={contact}
                        isDeleted={isDeleted}
                        size="md"
                      />
                      {!isDeleted && (
                        <span className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[var(--surface)] ${
                          onlineUsers.has(contact.id) ? 'bg-[var(--success)]' : 'bg-gray-400'
                        }`} />
                      )}
                    </div>
                    <div className="min-w-0 flex-1 pr-2">
                      <div className="flex items-center gap-2">
                        <h4 className={`font-semibold text-[15px] group-hover:underline truncate ${isDeleted ? 'text-slate-400' : 'text-[var(--text-primary)]'}`}>
                          {isDeleted ? DELETED_ACCOUNT_NAME : contact.name}
                        </h4>
                        <span className={`text-[10px] font-bold ${
                          isDeleted 
                            ? 'text-red-400' 
                            : onlineUsers.has(contact.id) ? 'text-[var(--success)]' : 'text-[var(--text-secondary)]'
                        }`}>
                          {isDeleted ? 'Удалён' : onlineUsers.has(contact.id) ? 'Онлайн' : 'Офлайн'}
                        </span>
                      </div>
                      <p className="text-xs font-mono text-[var(--accent)] truncate">@{contact.username}</p>
                      {contact.bio && <p className="text-[11px] text-[var(--text-secondary)] mt-0.5 truncate">{contact.bio}</p>}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleMessageUser(contact)}
                      className="p-3 rounded-full bg-[var(--accent)] text-[var(--message-sent-text)] hover:bg-[var(--accent-hover)] transition-all shadow-md active:scale-95 cursor-pointer"
                      title="Написать сообщение"
                    >
                      <MessageSquare className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {selectedProfileId && (
        <UserProfileModal 
          user={selectedUser || null} 
          onClose={() => setSelectedProfileId(null)}
          onMessage={async (u) => {
             handleMessageUser(u);
             setSelectedProfileId(null);
          }}
        />
      )}
    </div>
  );
};
