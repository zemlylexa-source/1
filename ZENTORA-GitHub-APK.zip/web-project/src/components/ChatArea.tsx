import React, { useState, useRef, useEffect } from 'react';
import {
  Info, Paperclip, Send, Mic, Smile, X, Pin, Check, CheckCheck,
  CornerDownRight, FileText, Forward, Sparkles, Image as ImageIcon, MapPin, Wallet, File as FileIcon, Search, ChevronLeft, ShieldCheck, MoreVertical, Bell, Archive, Trash2, Eraser, CheckCircle2, Phone, Video,
  AlertTriangle, ShieldAlert, Clock, AlertOctagon, Bot
} from 'lucide-react';
import EmojiPicker, { Theme, EmojiClickData } from 'emoji-picker-react';
import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';
import { useCall } from '../context/CallContext';
import { Message, Attachment } from '../types';
import { AdminInfoModal } from './AdminInfoModal';
import { VoicePlayer } from './VoicePlayer';
import { VoiceRecorder } from './VoiceRecorder';
import { MessageContextMenu } from './MessageContextMenu';
import { UserProfileModal } from './UserProfileModal';

interface ChatAreaProps {
  onToggleInfoPanel: () => void;
  onOpenMediaViewer: (att: Attachment) => void;
  onOpenReport: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  onToggleInfoPanel,
  onOpenMediaViewer
}) => {
  const { user, registeredUsers, settings, recordSpamViolation } = useAuth();
  const {
    activeChat,
    messages,
    sendMessage,
    editMessage,
    deleteMessage,
    togglePinMessage,
    addReaction,
    forwardMessage,
    replyingToMessage,
    setReplyingToMessage,
    editingMessage,
    setEditingMessage,
    typingUsers,
    onlineUsers,
    sendTypingSignal,
    getOrCreateDirectChat,
    isSearchOpen,
    setIsSearchOpen,
    setActiveChatId,
    toggleMuteChat,
    togglePinChat,
    archiveChat,
    unarchiveChat,
    clearChatHistory,
    deleteChat
  } = useChat();

  const { startCall } = useCall();

  const [inputText, setInputText] = useState('');
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [showHeaderMenu, setShowHeaderMenu] = useState(false);

  // Anti-Spam state
  const [spamLockoutSeconds, setSpamLockoutSeconds] = useState<number>(0);
  const [spamAlert, setSpamAlert] = useState<{ wordCount: number; duration: number } | null>(null);

  // Spam lockout countdown timer
  useEffect(() => {
    if (spamLockoutSeconds <= 0) return;

    const timer = setInterval(() => {
      setSpamLockoutSeconds(prev => {
        if (prev <= 1) {
          setSpamAlert(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [spamLockoutSeconds]);

  // Search state
  const [chatSearchQuery, setChatSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [currentSearchIndex, setCurrentSearchIndex] = useState(-1);

  // Context menu state
  const [contextMenu, setContextMenu] = useState<{
    message: Message;
    x: number;
    y: number;
  } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const docInputRef = useRef<HTMLInputElement | null>(null);

  // Auto scroll on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  // Sync editing text
  useEffect(() => {
    if (editingMessage) {
      setInputText(editingMessage.text);
    }
  }, [editingMessage]);

  // Handle search logic
  useEffect(() => {
    if (!chatSearchQuery.trim()) {
      setSearchResults([]);
      setCurrentSearchIndex(-1);
      return;
    }
    
    const query = chatSearchQuery.toLowerCase();
    const results = messages.filter(m => m.text?.toLowerCase().includes(query)).map(m => m.id);
    
    setSearchResults(results);
    if (results.length > 0) {
      setCurrentSearchIndex(results.length - 1); // Start from most recent (bottom)
      const msgId = results[results.length - 1];
      setTimeout(() => {
        const el = document.getElementById(`msg-${msgId}`);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 50);
    } else {
      setCurrentSearchIndex(-1);
    }
  }, [chatSearchQuery, messages]);

  const navigateSearch = (direction: -1 | 1) => {
    if (searchResults.length === 0) return;
    let nextIndex = currentSearchIndex + direction;
    if (nextIndex < 0) nextIndex = searchResults.length - 1;
    if (nextIndex >= searchResults.length) nextIndex = 0;
    setCurrentSearchIndex(nextIndex);
    
    // Scroll to message
    const msgId = searchResults[nextIndex];
    const el = document.getElementById(`msg-${msgId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const renderHighlightedText = (text: string, query: string) => {
    if (!query.trim() || !isSearchOpen) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return (
      <>
        {parts.map((part, i) => 
          part.toLowerCase() === query.toLowerCase() ? (
            <span key={i} className="bg-[var(--accent)]/40 text-[var(--message-sent-text)] rounded px-0.5">{part}</span>
          ) : (
            <span key={i}>{part}</span>
          )
        )}
      </>
    );
  };

  if (!activeChat) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[var(--background)] p-6 text-center text-[var(--text-secondary)]">
        <div className="p-4 rounded-3xl bg-[var(--accent-light)] border border-[var(--accent)]/20 mb-3">
          <Sparkles className="w-10 h-10 text-[var(--accent)]" />
        </div>
        <p className="text-base font-bold text-[var(--text-primary)]">Выберите диалог для общения</p>
        <p className="text-xs text-[var(--text-secondary)] mt-1 max-w-xs">Выберите чат из списка слева или создайте новое личное сообщение.</p>
      </div>
    );
  }

  const activeTyping = typingUsers[activeChat.id] || [];
  const isTargetOnline = onlineUsers.has(activeChat.members?.[1]?.userId || '');

  const pinnedMessage = messages.find(m => m.isPinned);

  const handleSend = async () => {
    if (editingMessage) {
      editMessage(editingMessage.id, inputText);
      setInputText('');
      setEditingMessage(null);
      return;
    }

    if (!inputText.trim()) return;

    // Check if user is currently locked out by SpamBot
    if (spamLockoutSeconds > 0) {
      return;
    }

    // SPAM PROTECTION: If user writes more than 5 words
    const words = inputText.trim().split(/\s+/).filter(w => w.length > 0);
    if (words.length > 5) {
      // Pick random lockout time 5 to 10 seconds
      const lockoutDuration = Math.floor(Math.random() * 6) + 5; // 5 to 10 seconds
      setSpamLockoutSeconds(lockoutDuration);
      setSpamAlert({
        wordCount: words.length,
        duration: lockoutDuration
      });

      if (user) {
        const res = await recordSpamViolation(user.id);
        if (res.isBanned) {
          // If banned (3rd violation), AuthContext automatically force kicks the user
          return;
        }
      }
      return; // Stop message from sending
    }

    sendMessage(inputText);
    setInputText('');
    sendTypingSignal(false);
    setShowEmojiPicker(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setShowAttachmentMenu(false);
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = async () => {
        const dataUrl = reader.result as string;

        try {
          const res = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name: file.name,
              mimeType: file.type || 'application/octet-stream',
              dataUrl
            })
          });
          const data = await res.json();
          if (res.ok && data.attachment) {
            sendMessage('', [data.attachment]);
          }
        } catch (err) {
          const fallbackAtt: Attachment = {
            id: `att_${Date.now()}`,
            name: file.name,
            size: file.size,
            mimeType: file.type,
            url: dataUrl,
            type: file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'document'
          };
          sendMessage('', [fallbackAtt]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const onEmojiClick = (emojiData: EmojiClickData, event: MouseEvent) => {
    setInputText(prev => prev + emojiData.emoji);
  };

  const handleCopyMessageText = async (text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
    } catch (err) {
      console.warn("Clipboard copy notice:", err);
    }
  };

  const selectedUser = selectedProfileId ? registeredUsers.find(u => u.id === selectedProfileId) : null;

  return (
    <div
      className="flex-1 flex flex-col h-full bg-[var(--background)] relative overflow-hidden select-none text-[var(--text-primary)]"
      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragOver(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          if (fileInputRef.current) {
            fileInputRef.current.files = e.dataTransfer.files;
            handleFileUpload({ target: fileInputRef.current } as unknown as React.ChangeEvent<HTMLInputElement>);
          }
        }
      }}
    >
      {/* Background */}
      
      {/* Pattern Background matching Telegram */}
      <div 
        className="absolute inset-0 bg-[var(--background)] pointer-events-none" 
        style={{
          backgroundImage: 'url("https://www.transparenttextures.com/patterns/cubes.png")',
          opacity: 0.25,
          backgroundSize: '200px'
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[var(--background)]/80 to-[var(--background)]/30 pointer-events-none" />


      {/* Drag & Drop Overlay */}
      {dragOver && (
        <div className="absolute inset-0 z-30 bg-[var(--accent)]/90 backdrop-blur-md text-[var(--message-sent-text)] flex flex-col items-center justify-center p-6 border-4 border-dashed border-white/60 animate-fadeIn">
          <Paperclip className="w-16 h-16 mb-2 animate-bounce" />
          <h3 className="text-xl font-bold">Перетащите файлы сюда для отправки</h3>
          <p className="text-xs opacity-80 mt-1">Поддерживаются фото, видео, документы и голосовые заметки</p>
        </div>
      )}

      {/* Top Header Bar matching Screenshot 1 */}
      <div className="py-2.5 px-3 md:px-4 bg-[var(--background)]/90 border-b border-[var(--border)] flex items-center justify-between shrink-0 z-10 shadow-sm backdrop-blur-xl">
        {/* Back Button on Left */}
        <button
          onClick={() => setActiveChatId(null)}
          className="w-10 h-10 rounded-full bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--text-primary)] transition-all flex items-center justify-center shadow-sm shrink-0"
          title="Назад к чатам"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        {/* Center Floating Pill Badge */}
        <div 
          onClick={async () => {
            if (activeChat.type === 'direct') {
              const targetId = activeChat.members?.find(m => m.userId !== user?.id)?.userId;
              if (targetId) setSelectedProfileId(targetId);
            } else {
              onToggleInfoPanel();
            }
          }}
          className="flex items-center gap-2.5 bg-[var(--surface-hover)]/90 border border-[var(--border)] backdrop-blur-md px-4 py-1.5 rounded-full shadow-sm cursor-pointer hover:bg-[var(--surface-hover)] transition-all max-w-[65%] min-w-0"
        >
          <img
            src={activeChat.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${activeChat.name}`}
            alt={activeChat.name}
            className="w-7 h-7 rounded-full object-cover border border-[var(--border)] shrink-0"
          />
          <div className="flex flex-col min-w-0">
            <h3 className="font-bold text-[13px] text-[var(--text-primary)] truncate leading-tight flex items-center gap-1">
              <span>{activeChat.name}</span>
              {(selectedUser?.isAdmin || (activeChat.type === 'direct' && activeChat.username?.toLowerCase() === 'den')) && (
                <CheckCircle2 className="w-3.5 h-3.5 fill-blue-500 text-white shrink-0" title="Подтверждённый аккаунт (Администратор)" />
              )}
              {selectedUser?.isModerator && !selectedUser?.isAdmin && (
                <CheckCircle2 className="w-3.5 h-3.5 fill-emerald-500 text-white shrink-0" title="Модератор системы" />
              )}
            </h3>
            <span className="text-[10px] text-[var(--text-secondary)] font-medium leading-none truncate">
              {activeTyping.length > 0 ? (
                <span className="text-[var(--accent)] animate-pulse">печатает...</span>
              ) : isTargetOnline ? (
                <span className="text-[var(--success)] font-semibold">В сети</span>
              ) : (
                <span className="opacity-80">Не в сети</span>
              )}
            </span>
          </div>
        </div>

        {/* Action Buttons on Right */}
        <div className="flex items-center gap-1.5 shrink-0 relative">
          {activeChat.type === 'direct' && (
            <>
              <button
                onClick={() => {
                  const otherMember = activeChat.members?.find(m => m.userId !== user?.id);
                  const targetId = otherMember?.userId || activeChat.memberIds?.find(id => id !== user?.id);
                  if (!targetId) {
                    alert('Нельзя позвонить самому себе (в Избранном) или в пустом чате.');
                    return;
                  }
                  if (targetId) {
                    startCall(
                      activeChat.id,
                      {
                        id: targetId,
                        name: activeChat.name || 'Собеседник',
                        avatar: activeChat.avatar || ''
                      },
                      'audio'
                    );
                  }
                }}
                className="w-10 h-10 rounded-full bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--accent)] transition-all flex items-center justify-center shadow-sm active:scale-95"
                title="Аудиозвонок"
              >
                <Phone className="w-5 h-5" />
              </button>
              <button
                onClick={() => {
                  const otherMember = activeChat.members?.find(m => m.userId !== user?.id);
                  const targetId = otherMember?.userId || activeChat.memberIds?.find(id => id !== user?.id);
                  if (!targetId) {
                    alert('Нельзя позвонить самому себе (в Избранном) или в пустом чате.');
                    return;
                  }
                  if (targetId) {
                    startCall(
                      activeChat.id,
                      {
                        id: targetId,
                        name: activeChat.name || 'Собеседник',
                        avatar: activeChat.avatar || ''
                      },
                      'video'
                    );
                  }
                }}
                className="w-10 h-10 rounded-full bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--accent)] transition-all flex items-center justify-center shadow-sm active:scale-95"
                title="Видеозвонок"
              >
                <Video className="w-5 h-5" />
              </button>
            </>
          )}

          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className={`w-10 h-10 rounded-full bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] transition-all flex items-center justify-center shadow-sm ${
              isSearchOpen ? 'text-[var(--accent)] bg-[var(--surface-hover)] border-[var(--accent)]/40' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
            title="Поиск"
          >
            <Search className="w-5 h-5" />
          </button>

          <button
            onClick={onToggleInfoPanel}
            className="w-10 h-10 rounded-full bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all flex items-center justify-center shadow-sm"
            title="Информация о чате"
          >
            <Info className="w-5 h-5" />
          </button>

          <button
            onClick={() => setShowHeaderMenu(prev => !prev)}
            className="w-10 h-10 rounded-full bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all flex items-center justify-center shadow-sm"
            title="Ещё настройки"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {/* Header More Options Menu */}
          {showHeaderMenu && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setShowHeaderMenu(false)} />
              <div className="absolute top-12 right-0 z-40 w-56 bg-[var(--surface)] border border-[var(--border)] rounded-2xl shadow-2xl py-2 text-xs text-[var(--text-primary)] animate-fadeIn backdrop-blur-md">
                <button
                  onClick={async () => {
                    setIsSearchOpen(true);
                    setShowHeaderMenu(false);
                  }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-medium"
                >
                  <Search className="w-4 h-4 text-[var(--text-secondary)]" />
                  <span>Поиск в чате</span>
                </button>

                <button
                  onClick={async () => {
                    toggleMuteChat(activeChat.id);
                    setShowHeaderMenu(false);
                  }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-medium"
                >
                  <Bell className="w-4 h-4 text-[var(--text-secondary)]" />
                  <span>{activeChat.isMuted ? 'Включить уведомления' : 'Отключить уведомления'}</span>
                </button>

                <button
                  onClick={async () => {
                    togglePinChat(activeChat.id);
                    setShowHeaderMenu(false);
                  }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-medium"
                >
                  <Pin className="w-4 h-4 text-[var(--text-secondary)]" />
                  <span>{activeChat.isPinned ? 'Открепить чат' : 'Закрепить чат'}</span>
                </button>

                <button
                  onClick={async () => {
                    if (activeChat.isArchived) unarchiveChat(activeChat.id);
                    else archiveChat(activeChat.id);
                    setShowHeaderMenu(false);
                  }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-medium"
                >
                  <Archive className="w-4 h-4 text-[var(--text-secondary)]" />
                  <span>{activeChat.isArchived ? 'Разархивировать' : 'Архивировать'}</span>
                </button>

                <button
                  onClick={async () => {
                    clearChatHistory(activeChat.id);
                    setShowHeaderMenu(false);
                  }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors font-medium text-amber-500"
                >
                  <Eraser className="w-4 h-4 text-amber-500" />
                  <span>Очистить историю</span>
                </button>

                <button
                  onClick={async () => {
                    deleteChat(activeChat.id);
                    setShowHeaderMenu(false);
                  }}
                  className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--danger)]/10 text-[var(--danger)] text-left font-semibold border-t border-[var(--border)] mt-1 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Удалить чат</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* In-Chat Search Bar */}
      {isSearchOpen && (
        <div className="p-2 md:p-3 bg-[var(--surface)] border-b border-[var(--border)] flex items-center justify-between gap-3 shrink-0 z-10 shadow-md">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-[var(--text-secondary)] absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Поиск по сообщениям..." 
              value={chatSearchQuery}
              onChange={(e) => setChatSearchQuery(e.target.value)}
              className="w-full bg-[var(--background)]/50 border border-[var(--border)] rounded-xl py-2 pl-9 pr-4 text-sm text-[var(--text-primary)] focus:outline-none focus:border-[var(--accent)] transition-colors"
              autoFocus
            />
          </div>
          <div className="flex items-center gap-1.5 text-xs font-mono text-[var(--text-secondary)] shrink-0">
            {chatSearchQuery.trim() && (
              <span className="mr-2 hidden sm:inline-block text-[10px] uppercase tracking-wider">
                {searchResults.length > 0 ? `${currentSearchIndex + 1} из ${searchResults.length}` : '0 из 0'}
              </span>
            )}
            <button 
              onClick={() => navigateSearch(-1)}
              disabled={searchResults.length === 0}
              className="p-1.5 hover:bg-[var(--surface-hover)] rounded-lg disabled:opacity-30 text-[var(--text-secondary)]"
            >
              ▲
            </button>
            <button 
              onClick={() => navigateSearch(1)}
              disabled={searchResults.length === 0}
              className="p-1.5 hover:bg-[var(--surface-hover)] rounded-lg disabled:opacity-30 text-[var(--text-secondary)]"
            >
              ▼
            </button>
            <div className="w-px h-4 bg-[var(--border)] mx-1"></div>
            <button 
              onClick={async () => {
                setIsSearchOpen(false);
                setChatSearchQuery('');
              }}
              className="p-1.5 hover:bg-[var(--surface-hover)] rounded-lg text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Pinned Message Banner */}
      {pinnedMessage && (
        <div className="p-2.5 bg-[var(--accent)]/10 border-b border-[var(--accent)]/20 flex items-center justify-between px-4 text-xs shrink-0 z-10 backdrop-blur-sm">
          <div className="flex items-center gap-2.5 min-w-0">
            <Pin className="w-4 h-4 text-[var(--accent)] shrink-0" />
            <div className="min-w-0">
              <span className="font-bold text-[var(--accent)] block text-[10px] uppercase tracking-wider">Закрепленное сообщение</span>
              <p className="text-[var(--text-primary)]/80 truncate">{pinnedMessage.text}</p>
            </div>
          </div>
          <button onClick={() => togglePinMessage(pinnedMessage.id)} className="p-1 text-[var(--text-secondary)] hover:text-[var(--accent)]">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Messages List Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 relative z-0">
          {/* Floating Central Date Badge matching Screenshot 1 */}
          <div className="flex justify-center my-3 select-none">
            <span className="bg-slate-200/80 dark:bg-slate-800/80 border border-black/5 dark:border-white/10 text-slate-700 dark:text-slate-200 backdrop-blur-md px-4 py-1 rounded-full text-xs font-semibold shadow-sm">
              Сегодня
            </span>
          </div>

          {messages.length === 0 ? (
            <div className="py-20 text-center text-[var(--text-secondary)] text-xs">
              <p className="font-bold text-[var(--text-primary)] mb-1">Сообщений пока нет</p>
              <p>Напишите сообщение или отправьте голосовую заметку.</p>
            </div>
          ) : (
            messages.map(msg => {
              const isMine = msg.senderId === user?.id;

              return (
                <div
                  key={msg.id}
                  id={`msg-${msg.id}`}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setContextMenu({ message: msg, x: e.clientX, y: e.clientY });
                  }}
                  className={`flex flex-col ${isMine ? 'items-end' : 'items-start'} group animate-fadeIn`}
                >
                  {/* Sender Name for Groups */}
                  {!isMine && activeChat.type === 'group' && (
                    <span 
                      onClick={() => setSelectedProfileId(msg.senderId)}
                      className="text-[10px] font-bold text-[var(--accent)] ml-3 mb-1 cursor-pointer hover:underline"
                    >
                      {msg.senderName}
                    </span>
                  )}

                  {/* Bubble & Hover Actions Row */}
                  <div className={`relative flex items-center gap-2 group/bubble max-w-[85%] md:max-w-[70%] ${isMine ? 'flex-row-reverse' : 'flex-row'}`}>
                    {/* The Message Bubble */}
                    <div
                      className={`relative min-w-[100px] md:min-w-[120px] px-4 py-2.5 shadow-sm transition-all ${
                        isSearchOpen && searchResults[currentSearchIndex] === msg.id
                          ? 'ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--background)]' 
                          : ''
                      } ${
                        isMine
                          ? 'bg-[var(--message-sent)] text-[var(--message-sent-text)] rounded-[18px] rounded-br-[4px]'
                          : 'bg-[var(--message-received)] border border-[var(--border)] text-[var(--message-received-text)] rounded-[18px] rounded-bl-[4px]'
                      }`}
                    >
                      {/* Reply Banner inside bubble */}
                      {msg.replyToMessage && (
                        <div className={`p-2 rounded-xl mb-2 text-xs border-l-2 ${
                          isMine
                            ? 'bg-white/10 border-white/80 text-white/90'
                            : 'bg-[var(--surface-hover)] border-[var(--accent)] text-[var(--text-secondary)]'
                        }`}>
                          <span className="font-bold block text-[10px]">{msg.replyToMessage.senderName}</span>
                          <p className="truncate">{renderHighlightedText(msg.replyToMessage.text, chatSearchQuery)}</p>
                        </div>
                      )}

                      {/* Forwarded Tag */}
                      {msg.forwardedFrom && (
                        <div className="flex items-center gap-1 text-[10px] italic opacity-80 mb-1 text-[var(--accent)]/80">
                          <Forward className="w-3 h-3" />
                          <span>Переслано от {msg.forwardedFrom}</span>
                        </div>
                      )}

                      {/* Text or Large Sticker Content */}
                      {msg.text && (
                        (() => {
                          const cleanText = msg.text.trim();
                          const isSticker = cleanText.startsWith('🏷️') || cleanText.startsWith('[Sticker]');
                          const emojiRegex = /^(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff]){1,4}$/u;
                          const isEmojiOnly = emojiRegex.test(cleanText);

                          if (isSticker || isEmojiOnly) {
                            const displayEmoji = cleanText.replace('🏷️', '').replace('[Sticker]', '');
                            return (
                              <div className="py-2 px-2 text-7xl md:text-8xl select-none leading-none transform hover:scale-110 transition-all cursor-pointer animate-fadeIn my-1 flex items-center justify-center">
                                <span className="filter drop-shadow-md">{displayEmoji}</span>
                              </div>
                            );
                          }

                          return (
                            <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap break-words">
                              {renderHighlightedText(msg.text, chatSearchQuery)}
                            </p>
                          );
                        })()
                      )}

                      {/* Attachments */}
                      {msg.attachments && msg.attachments.map(att => {
                        if (att.type === 'image') {
                          return (
                            <div
                              key={att.id}
                              onClick={() => onOpenMediaViewer(att)}
                              className="mt-2 rounded-xl overflow-hidden cursor-pointer hover:opacity-90 transition-opacity border border-white/10"
                            >
                              <img src={att.url} alt={att.name} className="max-h-64 w-full object-cover rounded-xl" />
                            </div>
                          );
                        }
                        if (att.type === 'voice' || att.type === 'audio') {
                          return (
                            <VoicePlayer
                              key={att.id}
                              url={att.url}
                              duration={att.duration}
                              waveform={att.waveform}
                              isSent={isMine}
                            />
                          );
                        }
                        return (
                          <a
                            key={att.id}
                            href={att.url}
                            download={att.name}
                            className={`mt-2 flex items-center gap-3 p-2.5 rounded-xl border text-xs ${
                              isMine
                                ? 'bg-white/10 border-white/30 text-white'
                                : 'bg-[var(--surface-hover)] border-[var(--border)] text-[var(--text-primary)]'
                            }`}
                          >
                            <FileText className="w-5 h-5 shrink-0 text-[var(--accent)]" />
                            <div className="flex-1 min-w-0">
                              <p className="font-bold truncate">{att.name}</p>
                              <p className="text-[10px] opacity-70">{Math.round(att.size / 1024)} КБ</p>
                            </div>
                          </a>
                        );
                      })}

                      {/* Emoji Reactions */}
                      {msg.reactions && msg.reactions.length > 0 && (
                        <div className="flex items-center flex-wrap gap-1 mt-2 pt-1.5 border-t border-white/10">
                          {msg.reactions.map(r => (
                            <button
                              key={r.emoji}
                              onClick={() => addReaction(msg.id, r.emoji)}
                              className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border transition-transform active:scale-95 ${
                                isMine
                                  ? 'bg-white/10 border-white/30 text-white'
                                  : 'bg-[var(--surface-hover)] border-[var(--border)] text-[var(--text-primary)]'
                              }`}
                            >
                              <span>{r.emoji}</span>
                              <span>{r.count}</span>
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Message Footer */}
                      <div className={`flex items-center justify-end gap-1 mt-1 text-[10px] font-mono ${
                        isMine ? 'text-[var(--message-sent-text)]/80' : 'text-[var(--text-secondary)]'
                      }`}>
                        {msg.isEdited && <span className="italic mr-1">изм.</span>}
                        <span>{msg.time}</span>
                        {isMine && (
                          <span className="ml-0.5">
                            {msg.status === 'read' ? <CheckCheck className="w-3.5 h-3.5 text-indigo-300 font-bold drop-shadow-sm" /> : <Check className="w-3.5 h-3.5 opacity-80" />}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Small Hover Quick Menu */}
                    <div className="opacity-0 group-hover/bubble:opacity-100 transition-all flex items-center bg-[var(--surface)] border border-[var(--border)] rounded-xl p-0.5 shadow-xl shrink-0 z-10 translate-y-0.5 sm:translate-y-0">
                      <button
                        onClick={() => setReplyingToMessage(msg)}
                        className="p-1 hover:bg-[var(--surface-hover)] rounded-lg text-[var(--text-secondary)] hover:text-[var(--accent)] transition-colors"
                        title="Ответить"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                        </svg>
                      </button>
                      <button
                        onClick={() => forwardMessage(msg)}
                        className="p-1 hover:bg-[var(--surface-hover)] rounded-lg text-[var(--text-secondary)] hover:text-[var(--accent)] transition-colors"
                        title="Переслать"
                      >
                        <Forward className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleCopyMessageText(msg.text || '')}
                        className="p-1 hover:bg-[var(--surface-hover)] rounded-lg text-[var(--text-secondary)] hover:text-[var(--accent)] transition-colors"
                        title="Копировать"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3" />
                        </svg>
                      </button>
                      {isMine && (
                        <button
                          onClick={() => deleteMessage(msg.id)}
                          className="p-1 hover:bg-red-500/10 rounded-lg text-[var(--text-secondary)] hover:text-red-400 transition-colors"
                          title="Удалить"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        <div ref={messagesEndRef} />
      </div>

      {/* Reply Banner */}
      {replyingToMessage && (
        <div className="p-2.5 bg-[var(--accent)]/10 border-t border-[var(--accent)]/20 flex items-center justify-between px-4 text-xs shrink-0 z-10 animate-fadeIn backdrop-blur-sm">
          <div className="flex items-center gap-2 min-w-0">
            <CornerDownRight className="w-4 h-4 text-[var(--accent)] shrink-0" />
            <div className="min-w-0">
              <span className="font-bold text-[var(--accent)] block text-[10px]">
                Ответ для {replyingToMessage.senderName}
              </span>
              <p className="text-[var(--text-primary)]/80 truncate">{replyingToMessage.text}</p>
            </div>
          </div>
          <button onClick={() => setReplyingToMessage(null)} className="p-1 hover:text-[var(--accent)]">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Edit Banner */}
      {editingMessage && (
        <div className="p-2.5 bg-[var(--accent)]/10 border-t border-[var(--accent)]/20 flex items-center justify-between px-4 text-xs shrink-0 z-10 animate-fadeIn backdrop-blur-sm">
          <div className="flex items-center gap-2 min-w-0">
            <span className="font-bold text-[var(--accent)] text-[10px] uppercase">Редактирование сообщения</span>
          </div>
          <button onClick={async () => { setEditingMessage(null); setInputText(''); }} className="p-1 hover:text-[var(--accent)]">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Message Input Container */}
      <div className="p-2 md:p-3 pb-[calc(env(safe-area-inset-bottom)+8px)] md:pb-3 bg-[var(--surface)]/95 border-t border-[var(--border)] shrink-0 z-10 backdrop-blur-xl relative w-full">
        
        {/* Zentora SpamBot Telegram-style Warning Banner */}
        {spamLockoutSeconds > 0 && (
          <div className="mb-2 p-3 rounded-2xl bg-gradient-to-r from-red-950/80 via-amber-950/70 to-red-950/80 border border-red-500/40 text-[var(--text-primary)] shadow-xl flex items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-5 h-5 text-red-400 animate-pulse" />
              </div>
              <div className="text-xs min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-red-300">Zentora SpamBot</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-red-500/30 text-red-200 border border-red-500/40 font-mono">
                    Антиспам
                  </span>
                </div>
                <p className="text-[var(--text-primary)] text-[11px] font-medium mt-0.5 leading-tight">
                  Вы были обнаружены как спамер (сообщение больше 5 слов: {spamAlert?.wordCount || 6} сл.). Чат временно заблокирован на {spamAlert?.duration || 10} сек.
                </p>
              </div>
            </div>
            <div className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-500/25 border border-red-500/40 text-amber-300 font-mono font-bold text-xs shadow-inner">
              <Clock className="w-3.5 h-3.5 animate-spin" />
              <span>{spamLockoutSeconds}с</span>
            </div>
          </div>
        )}

        {isRecordingVoice ? (
          <VoiceRecorder
            onSendVoice={(attachment) => {
              sendMessage('', [attachment]);
              setIsRecordingVoice(false);
            }}
            onCancel={() => setIsRecordingVoice(false)}
          />
        ) : (
          <div className="relative flex items-center gap-2 px-1 w-full">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              multiple
              accept="image/*,video/*"
            />
            
            <input
              type="file"
              ref={docInputRef}
              onChange={handleFileUpload}
              className="hidden"
              multiple
            />

            {/* Combined Long Horizontal Pill Container */}
            <div className={`flex-1 w-full min-w-0 flex items-center bg-[var(--input)] border ${
              spamLockoutSeconds > 0 ? 'border-red-500/40 ring-1 ring-red-500/20' : 'border-[var(--border)]'
            } rounded-full shadow-sm relative min-h-[48px] md:min-h-[52px] px-2.5 transition-all`}>
              
              {/* Attachment Button */}
              <div className="relative shrink-0">
                <button
                  onClick={() => setShowAttachmentMenu(prev => !prev)}
                  disabled={spamLockoutSeconds > 0}
                  className={`p-2 md:p-2.5 transition-colors rounded-full ${
                    spamLockoutSeconds > 0 ? 'opacity-40 cursor-not-allowed' :
                    showAttachmentMenu ? 'text-[var(--accent)]' : 'text-[var(--text-secondary)] hover:text-[var(--accent)]'
                  }`}
                  title="Прикрепить файл"
                >
                  <Paperclip className="w-5 h-5" />
                </button>

                {/* Attachment Popover Menu */}
                {showAttachmentMenu && (
                  <>
                    <div className="fixed inset-0 z-20" onClick={() => setShowAttachmentMenu(false)} />
                    <div className="absolute bottom-14 left-0 z-30 w-56 bg-[var(--surface)] border border-[var(--border)] rounded-[24px] shadow-2xl py-2 animate-slideUp">
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-[var(--text-primary)] hover:bg-[var(--surface-hover)] transition-colors"
                      >
                        <ImageIcon className="w-5 h-5 text-[var(--accent)]" />
                        Фото или видео
                      </button>
                      <button 
                        onClick={() => docInputRef.current?.click()}
                        className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-[var(--text-primary)] hover:bg-[var(--surface-hover)] transition-colors"
                      >
                        <FileIcon className="w-5 h-5 text-[var(--accent)]" />
                        Документ
                      </button>
                    </div>
                  </>
                )}
              </div>

              {/* Text Input - Long & Horizontal */}
              <textarea
                rows={1}
                placeholder={spamLockoutSeconds > 0 ? `Отправка заблокирована SpamBot (${spamLockoutSeconds}с)...` : "Сообщение..."}
                value={inputText}
                disabled={spamLockoutSeconds > 0}
                onChange={e => {
                  setInputText(e.target.value);
                  sendTypingSignal(true);
                }}
                onKeyDown={handleKeyDown}
                className={`w-full flex-1 min-w-0 py-2.5 px-3 bg-transparent text-sm md:text-base text-[var(--text-primary)] placeholder-[var(--text-secondary)]/60 focus:outline-none transition-all resize-none max-h-32 self-center font-normal leading-normal ${
                  spamLockoutSeconds > 0 ? 'opacity-50 cursor-not-allowed placeholder-red-400/70' : ''
                }`}
              />

              {/* Emoji Button */}
              <div className="relative shrink-0">
                <button
                  onClick={() => setShowEmojiPicker(prev => !prev)}
                  disabled={spamLockoutSeconds > 0}
                  className={`p-2 md:p-2.5 transition-colors rounded-full ${
                    spamLockoutSeconds > 0 ? 'opacity-40 cursor-not-allowed' :
                    showEmojiPicker ? 'text-[var(--accent)]' : 'text-[var(--text-secondary)] hover:text-[var(--accent)]'
                  }`}
                  title="Вставить эмодзи и стикеры"
                >
                  <Smile className="w-5 h-5" />
                </button>
                
                {/* Emoji Picker Component with Sticker Bar */}
                {showEmojiPicker && (
                  <>
                    <div className="fixed inset-0 z-20" onClick={() => setShowEmojiPicker(false)} />
                    <div className="absolute bottom-14 right-0 z-30 shadow-2xl animate-slideUp overflow-hidden rounded-[28px] border border-[var(--border)] bg-[var(--surface)]" style={{ width: '320px' }}>
                      
                      {/* Sticker Bar Header */}
                      <div className="p-2.5 bg-[var(--surface-hover)] border-b border-[var(--border)] flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                        <span className="text-[10px] font-bold text-[var(--accent)] uppercase tracking-wider px-1 shrink-0">Стикеры:</span>
                        {['🔥', '❤️', '🥳', '😎', '🐻', '🦊', '🚀', '👑', '💎', '🐱', '⭐', '👍', '🎉', '💩', '👻'].map(st => (
                          <button
                            key={st}
                            onClick={async () => {
                              sendMessage(`🏷️${st}`);
                              setShowEmojiPicker(false);
                            }}
                            className="text-2xl hover:scale-130 transition-transform p-1 rounded-xl hover:bg-[var(--surface)] shrink-0 active:scale-90"
                            title={`Отправить стикер ${st}`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>

                      <EmojiPicker
                        onEmojiClick={(emojiData, e) => onEmojiClick(emojiData, e)}
                        theme={settings.theme === 'light' ? Theme.LIGHT : Theme.DARK}
                        lazyLoadEmojis
                        searchPlaceHolder="Поиск эмодзи..."
                        width="100%"
                        height="340px"
                      />
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Send/Mic Button */}
            <div className="shrink-0">
              {inputText.trim() ? (
                <button
                  onClick={handleSend}
                  disabled={spamLockoutSeconds > 0}
                  className={`w-11 h-11 md:w-12 md:h-12 rounded-full shadow-md transition-all flex items-center justify-center ${
                    spamLockoutSeconds > 0 
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30 cursor-not-allowed' 
                      : 'bg-[var(--message-sent)] hover:bg-[var(--accent-hover)] text-[var(--message-sent-text)] hover:scale-105 active:scale-95 cursor-pointer'
                  }`}
                  title={spamLockoutSeconds > 0 ? `Блокировка SpamBot (${spamLockoutSeconds}с)` : "Отправить сообщение"}
                >
                  {spamLockoutSeconds > 0 ? (
                    <Clock className="w-5 h-5 animate-spin" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </button>
              ) : (
                <button
                  onClick={() => setIsRecordingVoice(true)}
                  disabled={spamLockoutSeconds > 0}
                  className={`w-11 h-11 md:w-12 md:h-12 bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full shadow-md transition-all hover:scale-105 active:scale-95 flex items-center justify-center ${
                    spamLockoutSeconds > 0 ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'
                  }`}
                  title="Записать голосовое сообщение"
                >
                  <Mic className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Context Menu Popup */}
      {contextMenu && (
        <MessageContextMenu
          message={contextMenu.message}
          x={contextMenu.x}
          y={contextMenu.y}
          onClose={() => setContextMenu(null)}
          onReply={(msg) => setReplyingToMessage(msg)}
          onCopy={(msg) => handleCopyMessageText(msg.text)}
          onForward={(msg) => {
            forwardMessage('chat_saved', msg);
          }}
          onEdit={(msg) => setEditingMessage(msg)}
          onPin={(msg) => togglePinMessage(msg.id)}
          onDelete={(msg) => deleteMessage(msg.id)}
          onReact={(msg, emoji) => addReaction(msg.id, emoji)}
        />
      )}

      {selectedProfileId && (
        <UserProfileModal 
          user={selectedUser || null} 
          onClose={() => setSelectedProfileId(null)}
          onMessage={async (contact) => {
              await getOrCreateDirectChat(contact);
              setSelectedProfileId(null);
          }}
        />
      )}

      <AdminInfoModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        adminName={activeChat.name}
      />
    </div>
  );
};

