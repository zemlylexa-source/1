import React, { useState, useEffect } from 'react';
import { ShieldAlert, AlertTriangle, Clock, RefreshCw, LogOut, CheckCircle2, UserX, MessageSquareWarning, Sparkles } from 'lucide-react';
import { User } from '../types';
import { ZentoraLogo } from './ZentoraLogo';

interface BannedAccountModalProps {
  bannedUser: User;
  onClose: () => void;
  onUnbanned?: (user: User) => void;
}

export const BannedAccountModal: React.FC<BannedAccountModalProps> = ({
  bannedUser,
  onClose,
  onUnbanned
}) => {
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [isExpired, setIsExpired] = useState<boolean>(false);
  const [isRestoring, setIsRestoring] = useState<boolean>(false);

  const banExpiresAt = bannedUser.banExpiresAt;
  const isPermanent = !banExpiresAt || banExpiresAt === 'permanent';

  useEffect(() => {
    if (isPermanent) return;

    const calculateTimeLeft = () => {
      const now = Date.now();
      const expireTime = new Date(banExpiresAt).getTime();
      const diff = Math.max(0, Math.floor((expireTime - now) / 1000));
      setTimeLeft(diff);

      if (diff <= 0) {
        setIsExpired(true);
      }
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(interval);
  }, [banExpiresAt, isPermanent]);

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    if (hours > 0) {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleRestoreAccount = async () => {
    setIsRestoring(true);
    try {
      if (onUnbanned) {
        onUnbanned(bannedUser);
      }
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fadeIn select-none overflow-y-auto">
      <div className="relative w-full max-w-lg bg-[var(--surface)] border border-red-500/30 rounded-[36px] shadow-2xl overflow-hidden p-6 sm:p-8 flex flex-col items-center text-center animate-scaleUp">
        
        {/* Ambient Top Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Warning Icon Badge */}
        <div className="relative w-20 h-20 rounded-3xl bg-red-500/10 border-2 border-red-500/30 flex items-center justify-center mb-5 shadow-lg shadow-red-500/20">
          <ShieldAlert className="w-10 h-10 text-red-500 animate-pulse" />
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500"></span>
          </span>
        </div>

        {/* Title */}
        <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-[var(--text-primary)]">
          {isExpired ? 'Срок блокировки истёк' : 'Аккаунт заблокирован'}
        </h2>
        
        <div className="mt-1 flex items-center gap-1.5 text-xs font-mono text-red-400">
          <span>@{bannedUser.username}</span>
          <span>•</span>
          <span>Zentora Security</span>
        </div>

        {/* Warning / Reason Box */}
        <div className="w-full mt-6 p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-left">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-bold text-red-300">Причина ограничения:</p>
              <p className="text-[var(--text-primary)] font-medium leading-relaxed">
                {bannedUser.banReason || bannedUser.deleteReason || 'Нарушение правил сообщества Zentora (Обнаружен спам сообщений)'}
              </p>
            </div>
          </div>
        </div>

        {/* Timer / Expiry Info Box */}
        <div className="w-full mt-4 p-4 rounded-2xl bg-[var(--surface-hover)] border border-[var(--border)]">
          {isPermanent ? (
            <div className="flex items-center justify-center gap-2 text-red-400 text-xs font-bold">
              <UserX className="w-4 h-4" />
              <span>Блокировка аккаунта: Навсегда</span>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-[var(--text-secondary)]">
                <span className="flex items-center gap-1.5 font-semibold">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Тип: Временная заморозка</span>
                </span>
                <span className="font-mono text-amber-400 font-bold">
                  {isExpired ? '00:00 (Завершено)' : 'Таймер активен'}
                </span>
              </div>

              {!isExpired && timeLeft !== null ? (
                <div className="bg-black/30 p-3 rounded-xl border border-white/5 flex flex-col items-center justify-center">
                  <span className="text-2xl sm:text-3xl font-mono font-black text-amber-400 tracking-wider">
                    {formatTime(timeLeft)}
                  </span>
                  <span className="text-[10px] text-[var(--text-secondary)] uppercase tracking-wider mt-0.5">
                    До автоматической разблокировки
                  </span>
                </div>
              ) : (
                <div className="bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20 flex items-center justify-center gap-2 text-emerald-400 text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Блокировка снята! Вы можете восстановить доступ</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Telegram-style explanation notice */}
        <p className="text-xs text-[var(--text-secondary)] mt-4 leading-relaxed max-w-sm">
          {isPermanent 
            ? 'Ваш профиль скрыт и помечен как удалённый аккаунт. Доступ к чатам и звонкам закрыт.'
            : isExpired
            ? 'Срок действия ограничения завершён. Нажмите кнопку ниже для возврата в аккаунт со всеми чатами.'
            : 'В период блокировки с аккаунта выполнен выход. После завершения таймера аккаунт будет полностью восстановлен.'}
        </p>

        {/* Action Buttons */}
        <div className="w-full mt-6 flex flex-col sm:flex-row gap-3">
          {isExpired ? (
            <button
              onClick={handleRestoreAccount}
              disabled={isRestoring}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer active:scale-95 animate-pulse"
            >
              <RefreshCw className={`w-4 h-4 ${isRestoring ? 'animate-spin' : ''}`} />
              <span>Войти в разблокированный аккаунт</span>
            </button>
          ) : (
            <button
              onClick={onClose}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--message-sent-text)] font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer active:scale-95"
            >
              <LogOut className="w-4 h-4" />
              <span>Вернуться к форме входа</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
