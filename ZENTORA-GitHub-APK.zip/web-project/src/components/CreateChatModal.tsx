import React, { useState } from 'react';
import { X, MessageSquare, Users, Radio, Check, Search } from 'lucide-react';
import { ChatType } from '../types';

import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';

interface CreateChatModalProps {
  onClose: () => void;
}

export const CreateChatModal: React.FC<CreateChatModalProps> = ({ onClose }) => {
  const { createChat } = useChat();
  const { user, registeredUsers } = useAuth();

  const [chatType, setChatType] = useState<ChatType>('direct');
  const [nameInput, setNameInput] = useState('');
  const [descInput, setDescInput] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);

  const searchClean = userSearch.toLowerCase().trim().replace(/^@/, '');

  const availableUsers = registeredUsers
    .filter(u => u.id !== user?.id)
    .filter(u => {
      if (!searchClean) return true;
      return (
        u.name?.toLowerCase().includes(searchClean) ||
        u.username?.toLowerCase().includes(searchClean)
      );
    });

  const toggleUserSelection = (userId: string) => {
    setSelectedUserIds(prev =>
      prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (chatType === 'direct' && selectedUserIds.length === 0) return;
    if ((chatType === 'group' || chatType === 'channel') && !nameInput.trim()) return;

    let finalName = nameInput;
    let finalAvatar = undefined;
    if (chatType === 'direct') {
       const target = registeredUsers.find(u => u.id === selectedUserIds[0]);
       if (target) {
         finalName = target.name;
         finalAvatar = target.avatar;
       }
    }
    createChat(chatType, finalName, selectedUserIds, descInput, finalAvatar);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--background)]/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-[var(--surface)] border border-[var(--border)] rounded-3xl shadow-2xl p-6 text-[var(--text-primary)]">
        
        <div className="flex items-center justify-between pb-4 border-b border-[var(--border)]">
          <h3 className="text-lg font-bold text-[var(--text-primary)] font-mono">Создать диалог</h3>
          <button onClick={onClose} className="p-1 hover:bg-[var(--surface-hover)] rounded-lg">
            <X className="w-5 h-5 text-[var(--text-secondary)]" />
          </button>
        </div>

        {/* Type Selector */}
        <div className="grid grid-cols-3 gap-2 my-4">
          {[
            { id: 'direct', label: 'Личное', icon: MessageSquare },
            { id: 'group', label: 'Группа', icon: Users },
            { id: 'channel', label: 'Канал', icon: Radio }
          ].map(t => {
            const Icon = t.icon;
            const isSel = chatType === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setChatType(t.id as ChatType)}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl border text-xs font-bold transition-all ${
                  isSel
                    ? 'border-[var(--accent)] bg-[var(--accent-light)] text-[var(--accent)] shadow-sm'
                    : 'border-[var(--border)] bg-[var(--background)] text-[var(--text-secondary)]'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          {chatType !== 'direct' && (
            <>
              <div>
                <label className="block text-xs font-semibold uppercase text-[var(--text-secondary)] mb-1">
                  {chatType === 'group' ? 'Название группы' : 'Название канала'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={chatType === 'group' ? 'Например: Архитектура проекта' : 'Например: Новости Zentora'}
                  value={nameInput}
                  onChange={e => setNameInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent)] text-[var(--text-primary)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-[var(--text-secondary)] mb-1">Описание (необязательно)</label>
                <input
                  type="text"
                  placeholder="О чем этот чат..."
                  value={descInput}
                  onChange={e => setDescInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--background)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent)] text-[var(--text-primary)]"
                />
              </div>
            </>
          )}

          {/* Members Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-semibold uppercase text-[var(--text-secondary)]">
                {chatType === 'direct' ? 'Выберите собеседника' : 'Выберите участников'}
              </label>
            </div>

            {/* Search user by @username */}
            <div className="relative mb-3">
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-[var(--text-secondary)]" />
              <input
                type="text"
                placeholder="Поиск по имени или @username..."
                value={userSearch}
                onChange={e => setUserSearch(e.target.value)}
                className="w-full pl-10 pr-3 py-2 rounded-xl border border-[var(--border)] bg-[var(--background)] text-xs focus:outline-none focus:ring-2 focus:ring-[var(--accent)] text-[var(--text-primary)]"
              />
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {availableUsers.map(u => {
                const isSelected = selectedUserIds.includes(u.id);
                return (
                  <div
                    key={u.id}
                    onClick={() => {
                      if (chatType === 'direct') {
                        setSelectedUserIds([u.id]);
                      } else {
                        toggleUserSelection(u.id);
                      }
                    }}
                    className={`flex items-center justify-between p-2.5 rounded-2xl border cursor-pointer transition-colors ${
                      isSelected
                        ? 'border-[var(--accent)] bg-[var(--accent-light)]'
                        : 'border-[var(--border)] hover:bg-[var(--surface-hover)]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={u.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${u.username}`}
                        alt={u.name}
                        className="w-8 h-8 rounded-full object-cover border border-[var(--border)]"
                      />
                      <div>
                        <p className="text-xs font-bold text-[var(--text-primary)]">{u.name}</p>
                        <p className="text-[10px] text-[var(--accent)] font-mono">@{u.username}</p>
                      </div>
                    </div>

                    {isSelected && (
                      <div className="p-1 rounded-full bg-[var(--accent)] text-[var(--message-sent-text)]">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--message-sent-text)] font-bold text-xs shadow-md transition-transform active:scale-95"
          >
            Создать чат
          </button>
        </form>

      </div>
    </div>
  );
};
