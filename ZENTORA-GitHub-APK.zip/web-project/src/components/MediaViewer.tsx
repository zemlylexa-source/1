import React, { useState } from 'react';
import { X, Download, ZoomIn, ZoomOut, ChevronLeft, ChevronRight } from 'lucide-react';
import { Attachment } from '../types';

interface MediaViewerProps {
  attachment: Attachment | null;
  allAttachments?: Attachment[];
  onClose: () => void;
}

export const MediaViewer: React.FC<MediaViewerProps> = ({ attachment, allAttachments = [], onClose }) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [currentIndex, setCurrentIndex] = useState(() => {
    if (!attachment) return 0;
    const idx = allAttachments.findIndex(a => a.id === attachment.id);
    return idx >= 0 ? idx : 0;
  });

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!attachment) return null;

  const currentMedia = allAttachments.length > 0 ? allAttachments[currentIndex] : attachment;

  const handleNext = () => {
    if (currentIndex < allAttachments.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setZoomLevel(1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setZoomLevel(1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--background)]/95 backdrop-blur-md animate-fadeIn text-[var(--text-primary)] p-4">
      {/* Top Action Bar */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-3">
        {currentMedia.type === 'image' && (
          <>
            <button
              onClick={() => setZoomLevel(prev => Math.min(prev + 0.25, 3))}
              className="p-2.5 rounded-full bg-[var(--surface-hover)]/80 hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-5 h-5" />
            </button>
            <button
              onClick={() => setZoomLevel(prev => Math.max(prev - 0.25, 0.5))}
              className="p-2.5 rounded-full bg-[var(--surface-hover)]/80 hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-5 h-5" />
            </button>
          </>
        )}

        <a
          href={currentMedia.url}
          download={currentMedia.name}
          className="p-2.5 rounded-full bg-[var(--surface-hover)]/80 hover:bg-[var(--surface-hover)] text-[var(--text-secondary)] transition-colors"
          title="Download File"
        >
          <Download className="w-5 h-5" />
        </a>

        <button
          onClick={onClose}
          className="p-2.5 rounded-full bg-[var(--surface-hover)]/80 hover:bg-[var(--danger)] text-white transition-colors"
          title="Close Viewer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Navigation arrows */}
      {allAttachments.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="absolute left-4 z-20 p-3 rounded-full bg-[var(--surface-hover)]/80 hover:bg-[var(--surface-hover)] disabled:opacity-30 disabled:pointer-events-none text-[var(--text-primary)] transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={handleNext}
            disabled={currentIndex === allAttachments.length - 1}
            className="absolute right-4 z-20 p-3 rounded-full bg-[var(--surface-hover)]/80 hover:bg-[var(--surface-hover)] disabled:opacity-30 disabled:pointer-events-none text-[var(--text-primary)] transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </>
      )}

      {/* Media Display */}
      <div className="relative max-w-5xl max-h-[85vh] flex items-center justify-center overflow-hidden">
        {currentMedia.type === 'image' && (
          <img
            src={currentMedia.url}
            alt={currentMedia.name}
            className="max-w-full max-h-[85vh] object-contain rounded-xl transition-transform duration-200"
            style={{ transform: `scale(${zoomLevel})` }}
          />
        )}

        {currentMedia.type === 'video' && (
          <video
            src={currentMedia.url}
            controls
            autoPlay
            className="max-w-full max-h-[85vh] rounded-xl shadow-2xl"
          />
        )}
      </div>
    </div>
  );
};
