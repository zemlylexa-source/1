import React from 'react';
import { Pin, VolumeX, Trash2, Archive, Volume2 } from 'lucide-react';
import { Chat } from '../types';

interface ChatContextMenuProps {
  chat: Chat;
  x: number;
  y: number;
  onClose: () => void;
  onPin: (chatId: string) => void;
  onMute: (chatId: string) => void;
  onArchive: (chatId: string) => void;
  onDelete: (chatId: string) => void;
}

export const ChatContextMenu: React.FC<ChatContextMenuProps> = ({
  chat,
  x,
  y,
  onClose,
  onPin,
  onMute,
  onArchive,
  onDelete
}) => {
  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      
      <div
        className="fixed z-50 w-56 rounded-2xl bg-[var(--surface)] border border-[var(--border)] shadow-2xl py-2 text-xs text-[var(--text-primary)] animate-fadeIn backdrop-blur-md"
        style={{
          top: Math.max(12, Math.min(y, window.innerHeight - 200)),
          left: Math.max(12, Math.min(x, window.innerWidth - 224))
        }}
      >
        <button
          onClick={() => { onPin(chat.id); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
        >
          <Pin className={`w-4 h-4 ${chat.isPinned ? 'text-[var(--accent)]' : 'text-[var(--text-secondary)]'}`} />
          <span>{chat.isPinned ? 'Открепить' : 'Закрепить'}</span>
        </button>

        <button
          onClick={() => { onMute(chat.id); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
        >
          {chat.isMuted ? (
            <Volume2 className="w-4 h-4 text-[var(--success)]" />
          ) : (
            <Volume2 className="w-4 h-4 text-[var(--text-secondary)]" />
          )}
          <span>{chat.isMuted ? 'Включить звук' : 'Без звука'}</span>
        </button>

        <button
          onClick={() => { onArchive(chat.id); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--surface-hover)] text-left transition-colors"
        >
          <Archive className="w-4 h-4 text-[var(--accent)]" />
          <span>{chat.isArchived ? 'Вернуть из архива' : 'В архив'}</span>
        </button>

        <button
          onClick={() => { onDelete(chat.id); onClose(); }}
          className="w-full px-4 py-2.5 flex items-center gap-2.5 hover:bg-[var(--danger)]/10 text-[var(--danger)] text-left font-semibold border-t border-[var(--border)] mt-1 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          <span>Удалить чат</span>
        </button>
      </div>
    </>
  );
};
