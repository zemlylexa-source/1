import React, { useState } from 'react';
import { 
  Phone, 
  PhoneIncoming, 
  PhoneOutgoing, 
  PhoneMissed, 
  Video, 
  Trash2, 
  Clock, 
  Search, 
  PhoneCall 
} from 'lucide-react';
import { useCall } from '../context/CallContext';
import { useAuth } from '../context/AuthContext';
import { CallLog } from '../types';

export const CallsView: React.FC = () => {
  const { user } = useAuth();
  const { callLogs, redialCall, clearCallHistory } = useCall();
  const [filter, setFilter] = useState<'all' | 'missed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const formatDuration = (seconds: number) => {
    if (!seconds || seconds <= 0) return '0 сек';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins > 0) {
      return `${mins} мин ${secs > 0 ? `${secs} сек` : ''}`;
    }
    return `${secs} сек`;
  };

  const filteredLogs = callLogs.filter(log => {
    if (filter === 'missed' && log.status !== 'missed' && log.direction !== 'missed') {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const otherName = (log.callerId === user?.id ? log.recipientName : log.callerName).toLowerCase();
      return otherName.includes(q);
    }
    return true;
  });

  return (
    <div className="w-full h-full flex flex-col bg-[var(--background)] text-[var(--text-primary)] select-none">
      {/* Header */}
      <div className="p-4 border-b border-[var(--border)] shrink-0 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">История звонков</h2>
          <p className="text-xs text-[var(--text-secondary)]">Голосовые и видеозвонки</p>
        </div>

        {callLogs.length > 0 && (
          <button
            onClick={clearCallHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-red-400 hover:bg-red-500/10 transition-colors border border-red-500/20"
            title="Очистить историю"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Очистить</span>
          </button>
        )}
      </div>

      {/* Filter Tabs & Search */}
      <div className="p-3 border-b border-[var(--border)] flex items-center gap-2">
        <div className="flex bg-[var(--surface)] p-1 rounded-xl border border-[var(--border)] shrink-0">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 text-xs rounded-lg font-semibold transition-all ${
              filter === 'all'
                ? 'bg-[var(--accent)] text-[var(--message-sent-text)] shadow-sm'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            Все
          </button>
          <button
            onClick={() => setFilter('missed')}
            className={`px-3 py-1 text-xs rounded-lg font-semibold transition-all ${
              filter === 'missed'
                ? 'bg-red-500 text-white shadow-sm'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            Пропущенные
          </button>
        </div>

        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-[var(--text-secondary)] absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Поиск по имени..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-[var(--surface)] border border-[var(--border)] text-xs text-[var(--text-primary)] placeholder-[var(--text-secondary)]/50 focus:outline-none"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center text-[var(--text-secondary)]">
            <PhoneCall className="w-12 h-12 mb-3 opacity-40 text-purple-400" />
            <p className="font-bold text-sm text-[var(--text-primary)]">История звонков пуста</p>
            <p className="text-xs text-[var(--text-secondary)] mt-1 max-w-xs">
              {filter === 'missed' 
                ? 'У вас нет пропущенных звонков.' 
                : 'Совершайте голосовые и видеозвонки собеседникам прямо из чата или профиля.'}
            </p>
          </div>
        ) : (
          filteredLogs.map(log => {
            const isOutgoing = log.callerId === user?.id;
            const targetName = isOutgoing ? log.recipientName : log.callerName;
            const targetAvatar = (isOutgoing ? log.recipientAvatar : log.callerAvatar) || 
              `https://api.dicebear.com/7.x/identicon/svg?seed=${targetName}`;
            const isMissed = log.status === 'missed' || log.direction === 'missed';

            return (
              <div
                key={log.id}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-[var(--surface)] hover:bg-[var(--surface-hover)] border border-[var(--border)] transition-all group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={targetAvatar}
                    alt={targetName}
                    className="w-12 h-12 rounded-full object-cover border border-[var(--border)] shrink-0"
                  />

                  <div className="min-w-0">
                    <h4 className={`font-bold text-sm truncate ${isMissed ? 'text-red-400' : 'text-[var(--text-primary)]'}`}>
                      {targetName}
                    </h4>

                    <div className="flex items-center gap-1.5 text-xs text-[var(--text-secondary)] mt-0.5">
                      {isMissed ? (
                        <PhoneMissed className="w-3.5 h-3.5 text-red-500 shrink-0" />
                      ) : isOutgoing ? (
                        <PhoneOutgoing className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      ) : (
                        <PhoneIncoming className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      )}

                      <span>
                        {isMissed 
                          ? 'Пропущенный' 
                          : isOutgoing 
                            ? `Исходящий (${formatDuration(log.duration)})` 
                            : `Входящий (${formatDuration(log.duration)})`}
                      </span>
                      <span>•</span>
                      <span>{log.time}</span>
                    </div>
                  </div>
                </div>

                {/* Redial Action Buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => redialCall({ ...log, type: 'audio' })}
                    className="w-9 h-9 rounded-full bg-purple-500/10 hover:bg-purple-500/25 text-purple-400 flex items-center justify-center transition-transform active:scale-95 border border-purple-500/20"
                    title="Позвонить"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => redialCall({ ...log, type: 'video' })}
                    className="w-9 h-9 rounded-full bg-indigo-500/10 hover:bg-indigo-500/25 text-indigo-400 flex items-center justify-center transition-transform active:scale-95 border border-indigo-500/20"
                    title="Видеозвонок"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
