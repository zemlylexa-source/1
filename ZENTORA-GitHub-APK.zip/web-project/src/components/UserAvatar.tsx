import React from 'react';
import { UserX } from 'lucide-react';
import { User } from '../types';

export const DELETED_ACCOUNT_NAME = 'Удалённый аккаунт';
export const DELETED_ACCOUNT_BIO = 'Данный аккаунт был удален за иную причину администрацией Zentora.';

export interface UserAvatarProps {
  user?: Partial<User> | null;
  name?: string;
  avatar?: string;
  isDeleted?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  showOnlineStatus?: boolean;
  isOnline?: boolean;
  onClick?: (e: React.MouseEvent) => void;
}

const sizeClasses = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-12 h-12 text-base',
  xl: 'w-14 h-14 text-lg',
  '2xl': 'w-28 h-28 md:w-32 md:h-32 text-2xl',
};

const iconSizes = {
  xs: 'w-3 h-3',
  sm: 'w-4 h-4',
  md: 'w-5 h-5',
  lg: 'w-6 h-6',
  xl: 'w-7 h-7',
  '2xl': 'w-14 h-14',
};

export const UserAvatar: React.FC<UserAvatarProps> = ({
  user,
  name,
  avatar,
  isDeleted,
  size = 'md',
  className = '',
  showOnlineStatus = false,
  isOnline = false,
  onClick,
}) => {
  const deleted = isDeleted || user?.isDeleted || user?.isBanned || user?.status === 'deleted';
  const displayName = deleted ? DELETED_ACCOUNT_NAME : (name || user?.name || user?.username || 'Пользователь');
  const avatarUrl = user?.avatar || avatar;
  const finalAvatar = deleted ? '' : (avatarUrl || `https://api.dicebear.com/7.x/identicon/svg?seed=${user?.username || displayName}`);

  const containerSizeClass = sizeClasses[size] || sizeClasses.md;
  const iconSizeClass = iconSizes[size] || iconSizes.md;

  return (
    <div
      onClick={onClick}
      className={`relative inline-flex shrink-0 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {deleted ? (
        <div
          className={`${containerSizeClass} rounded-full bg-slate-500/20 dark:bg-slate-700/50 border border-slate-400/30 text-slate-400 flex items-center justify-center shadow-inner`}
          title={DELETED_ACCOUNT_NAME}
        >
          <UserX className={`${iconSizeClass} stroke-[2] text-slate-400`} />
        </div>
      ) : (
        <img
          src={finalAvatar}
          alt={displayName}
          className={`${containerSizeClass} rounded-full object-cover border border-[var(--border)]`}
        />
      )}

      {showOnlineStatus && !deleted && (
        <span
          className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[var(--background)] ${
            isOnline ? 'bg-[var(--success)]' : 'bg-gray-400'
          }`}
        />
      )}
    </div>
  );
};
