// Safe media stream acquisition and synthetic fallback generator for WebRTC

export interface SafeMediaResult {
  stream: MediaStream;
  hasRealAudio: boolean;
  hasRealVideo: boolean;
  isSynthetic: boolean;
}

/**
 * Creates a silent audio track using Web Audio API
 */
export function createSilentAudioTrack(): MediaStreamTrack {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContextClass();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    const dst = ctx.createMediaStreamDestination();
    oscillator.connect(gainNode);
    gainNode.connect(dst);
    oscillator.start();
    const track = dst.stream.getAudioTracks()[0];
    track.enabled = true;
    return track;
  } catch (e) {
    const canvas = document.createElement('canvas');
    canvas.width = 2;
    canvas.height = 2;
    const stream = (canvas as any).captureStream ? (canvas as any).captureStream() : new MediaStream();
    return stream.getVideoTracks()[0] || null;
  }
}

/**
 * Creates an animated synthetic canvas video track with user avatar/initials
 */
export function createPlaceholderVideoTrack(userName: string = 'User'): MediaStreamTrack {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 480;
  const ctx = canvas.getContext('2d');

  let hue = 260;
  const draw = () => {
    if (!ctx) return;
    hue = (hue + 0.2) % 360;

    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#0f172a');
    gradient.addColorStop(1, '#1e1b4b');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle animated grid/dots
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    for (let x = 20; x < canvas.width; x += 40) {
      for (let y = 20; y < canvas.height; y += 40) {
        ctx.beginPath();
        ctx.arc(x, y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Avatar glowing ring
    ctx.save();
    ctx.beginPath();
    ctx.arc(320, 220, 75, 0, Math.PI * 2);
    ctx.fillStyle = '#6366f1';
    ctx.shadowColor = '#818cf8';
    ctx.shadowBlur = 20;
    ctx.fill();
    ctx.restore();

    // User initials
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 44px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const initials = (userName || 'U').substring(0, 2).toUpperCase();
    ctx.fillText(initials, 320, 220);

    // Label
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 18px sans-serif';
    ctx.fillText(userName, 320, 330);

    ctx.fillStyle = '#38bdf8';
    ctx.font = '14px sans-serif';
    ctx.fillText('Камера выключена / недоступна', 320, 360);
  };

  draw();
  const animInterval = setInterval(draw, 1000);

  const stream = canvas.captureStream(10);
  const track = stream.getVideoTracks()[0];

  const originalStop = track.stop.bind(track);
  track.stop = () => {
    clearInterval(animInterval);
    originalStop();
  };

  return track;
}

/**
 * Safely requests user media with graceful fallback against "Could not start video source" / NotReadableError / permission issues.
 */
export async function getSafeUserMedia(options: {
  type: 'audio' | 'video';
  facingMode?: 'user' | 'environment';
  userName?: string;
}): Promise<SafeMediaResult> {
  const wantsVideo = options.type === 'video';
  const facingMode = options.facingMode || 'user';

  // Attempt 1: Try requested configuration with flexible constraints
  if (wantsVideo) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        video: { facingMode }
      });
      return { stream, hasRealAudio: true, hasRealVideo: true, isSynthetic: false };
    } catch (err1: any) {
      console.warn('getUserMedia Attempt 1 failed:', err1?.message || err1);

      // Attempt 2: Try basic video: true without strict facingMode
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: true
        });
        return { stream, hasRealAudio: true, hasRealVideo: true, isSynthetic: false };
      } catch (err2: any) {
        console.warn('getUserMedia Attempt 2 (basic video) failed:', err2?.message || err2);

        // Attempt 3: Try audio only, and supply placeholder video track
        try {
          const audioStream = await navigator.mediaDevices.getUserMedia({
            audio: true,
            video: false
          });
          const placeholderVideo = createPlaceholderVideoTrack(options.userName);
          audioStream.addTrack(placeholderVideo);
          return { stream: audioStream, hasRealAudio: true, hasRealVideo: false, isSynthetic: false };
        } catch (err3: any) {
          console.warn('getUserMedia Attempt 3 (audio only) failed:', err3?.message || err3);
        }
      }
    }
  } else {
    // Audio Call:
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        video: false
      });
      return { stream, hasRealAudio: true, hasRealVideo: false, isSynthetic: false };
    } catch (errAudio: any) {
      console.warn('getUserMedia audio failed, attempting simple audio: true:', errAudio?.message || errAudio);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        return { stream, hasRealAudio: true, hasRealVideo: false, isSynthetic: false };
      } catch (errAudio2: any) {
        console.warn('Microphone access unavailable:', errAudio2?.message || errAudio2);
      }
    }
  }

  // Fallback: Create synthetic stream if no hardware or permissions failed
  const syntheticStream = new MediaStream();
  try {
    const silentAudio = createSilentAudioTrack();
    if (silentAudio) syntheticStream.addTrack(silentAudio);
  } catch (e) {}

  if (wantsVideo) {
    try {
      const placeholderVideo = createPlaceholderVideoTrack(options.userName);
      syntheticStream.addTrack(placeholderVideo);
    } catch (e) {}
  }

  return {
    stream: syntheticStream,
    hasRealAudio: false,
    hasRealVideo: false,
    isSynthetic: true
  };
}
