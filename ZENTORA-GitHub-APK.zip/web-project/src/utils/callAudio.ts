// Web Audio API Sound Generator for Zentora Calls (Outgoing dial tone, Incoming ringtone, Connected chime, End call beeps)

let audioCtx: AudioContext | null = null;
let currentLoopTimer: NodeJS.Timeout | null = null;
let currentOscillators: OscillatorNode[] = [];
let currentGainNodes: GainNode[] = [];

function getAudioContext(): AudioContext {
  if (!audioCtx || audioCtx.state === 'closed') {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export function stopAllCallSounds() {
  if (currentLoopTimer) {
    clearInterval(currentLoopTimer);
    currentLoopTimer = null;
  }
  currentOscillators.forEach(osc => {
    try {
      osc.stop();
      osc.disconnect();
    } catch (e) {}
  });
  currentOscillators = [];
  currentGainNodes.forEach(g => {
    try {
      g.disconnect();
    } catch (e) {}
  });
  currentGainNodes = [];
}

/**
 * Play Telegram-like outgoing call tone (Periodic gentle dual-frequency beep every 3.5s)
 */
export function playOutgoingRing() {
  stopAllCallSounds();
  try {
    const ctx = getAudioContext();

    const playBeep = () => {
      if (ctx.state === 'closed') return;
      const now = ctx.currentTime;
      
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(440, now); // A4
      
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(480, now);

      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(0.09, now + 0.08);
      gainNode.gain.setValueAtTime(0.09, now + 1.2);
      gainNode.gain.linearRampToValueAtTime(0, now + 1.35);

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 1.4);
      osc2.stop(now + 1.4);

      currentOscillators.push(osc1, osc2);
      currentGainNodes.push(gainNode);
    };

    playBeep();
    currentLoopTimer = setInterval(playBeep, 3500);
  } catch (e) {
    console.warn('Could not play outgoing ring tone:', e);
  }
}

/**
 * Play Telegram-style melodic incoming ringtone (Pleasant chord chime progression repeating every 3s)
 */
export function playIncomingRingtone() {
  stopAllCallSounds();
  try {
    const ctx = getAudioContext();

    const notes = [
      { freq: 523.25, time: 0, dur: 0.15 },    // C5
      { freq: 659.25, time: 0.16, dur: 0.15 }, // E5
      { freq: 783.99, time: 0.32, dur: 0.2 },  // G5
      { freq: 1046.50, time: 0.52, dur: 0.3 }, // C6
      { freq: 783.99, time: 0.9, dur: 0.15 },  // G5
      { freq: 1046.50, time: 1.08, dur: 0.4 }, // C6
    ];

    const playMelody = () => {
      if (ctx.state === 'closed') return;
      const startTime = ctx.currentTime;

      notes.forEach(({ freq, time, dur }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime + time);

        gain.gain.setValueAtTime(0, startTime + time);
        gain.gain.linearRampToValueAtTime(0.12, startTime + time + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + time + dur);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(startTime + time);
        osc.stop(startTime + time + dur + 0.05);

        currentOscillators.push(osc);
        currentGainNodes.push(gain);
      });
    };

    playMelody();
    currentLoopTimer = setInterval(playMelody, 2800);
  } catch (e) {
    console.warn('Could not play incoming ringtone:', e);
  }
}

/**
 * Play Connected Tone (Short happy 2-note ascending chime)
 */
export function playConnectedTone() {
  stopAllCallSounds();
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.setValueAtTime(880.00, now + 0.12); // A5

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.12, now + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc1.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc1.stop(now + 0.45);
  } catch (e) {}
}

/**
 * Play End Call Tone (Short descending busy tone)
 */
export function playEndCallTone() {
  stopAllCallSounds();
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const freqs = [480, 480, 480];
    freqs.forEach((freq, idx) => {
      const start = now + idx * 0.18;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);

      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.09, start + 0.02);
      gain.gain.linearRampToValueAtTime(0, start + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(start);
      osc.stop(start + 0.14);
    });
  } catch (e) {}
}

/**
 * Play short UI toggle feedback
 */
export function playToggleTone(isMuted: boolean) {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(isMuted ? 320 : 640, now);

    gain.gain.setValueAtTime(0.05, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.1);
  } catch (e) {}
}
