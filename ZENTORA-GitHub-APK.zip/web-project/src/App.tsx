import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ChatProvider, useChat } from './context/ChatContext';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { InfoPanel } from './components/InfoPanel';
import { ContactsView } from './components/ContactsView';
import { CallsView } from './components/CallsView';
import { CallProvider } from './context/CallContext';
import { CallOverlay } from './components/CallOverlay';
import { IncomingCallModal } from './components/IncomingCallModal';

import { MusicProvider } from './context/MusicContext';
import { FloatingMusicBar } from './components/FloatingMusicBar';
import { MusicPlayerModal } from './components/MusicPlayerModal';

import { AuthModal } from './components/AuthModal';
import { SettingsModal } from './components/SettingsModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { CreateChatModal } from './components/CreateChatModal';
import { ReportModal } from './components/ReportModal';
import { MediaViewer } from './components/MediaViewer';

import { StoriesModal } from './components/StoriesModal';
import { BannedAccountModal } from './components/BannedAccountModal';

import { MessageSquare, Contact, Phone, Settings } from 'lucide-react';
import { Attachment } from './types';


const MainLayout: React.FC = () => {
  const { user, isAuthenticated, bannedUserModal, setBannedUserModal, unbanUser } = useAuth();
  const { activeChatId, showInfoPanel, setShowInfoPanel, setIsSearchOpen } = useChat();

  const [activeSection, setActiveSection] = useState<'chats' | 'contacts' | 'calls'>('chats');
  const [globalTab, setGlobalTab] = useState<string>('feed');
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(false);
  const [isMobileScreen, setIsMobileScreen] = useState<boolean>(false);

  // Modals
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showCreateChatModal, setShowCreateChatModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showStoriesModal, setShowStoriesModal] = useState(false);
  
  const [selectedMedia, setSelectedMedia] = useState<Attachment | null>(null);

  // Screen Auto-Detection
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobileScreen(mobile);
      if (mobile) {
        setIsPhoneFrame(false); // native full screen on mobile device
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!isAuthenticated || !user) {
    return (
      <>
        <AuthModal />
        {bannedUserModal && (
          <BannedAccountModal
            bannedUser={bannedUserModal}
            onClose={() => setBannedUserModal(null)}
            onUnbanned={async (banned) => {
              await unbanUser(banned.id);
              setBannedUserModal(null);
            }}
          />
        )}
      </>
    );
  }

  const isPhoneView = isMobileScreen || isPhoneFrame;

  return (
    <div className="flex flex-col h-[100dvh] w-full max-w-full overflow-hidden bg-[#090b10] text-gray-900 dark:text-white transition-colors duration-300 relative items-center justify-center">
      
      {/* Main Container Envelope */}
      <div className={`relative flex flex-col h-full w-full max-w-full transition-all duration-300 ${
        isPhoneFrame 
          ? 'max-w-[390px] h-[830px] rounded-[50px] border-[10px] border-slate-800 bg-[var(--background)] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden ring-1 ring-white/10'
          : 'w-full h-full bg-[var(--background)]'
      }`}>

                {/* App Content Area */}
        <div className="flex flex-1 overflow-hidden relative w-full h-full">
          
          {/* Sidebar / Chat List */}
          <div className={`${activeChatId && isPhoneView ? 'hidden' : 'flex'} w-full ${!isPhoneView ? 'md:w-80 lg:w-96' : ''} shrink-0 h-full`}>
            <Sidebar
              onOpenCreateChat={() => setShowCreateChatModal(true)}
              onOpenSettings={() => setShowSettingsModal(true)}
              onOpenAdmin={() => setShowAdminModal(true)}
              activeSection={activeSection}
              setActiveSection={setActiveSection}
            />
          </div>

          {/* Center Main Chat Area */}
          <div className={`${activeChatId || !isPhoneView ? 'flex' : 'hidden'} flex-1 h-full overflow-hidden relative`}>
            {activeSection === 'chats' && (
              <ChatArea
                onToggleInfoPanel={() => setShowInfoPanel(!showInfoPanel)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenReport={() => setShowReportModal(true)}
              />
            )}
            {activeSection === 'contacts' && <ContactsView onChatStart={() => setActiveSection('chats')} />}
            {activeSection === 'calls' && <CallsView />}

            {/* Right Info Panel */}
            {showInfoPanel && activeSection === 'chats' && (
              <InfoPanel
                onClose={() => setShowInfoPanel(false)}
                onOpenReport={() => setShowReportModal(true)}
                onOpenMediaViewer={(att) => setSelectedMedia(att)}
                onOpenSearch={() => setIsSearchOpen(true)}
              />
            )}
          </div>
        </div>

        {/* Floating Mobile Dock Navigation Bar */}
        {isPhoneView && !activeChatId && (
          <div className="p-2 pb-3 bg-slate-950/90 backdrop-blur-2xl border-t border-white/10 shrink-0 z-40 select-none">
            <div className="w-full max-w-sm mx-auto bg-slate-900/90 border border-white/10 rounded-full p-1 flex items-center justify-around gap-1 shadow-2xl">
              <button
                onClick={() => setActiveSection('chats')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all ${
                  activeSection === 'chats'
                    ? 'bg-purple-600/30 text-purple-200 font-bold border border-purple-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-purple-400" />
                <span>Чаты</span>
              </button>
              <button
                onClick={() => setActiveSection('calls')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all ${
                  activeSection === 'calls'
                    ? 'bg-emerald-600/30 text-emerald-200 font-bold border border-emerald-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Звонки</span>
              </button>
              <button
                onClick={() => setActiveSection('contacts')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-all ${
                  activeSection === 'contacts'
                    ? 'bg-blue-600/30 text-blue-200 font-bold border border-blue-500/30 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Contact className="w-4 h-4 text-blue-400" />
                <span>Контакты</span>
              </button>
            </div>
          </div>
        )}
      </div>
      {/* Overlay Modals */}
      {showSettingsModal && (
        <SettingsModal
          onClose={() => setShowSettingsModal(false)}
          isPhoneFrame={isPhoneFrame}
          onTogglePhoneFrame={(val) => setIsPhoneFrame(val)}
        />
      )}
      {showAdminModal && <AdminPanelModal onClose={() => setShowAdminModal(false)} />}
      {showCreateChatModal && <CreateChatModal onClose={() => setShowCreateChatModal(false)} />}
      {showStoriesModal && <StoriesModal currentUser={user} isOpen={showStoriesModal} onClose={() => setShowStoriesModal(false)} />}
      {showReportModal && (
        <ReportModal
          targetId="msg_1"
          targetType="message"
          onClose={() => setShowReportModal(false)}
        />
      )}
      {selectedMedia && (
        <MediaViewer
          attachment={selectedMedia}
          allAttachments={[selectedMedia]}
          onClose={() => setSelectedMedia(null)}
        />
      )}

      {/* Call System */}
      <CallOverlay />
      <IncomingCallModal />

      {/* Music System */}
      <FloatingMusicBar />
      <MusicPlayerModal />

    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MusicProvider>
        <ChatProvider>
          <CallProvider>
            <MainLayout />
          </CallProvider>
        </ChatProvider>
      </MusicProvider>
    </AuthProvider>
  );
}
