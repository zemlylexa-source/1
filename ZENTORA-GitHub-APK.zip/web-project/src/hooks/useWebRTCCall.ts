import { useEffect, useRef, useState } from 'react';
import { db, auth } from '../lib/firebase';
import { 
  collection, 
  doc, 
  onSnapshot, 
  addDoc, 
  setDoc, 
  updateDoc, 
  getDoc,
  serverTimestamp,
  query,
  where,
  deleteDoc
} from 'firebase/firestore';

const servers = {
  iceServers: [
    {
      urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'],
    },
  ],
  iceCandidatePoolSize: 10,
};

export function useWebRTCCall(callId: string | null, isCaller: boolean) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const pc = useRef<RTCPeerConnection | null>(null);

  useEffect(() => {
    if (!callId) return;

    const startCall = async () => {
      pc.current = new RTCPeerConnection(servers);

      // Get local media
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      setLocalStream(stream);
      stream.getTracks().forEach((track) => {
        pc.current?.addTrack(track, stream);
      });

      // Handle remote tracks
      pc.current.ontrack = (event) => {
        setRemoteStream(event.streams[0]);
      };

      // Handle ICE candidates
      pc.current.onicecandidate = async (event) => {
        if (event.candidate) {
          try {
            const signalRef = collection(db, 'calls', callId, 'signals');
            await addDoc(signalRef, {
              type: 'candidate',
              data: JSON.stringify(event.candidate),
              senderId: auth.currentUser?.uid,
              timestamp: Date.now(),
            });
          } catch (e) {
            console.warn("ICE candidate signal write error:", e);
          }
        }
      };

      if (isCaller) {
        // Create Offer
        const offerDescription = await pc.current.createOffer();
        await pc.current.setLocalDescription(offerDescription);

        const signalRef = collection(db, 'calls', callId, 'signals');
        await addDoc(signalRef, {
          type: 'offer',
          data: JSON.stringify(offerDescription),
          senderId: auth.currentUser?.uid,
          timestamp: Date.now(),
        });
      }

      // Listen for signals
      const signalsRef = collection(db, 'calls', callId, 'signals');
      const unsubscribe = onSnapshot(signalsRef, async (snapshot) => {
        for (const change of snapshot.docChanges()) {
          if (change.type === 'added') {
            const data = change.doc.data();
            if (data.senderId === auth.currentUser?.uid) continue;

            if (data.type === 'offer' && !isCaller) {
              const offer = JSON.parse(data.data);
              await pc.current?.setRemoteDescription(new RTCSessionDescription(offer));
              const answerDescription = await pc.current?.createAnswer();
              await pc.current?.setLocalDescription(answerDescription);

              await addDoc(signalsRef, {
                type: 'answer',
                data: JSON.stringify(answerDescription),
                senderId: auth.currentUser?.uid,
                timestamp: Date.now(),
              });
            } else if (data.type === 'answer' && isCaller) {
              const answer = JSON.parse(data.data);
              await pc.current?.setRemoteDescription(new RTCSessionDescription(answer));
            } else if (data.type === 'candidate') {
              const candidate = new RTCIceCandidate(JSON.parse(data.data));
              await pc.current?.addIceCandidate(candidate);
            }
          }
        }
      }, (err) => {
        console.warn("WebRTC signals snapshot error:", err);
      });

      return () => {
        unsubscribe();
        stream.getTracks().forEach((track) => track.stop());
        pc.current?.close();
      };
    };

    startCall();
  }, [callId, isCaller]);

  return { localStream, remoteStream };
}
