import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';

try {
  // Security cleanup (CWE-922)
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith('zentora_')) {
      localStorage.removeItem(key);
      i--; // Adjust index since we removed an item
    }
  }
} catch(e) {}

import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
