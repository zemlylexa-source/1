import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { Chat, Message, Reaction, Attachment, ChatType } from '../types';
import { useAuth } from './AuthContext';
import { db, cleanObject } from '../lib/firebase';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  setDoc, 
  doc, 
  updateDoc, 
  deleteDoc, 
  orderBy,
  serverTimestamp,
  increment
} from 'firebase/firestore';

export type SidebarTab = 'all' | 'unread' | 'personal' | 'groups' | 'channels' | 'saved' | 'archive';

interface ChatContextType {
  chats: Chat[];
  activeChat: Chat | null;
  activeChatId: string | null;
  setActiveChatId: (id: string | null) => void;
  messages: Message[];
  messagesMap: Record<string, Message[]>;
  activeTab: SidebarTab;
  setActiveTab: (tab: SidebarTab) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  replyingToMessage: Message | null;
  setReplyingToMessage: (msg: Message | null) => void;
  editingMessage: Message | null;
  setEditingMessage: (msg: Message | null) => void;
  typingUsers: Record<string, string[]>; 
  onlineUsers: Set<string>;
  sendMessage: (text: string, attachments?: Attachment[]) => Promise<void>;
  editMessage: (messageId: string, newText: string) => Promise<void>;
  deleteMessage: (messageId: string) => Promise<void>;
  togglePinMessage: (messageId: string) => void;
  addReaction: (messageId: string, emoji: string) => void;
  forwardMessage: (targetChatId: string, message: Message) => void;
  createChat: (type: ChatType, name?: string, memberIds?: string[], description?: string, avatar?: string) => Promise<string>;
  archiveChat: (chatId: string) => void;
  unarchiveChat: (chatId: string) => void;
  toggleMuteChat: (chatId: string) => void;
  togglePinChat: (chatId: string) => void;
  clearChatHistory: (chatId: string) => void;
  deleteChat: (chatId: string) => void;
  sendTypingSignal: (isTyping: boolean) => void;
  getOrCreateDirectChat: (targetUser: { id: string; name: string; avatar?: string; username?: string }) => Promise<string>;
  getOrCreateSavedMessages: () => Promise<string>;
  showInfoPanel: boolean;
  setShowInfoPanel: (show: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (show: boolean) => void;
  socket: WebSocket | null;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>({});
  const [activeTab, setActiveTab] = useState<SidebarTab>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [replyingToMessage, setReplyingToMessage] = useState<Message | null>(null);
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);
  const [showInfoPanel, setShowInfoPanel] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [typingUsers, setTypingUsers] = useState<Record<string, string[]>>({});
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // 1. Sync Chats from Firestore
  useEffect(() => {
    if (!user) {
      setChats([]);
      return;
    }

    const chatsQuery = query(
      collection(db, 'chats'),
      where('memberIds', 'array-contains', user.id)
    );

    const unsubscribe = onSnapshot(chatsQuery, (snapshot) => {
      const chatsMap = new Map<string, Chat>();



      // Firestore chats override
      snapshot.forEach(docSnap => {
        const chat = { ...docSnap.data() as Chat, id: docSnap.id };
        if (!Array.isArray(chat.memberIds)) chat.memberIds = [];
        chatsMap.set(chat.id, chat);
      });

      const chatList = Array.from(chatsMap.values());
      setChats(chatList.sort((a, b) => {
        const timeA = a.lastMessage?.timestamp || 0;
        const timeB = b.lastMessage?.timestamp || 0;
        return timeB - timeA;
      }));
    }, (err) => {
      console.warn("Chats snapshot error:", err);

    });

    return () => unsubscribe();
  }, [user]);

  // 2. Sync Messages for Active Chat
  useEffect(() => {
    if (!activeChatId || !user) return;

    const messagesQuery = query(
      collection(db, 'chats', activeChatId, 'messages'),
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(messagesQuery, (snapshot) => {
      const msgList: Message[] = [];
      snapshot.forEach(doc => msgList.push({ ...doc.data() as Message, id: doc.id }));
      setMessagesMap(prev => ({
        ...prev,
        [activeChatId]: msgList
      }));
    }, (err) => {
      console.warn("Messages snapshot error:", err);
    });

    return () => unsubscribe();
  }, [activeChatId, user]);

  // WebSocket for Typing Signals
  useEffect(() => {
    if (!user) return;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
    socketRef.current = ws;
    setSocket(ws);

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'auth', payload: { userId: user.id } }));
    };

    ws.onmessage = (event) => {
      try {
        const { type, payload } = JSON.parse(event.data);
        if (type === 'typing:start') {
          const { chatId, userName } = payload;
          setTypingUsers(prev => ({
            ...prev,
            [chatId]: Array.from(new Set([...(prev[chatId] || []), userName]))
          }));
        } else if (type === 'typing:stop') {
          const { chatId, userName } = payload;
          setTypingUsers(prev => ({
            ...prev,
            [chatId]: (prev[chatId] || []).filter(n => n !== userName)
          }));
        } else if (type === 'user:online') {
          setOnlineUsers(prev => new Set(prev).add(payload.userId));
        } else if (type === 'user:offline') {
          setOnlineUsers(prev => {
            const next = new Set(prev);
            next.delete(payload.userId);
            return next;
          });
        }
      } catch (e) {}
    };

    return () => ws.close();
  }, [user]);

  const activeChat = chats.find(c => c.id === activeChatId) || null;
  const messages = activeChatId ? (messagesMap[activeChatId] || []) : [];

  const sendMessage = async (text: string, attachments?: Attachment[]) => {
    if (!activeChatId || !user) return;
    const msgId = doc(collection(db, 'chats', activeChatId, 'messages')).id;
    
    // Create base message, omitting undefined
    const message: Message = {
      id: msgId,
      chatId: activeChatId,
      senderId: user.id,
      senderName: user.name,
      text: text.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timestamp: Date.now(),
      status: 'sent',
    };

    if (user.avatar) message.senderAvatar = user.avatar;
    if (attachments && attachments.length > 0) message.attachments = attachments;
    if (replyingToMessage) {
      message.replyToMessage = {
        id: replyingToMessage.id,
        senderName: replyingToMessage.senderName,
        text: replyingToMessage.text
      };
    }

    // Immediately update local messages state
    setMessagesMap(prev => ({
      ...prev,
      [activeChatId]: [...(prev[activeChatId] || []), message]
    }));

    // Immediately update chat's last message in chats list
    setChats(prev => {
      const updated = prev.map(c => {
        if (c.id === activeChatId) {
          return { ...c, lastMessage: message, updatedAt: new Date().toISOString() };
        }
        return c;
      });

      return updated;
    });

    try {
      await setDoc(doc(db, 'chats', activeChatId, 'messages', msgId), cleanObject(message));
      await setDoc(doc(db, 'chats', activeChatId), cleanObject({
        lastMessage: message,
        updatedAt: serverTimestamp()
      }), { merge: true });
    } catch (e) {
      console.warn('Firestore message save note:', e);
    }
    
    setReplyingToMessage(null);
  };

  const createChat = async (type: ChatType, name?: string, memberIds?: string[], description?: string, avatar?: string) => {
    if (!user) return '';
    const chatId = doc(collection(db, 'chats')).id;
    const newChat: Chat = {
      id: chatId,
      type,
      name: name || 'Новый чат',
      avatar: avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${chatId}`,
      description: description || '',
      memberIds: Array.from(new Set([user.id, ...(memberIds || [])])),
      members: [
        { userId: user.id, role: 'owner', joinedAt: new Date().toISOString() },
        ...(memberIds || []).map(id => ({ userId: id, role: 'member' as const, joinedAt: new Date().toISOString() }))
      ],
      ownerId: user.id,
      unreadCount: 0,
      createdAt: new Date().toISOString()
    };
    
    if (type === 'direct' && description?.startsWith('@')) {
        newChat.username = description.substring(1);
    }

    // Immediately add to local state and local storage
    setChats(prev => {
      const next = [newChat, ...prev.filter(c => c.id !== chatId)];

      return next;
    });

    setActiveChatId(chatId);

    try {
      await setDoc(doc(db, 'chats', chatId), cleanObject(newChat));
    } catch (e) {
      console.warn("Firestore chat save note:", e);
    }

    return chatId;
  };

  const getOrCreateDirectChat = async (targetUser: { id: string; name: string; avatar?: string; username?: string }) => {
    if (!user || !targetUser || !targetUser.id) return '';
    const existing = chats.find(c => c && c.type === 'direct' && Array.isArray(c.memberIds) && c.memberIds.includes(targetUser.id));
    if (existing) {
      setActiveChatId(existing.id);
      return existing.id;
    }
    return await createChat('direct', targetUser.name, [targetUser.id], `@${targetUser.username || ''}`, targetUser.avatar);
  };

  const getOrCreateSavedMessages = async () => {
    if (!user) return '';
    const existing = chats.find(c => c.type === 'saved' && c.ownerId === user.id);
    if (existing) {
      setActiveChatId(existing.id);
      return existing.id;
    }
    return await createChat('saved', 'Избранное', [], 'Сохраненные сообщения', 'https://api.dicebear.com/7.x/identicon/svg?seed=saved');
  };

  const editMessage = async (messageId: string, newText: string) => {
    if (!activeChatId) return;
    await setDoc(doc(db, 'chats', activeChatId, 'messages', messageId), cleanObject({
      text: newText,
      isEdited: true
    }), { merge: true });
    setEditingMessage(null);
  };

  const deleteMessage = async (messageId: string) => {
    if (!activeChatId) return;
    await deleteDoc(doc(db, 'chats', activeChatId, 'messages', messageId));
  };

  const sendTypingSignal = (isTyping: boolean) => {
    if (socket?.readyState === WebSocket.OPEN && activeChatId && user) {
      socket.send(JSON.stringify({
        type: isTyping ? 'typing:start' : 'typing:stop',
        payload: { chatId: activeChatId, userName: user.name }
      }));
    }
  };

  const togglePinMessage = async (messageId: string) => {
    if (!activeChatId) return;
    const msgRef = doc(db, 'chats', activeChatId, 'messages', messageId);
    const msg = messages.find(m => m.id === messageId);
    if (msg) {
      await updateDoc(msgRef, { isPinned: !msg.isPinned });
    }
  };

  const addReaction = async (messageId: string, emoji: string) => {
    if (!activeChatId || !user) return;
    const msgRef = doc(db, 'chats', activeChatId, 'messages', messageId);
    const msg = messages.find(m => m.id === messageId);
    if (!msg) return;

    let currentReactions = msg.reactions || [];
    const existingReactionIndex = currentReactions.findIndex(r => r.emoji === emoji);

    if (existingReactionIndex > -1) {
      const rx = { ...currentReactions[existingReactionIndex] };
      const usersList = rx.users;
      
      // Safety check in case old data has userIds or isn't an array
      const normalizedUsers: string[] = Array.isArray(usersList) 
        ? [...usersList] 
        : (usersList ? [String(usersList)] : []);
      const userIndex = (Array.isArray(normalizedUsers) && user?.id) ? normalizedUsers.indexOf(user.id) : -1;

      if (userIndex > -1) {
        normalizedUsers.splice(userIndex, 1);
        rx.count = Math.max(0, rx.count - 1);
      } else {
        normalizedUsers.push(user.id);
        rx.count += 1;
      }
      rx.users = normalizedUsers;
      currentReactions[existingReactionIndex] = rx;
    } else {
      currentReactions.push({
        emoji,
        count: 1,
        users: [user.id]
      });
    }

    currentReactions = currentReactions.filter(r => r.count > 0);
    await updateDoc(msgRef, { reactions: currentReactions });
  };

  const forwardMessage = async (targetChatId: string, message: Message) => {
    if (!user) return;
    const msgId = doc(collection(db, 'chats', targetChatId, 'messages')).id;
    
    const forwardedMsg: Message = {
      id: msgId,
      chatId: targetChatId,
      senderId: user.id,
      senderName: user.name,
      text: message.text || '',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timestamp: Date.now(),
      status: 'sent',
      forwardedFrom: message.senderName
    };
    if (user.avatar) forwardedMsg.senderAvatar = user.avatar;
    if (message.attachments && message.attachments.length > 0) forwardedMsg.attachments = message.attachments;

    await setDoc(doc(db, 'chats', targetChatId, 'messages', msgId), cleanObject(forwardedMsg));
    await setDoc(doc(db, 'chats', targetChatId), cleanObject({
      lastMessage: forwardedMsg,
      updatedAt: serverTimestamp()
    }), { merge: true });
  };

  const archiveChat = async (chatId: string) => {
    const chatRef = doc(db, 'chats', chatId);
    await updateDoc(chatRef, { isArchived: true });
  };

  const unarchiveChat = async (chatId: string) => {
    const chatRef = doc(db, 'chats', chatId);
    await updateDoc(chatRef, { isArchived: false });
  };

  const toggleMuteChat = async (chatId: string) => {
    const chatRef = doc(db, 'chats', chatId);
    const chatObj = chats.find(c => c.id === chatId);
    if (chatObj) {
      await updateDoc(chatRef, { isMuted: !chatObj.isMuted });
    }
  };

  const togglePinChat = async (chatId: string) => {
    const chatRef = doc(db, 'chats', chatId);
    const chatObj = chats.find(c => c.id === chatId);
    if (chatObj) {
      await updateDoc(chatRef, { isPinned: !chatObj.isPinned });
    }
  };

  const clearChatHistory = async (chatId: string) => {
    await updateDoc(doc(db, 'chats', chatId), {
      lastMessage: null
    });
  };

  const deleteChat = async (chatId: string) => {
    await deleteDoc(doc(db, 'chats', chatId));
    if (activeChatId === chatId) {
      setActiveChatId(null);
    }
  };

  return (
    <ChatContext.Provider
      value={{
        chats, activeChat, activeChatId, setActiveChatId,
        messages, messagesMap, activeTab, setActiveTab,
        searchQuery, setSearchQuery, replyingToMessage, setReplyingToMessage,
        editingMessage, setEditingMessage, typingUsers, onlineUsers,
        sendMessage, editMessage, deleteMessage, togglePinMessage,
        addReaction, forwardMessage, createChat, archiveChat, unarchiveChat,
        toggleMuteChat, togglePinChat, clearChatHistory, deleteChat,
        sendTypingSignal, getOrCreateDirectChat, getOrCreateSavedMessages,
        showInfoPanel, setShowInfoPanel, isSearchOpen, setIsSearchOpen, socket
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) throw new Error('useChat must be used within a ChatProvider');
  return context;
};
