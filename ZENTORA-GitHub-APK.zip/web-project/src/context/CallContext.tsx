import React, { createContext, useContext, useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { CallInfo, CallLog, CallType, CallState } from '../types';
import { db, cleanObject } from '../lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  onSnapshot, 
  updateDoc, 
  deleteDoc, 
  query, 
  where,
  serverTimestamp 
} from 'firebase/firestore';
import { 
  playOutgoingRing, 
  playIncomingRingtone, 
  playConnectedTone, 
  playEndCallTone, 
  playToggleTone,
  stopAllCallSounds 
} from '../utils/callAudio';
import { getSafeUserMedia } from '../utils/mediaStream';

interface CallContextType {
  activeCall: CallInfo | null;
  incomingCall: CallInfo | null;
  callLogs: CallLog[];
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isMuted: boolean;
  isVideoOff: boolean;
  isSpeakerOn: boolean;
  isMinimized: boolean;
  callDuration: number;
  connectionQuality: 'excellent' | 'good' | 'poor' | 'reconnecting';
  startCall: (chatId: string, recipient: { id: string; name: string; avatar?: string }, type: CallType) => Promise<void>;
  acceptCall: (withVideo?: boolean) => Promise<void>;
  declineCall: () => Promise<void>;
  endCall: () => Promise<void>;
  toggleMute: () => void;
  toggleVideo: () => void;
  switchCamera: () => Promise<void>;
  toggleSpeaker: () => void;
  setMinimized: (minimized: boolean) => void;
  clearCallHistory: () => Promise<void>;
  redialCall: (log: CallLog) => Promise<void>;
}

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun3.l.google.com:19302' },
    { urls: 'stun:stun.services.mozilla.com' }
  ],
  iceCandidatePoolSize: 10
};

const CallContext = createContext<CallContextType | undefined>(undefined);

export const CallProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  const [activeCall, setActiveCall] = useState<CallInfo | null>(null);
  const [incomingCall, setIncomingCall] = useState<CallInfo | null>(null);
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);

  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [callDuration, setCallDuration] = useState(0);
  const [connectionQuality, setConnectionQuality] = useState<'excellent' | 'good' | 'poor' | 'reconnecting'>('excellent');

  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const pendingSignalingQueue = useRef<{ type: string; payload: any }[]>([]);
  const reconnectTimerRef = useRef<NodeJS.Timeout | null>(null);
  const iceCandidatesQueue = useRef<RTCIceCandidateInit[]>([]);
  const durationTimerRef = useRef<NodeJS.Timeout | null>(null);
  const activeCallRef = useRef<CallInfo | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const hasSentAnswer = useRef<boolean>(false);
  const callDocUnsubRef = useRef<(() => void) | null>(null);

  activeCallRef.current = activeCall;
  localStreamRef.current = localStream;

  // 1. Fetch Call History
  const fetchCallLogs = useCallback(async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/calls/history?userId=${encodeURIComponent(user.id)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.calls) {
          const logs: CallLog[] = data.calls.map((c: any) => ({
            id: c.id,
            chatId: c.chatId || '',
            callerId: c.callerId,
            callerName: c.callerName,
            callerAvatar: c.callerAvatar,
            recipientId: c.recipientId,
            recipientName: c.recipientName,
            recipientAvatar: c.recipientAvatar,
            type: c.type,
            direction: c.callerId === user.id ? 'outgoing' : (c.status === 'missed' ? 'missed' : 'incoming'),
            status: c.status,
            time: new Date(c.timestamp || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            timestamp: c.timestamp || Date.now(),
            duration: c.duration || 0
          }));
          setCallLogs(logs);
        }
      }
    } catch (e) {
      // Fallback local storage
      try {
        const saved = localStorage.getItem(`zentora_call_logs_${user.id}`);
        if (saved) setCallLogs(JSON.parse(saved));
      } catch (err) {}
    }
  }, [user]);

  useEffect(() => {
    fetchCallLogs();
  }, [fetchCallLogs]);

  // 2. Request Notification Permission
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }, []);

  // 3. Resilient WebSocket Manager with Auto-Reconnect & Queue
  const sendSignal = useCallback((type: string, payload: any) => {
    const msgString = JSON.stringify({ type, payload });
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      try {
        socketRef.current.send(msgString);
      } catch (e) {
        console.warn('Socket send error:', e);
      }
    } else {
      // Queue for delivery upon reconnection
      pendingSignalingQueue.current.push({ type, payload });
      // Ensure socket is connecting
      connectSocket();
    }
  }, []);

  const connectSocket = useCallback(() => {
    if (!user) return;
    if (socketRef.current && (socketRef.current.readyState === WebSocket.OPEN || socketRef.current.readyState === WebSocket.CONNECTING)) {
      return;
    }

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      socketRef.current = ws;

      ws.onopen = () => {
        console.log('Call signaling socket connected');
        ws.send(JSON.stringify({ type: 'auth', payload: { userId: user.id } }));

        // Flush pending signaling queue
        while (pendingSignalingQueue.current.length > 0) {
          const item = pendingSignalingQueue.current.shift();
          if (item && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(item));
          }
        }
      };

      ws.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'pong') return;
          handleSignalingMessage(data.type, data.payload);
        } catch (e) {
          console.error('Signaling parse error:', e);
        }
      };

      ws.onerror = (e) => {
        console.warn('Call signaling socket error:', e);
      };

      ws.onclose = () => {
        console.log('Call signaling socket closed, reconnecting in 2s...');
        socketRef.current = null;
        if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = setTimeout(() => {
          connectSocket();
        }, 2000);
      };
    } catch (err) {
      console.warn('Socket connection failure:', err);
    }
  }, [user]);

  // Keep-alive heartbeat & initial socket setup
  useEffect(() => {
    if (!user) return;
    connectSocket();

    const pingInterval = setInterval(() => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify({ type: 'ping' }));
      } else {
        connectSocket();
      }
    }, 12000);

    return () => {
      clearInterval(pingInterval);
      if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
    };
  }, [user, connectSocket]);

  // 4. Firestore Realtime Signaling Backup Listener
  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'calls'),
      where('recipientId', '==', user.id),
      where('state', '==', 'ringing')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const callData = change.doc.data() as CallInfo;
          if (!activeCallRef.current && (!incomingCall || incomingCall.id !== change.doc.id)) {
            handleIncomingCallSignal({
              ...callData,
              id: change.doc.id,
              isIncoming: true
            });
          }
        } else if (change.type === 'removed') {
          if (incomingCall && incomingCall.id === change.doc.id) {
            setIncomingCall(null);
            stopAllCallSounds();
          }
        }
      });
    }, (err) => console.warn('Firestore call listener note:', err));

    return () => unsubscribe();
  }, [user, incomingCall]);

  // 5. Manage Call Duration Timer
  useEffect(() => {
    if (activeCall?.state === 'connected') {
      setCallDuration(0);
      durationTimerRef.current = setInterval(() => {
        setCallDuration(d => d + 1);
      }, 1000);
    } else {
      if (durationTimerRef.current) {
        clearInterval(durationTimerRef.current);
        durationTimerRef.current = null;
      }
      if (!activeCall) {
        setCallDuration(0);
      }
    }
    return () => {
      if (durationTimerRef.current) {
        clearInterval(durationTimerRef.current);
      }
    };
  }, [activeCall?.state]);

  // Create or retrieve RTCPeerConnection
  const getOrCreatePeerConnection = useCallback(() => {
    if (peerConnectionRef.current && peerConnectionRef.current.signalingState !== 'closed') {
      return peerConnectionRef.current;
    }

    const pc = new RTCPeerConnection(ICE_SERVERS);
    peerConnectionRef.current = pc;
    hasSentAnswer.current = false;

    pc.onicecandidate = (event) => {
      if (event.candidate && socketRef.current?.readyState === WebSocket.OPEN) {
        const current = activeCallRef.current;
        if (!current) return;
        const targetId = current.isIncoming ? current.callerId : current.recipientId;
        socketRef.current.send(JSON.stringify({
          type: 'call:ice-candidate',
          payload: {
            callId: current.id,
            targetUserId: targetId,
            candidate: event.candidate.toJSON()
          }
        }));
      }
    };

    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        setRemoteStream(event.streams[0]);
      } else {
        setRemoteStream(prev => {
          if (prev) {
            const hasTrack = prev.getTracks().some(t => t.id === event.track.id);
            if (!hasTrack) {
              prev.addTrack(event.track);
            }
            return new MediaStream(prev.getTracks());
          }
          return new MediaStream([event.track]);
        });
      }
    };

    pc.oniceconnectionstatechange = () => {
      const state = pc.iceConnectionState;
      if (state === 'connected' || state === 'completed') {
        setConnectionQuality('excellent');
        setActiveCall(prev => prev ? { ...prev, state: 'connected' } : null);
        playConnectedTone();
      } else if (state === 'disconnected') {
        setConnectionQuality('reconnecting');
        try {
          pc.restartIce();
        } catch (e) {}
      } else if (state === 'failed') {
        setConnectionQuality('poor');
      }
    };

    return pc;
  }, []);

  // Save Completed Call Log and write to Chat
  const recordCallLog = async (call: CallInfo, finalDuration: number, finalStatus: 'completed' | 'missed' | 'declined' | 'busy' | 'failed') => {
    if (!user) return;
    const isCaller = call.callerId === user.id;
    const isVideo = call.type === 'video';
    const typeLabel = isVideo ? 'Видеозвонок' : 'Голосовой звонок';

    const logItem: CallLog = {
      id: `call_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      chatId: call.chatId,
      callerId: call.callerId,
      callerName: call.callerName,
      callerAvatar: call.callerAvatar,
      recipientId: call.recipientId,
      recipientName: call.recipientName,
      recipientAvatar: call.recipientAvatar,
      type: call.type,
      direction: isCaller ? 'outgoing' : (finalStatus === 'missed' ? 'missed' : 'incoming'),
      status: finalStatus,
      duration: finalDuration,
      timestamp: Date.now(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setCallLogs(prev => [logItem, ...prev.slice(0, 49)]);

    try {
      await fetch('/api/calls/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(logItem)
      });
      localStorage.setItem(`zentora_call_logs_${user.id}`, JSON.stringify([logItem, ...callLogs.slice(0, 49)]));
    } catch (e) {}

    // Post to chat if chatId is available (only caller posts to avoid duplicate messages in chat)
    if (call.chatId && isCaller) {
      let statusText = '';
      if (finalStatus === 'completed') {
        const mins = Math.floor(finalDuration / 60);
        const secs = finalDuration % 60;
        const durStr = `${mins}:${secs.toString().padStart(2, '0')}`;
        statusText = `📞 ${typeLabel} (${durStr})`;
      } else if (finalStatus === 'declined') {
        statusText = `❌ ${typeLabel} отклонён`;
      } else if (finalStatus === 'busy') {
        statusText = `🚫 ${typeLabel}: абонент занят`;
      } else if (finalStatus === 'missed') {
        statusText = `📞 Неотвеченный ${typeLabel.toLowerCase()}`;
      } else if (finalStatus === 'failed') {
        statusText = `⚠️ ${typeLabel}: ошибка соединения`;
      } else {
        statusText = `📞 ${typeLabel} завершён`;
      }

      const msgId = `msg_call_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const messageData = {
        id: msgId,
        chatId: call.chatId,
        senderId: user.id,
        senderName: user.name,
        senderAvatar: user.avatar,
        text: statusText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        timestamp: Date.now(),
        status: 'sent'
      };

      if (socketRef.current?.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify({
          type: 'message:new',
          payload: {
            message: messageData,
            memberIds: [call.callerId, call.recipientId]
          }
        }));
      }

      try {
        await setDoc(doc(db, 'chats', call.chatId, 'messages', msgId), cleanObject(messageData));
        await setDoc(doc(db, 'chats', call.chatId), cleanObject({
          lastMessage: messageData,
          updatedAt: serverTimestamp()
        }), { merge: true });
      } catch (e) {}
    }
  };

  // Helper to cleanup media
  const cleanupMediaAndPeer = useCallback(() => {
    if (callDocUnsubRef.current) {
      try { callDocUnsubRef.current(); } catch (e) {}
      callDocUnsubRef.current = null;
    }
    stopAllCallSounds();
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(t => t.stop());
      setLocalStream(null);
    }
    setRemoteStream(null);
    if (peerConnectionRef.current) {
      try {
        peerConnectionRef.current.close();
      } catch (e) {}
      peerConnectionRef.current = null;
    }
    iceCandidatesQueue.current = [];
    hasSentAnswer.current = false;
    activeCallRef.current = null;
    setIsMinimized(false);
  }, []);

  // Handle incoming call signal
  const handleIncomingCallSignal = (payload: CallInfo) => {
    if (activeCallRef.current) {
      // Send busy signal if already in a call
      if (socketRef.current?.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify({
          type: 'call:busy',
          payload: { callId: payload.id, targetUserId: payload.callerId }
        }));
      }
      return;
    }

    setIncomingCall(payload);
    playIncomingRingtone();

    // Show native browser notification if page in background
    if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
      try {
        const notif = new Notification(`Входящий ${payload.type === 'video' ? 'видеозвонок' : 'звонок'}`, {
          body: `Звонит ${payload.callerName}`,
          icon: payload.callerAvatar || '/favicon.ico',
          tag: 'incoming-call'
        });
        notif.onclick = () => {
          window.focus();
          notif.close();
        };
      } catch (e) {}
    }
  };

  // Process WebSocket Signaling Events
  const handleSignalingMessage = async (type: string, payload: any) => {
    if (!user) return;

    switch (type) {
      case 'call:initiate':
      case 'call:offer': {
        if (payload.recipientId === user.id) {
          const callData: CallInfo = {
            id: payload.callId || payload.id,
            chatId: payload.chatId || '',
            callerId: payload.callerId,
            callerName: payload.callerName,
            callerAvatar: payload.callerAvatar,
            recipientId: user.id,
            recipientName: user.name,
            recipientAvatar: user.avatar,
            type: payload.callType || payload.type || 'audio',
            state: 'ringing',
            isIncoming: true
          };

          if (payload.sdp) {
            // Save remote offer sdp in active/incoming structure
            (callData as any).remoteSdp = payload.sdp;
          }

          handleIncomingCallSignal(callData);

          // Acknowledge ringing to caller
          if (socketRef.current?.readyState === WebSocket.OPEN) {
            socketRef.current.send(JSON.stringify({
              type: 'call:ringing',
              payload: { callId: callData.id, targetUserId: payload.callerId }
            }));
          }
        }
        break;
      }

      case 'call:ringing': {
        if (activeCallRef.current && activeCallRef.current.id === payload.callId) {
          setActiveCall(prev => prev ? { ...prev, state: 'ringing' } : null);
        }
        break;
      }

      case 'call:answer': {
        const current = activeCallRef.current;
        if (current && (current.id === payload.callId || current.recipientId === payload.callerId)) {
          setActiveCall(prev => prev ? { ...prev, state: 'connecting' } : null);
          const pc = getOrCreatePeerConnection();
          if (payload.sdp && pc.signalingState !== 'stable') {
            await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
            // Drain candidate queue
            while (iceCandidatesQueue.current.length > 0) {
              const candidate = iceCandidatesQueue.current.shift();
              if (candidate) await pc.addIceCandidate(new RTCIceCandidate(candidate));
            }
          }
          setActiveCall(prev => prev ? { ...prev, state: 'connected' } : null);
        }
        break;
      }

      case 'call:ice-candidate': {
        if (payload.candidate) {
          const pc = peerConnectionRef.current;
          if (pc && pc.remoteDescription && pc.remoteDescription.type) {
            try {
              await pc.addIceCandidate(new RTCIceCandidate(payload.candidate));
            } catch (e) {
              console.warn('ICE add error:', e);
            }
          } else {
            iceCandidatesQueue.current.push(payload.candidate);
          }
        }
        break;
      }

      case 'call:media-state': {
        if (activeCallRef.current) {
          setActiveCall(prev => prev ? {
            ...prev,
            isRemoteMuted: payload.isMuted !== undefined ? payload.isMuted : prev.isRemoteMuted,
            isRemoteVideoOff: payload.isVideoOff !== undefined ? payload.isVideoOff : prev.isRemoteVideoOff
          } : null);
        }
        break;
      }

      case 'call:reject':
      case 'call:busy': {
        if (activeCallRef.current && activeCallRef.current.id === payload.callId) {
          const current = activeCallRef.current;
          const statusKey = payload.type === 'call:busy' ? 'busy' : 'declined';
          setActiveCall(prev => prev ? { ...prev, state: statusKey } : null);
          playEndCallTone();
          await recordCallLog(current, 0, statusKey);
          setTimeout(() => {
            setActiveCall(null);
            cleanupMediaAndPeer();
          }, 1500);
        }
        break;
      }

      case 'call:cancel': {
        if (incomingCall && incomingCall.id === payload.callId) {
          stopAllCallSounds();
          playEndCallTone();
          await recordCallLog(incomingCall, 0, 'missed');
          setIncomingCall(null);
          cleanupMediaAndPeer();
        }
        break;
      }

      case 'call:hangup': {
        if (incomingCall && incomingCall.id === payload.callId) {
          stopAllCallSounds();
          playEndCallTone();
          await recordCallLog(incomingCall, 0, 'missed');
          setIncomingCall(null);
          cleanupMediaAndPeer();
        }
        if (activeCallRef.current && activeCallRef.current.id === payload.callId) {
          const current = activeCallRef.current;
          playEndCallTone();
          setActiveCall(prev => prev ? { ...prev, state: 'ended' } : null);
          await recordCallLog(current, callDuration, callDuration > 0 ? 'completed' : 'missed');
          setTimeout(() => {
            setActiveCall(null);
            cleanupMediaAndPeer();
          }, 1000);
        }
        break;
      }
    }
  };

  // Start an Outgoing Call
  const startCall = async (chatId: string, recipient: { id: string; name: string; avatar?: string }, type: CallType) => {
    if (!user) return;
    cleanupMediaAndPeer();

    const callId = `call_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const newCall: CallInfo = {
      id: callId,
      chatId,
      callerId: user.id,
      callerName: user.name,
      callerAvatar: user.avatar || '',
      recipientId: recipient.id,
      recipientName: recipient.name,
      recipientAvatar: recipient.avatar || '',
      type,
      state: 'calling',
      isIncoming: false,
      isMuted: false,
      isVideoOff: type === 'audio',
      facingMode: 'user',
      connectionQuality: 'excellent'
    };

    activeCallRef.current = newCall;
    setActiveCall(newCall);
    setIsMuted(false);
    setIsVideoOff(type === 'audio');
    playOutgoingRing();

    try {
      // 1. Get Local User Media with resilient fallback
      const mediaResult = await getSafeUserMedia({
        type,
        facingMode: 'user',
        userName: user.name
      });
      const stream = mediaResult.stream;
      setLocalStream(stream);

      // If video was requested but real video unavailable, mark video off or synthetic
      if (type === 'video' && !mediaResult.hasRealVideo) {
        setIsVideoOff(true);
      }

      // 2. Setup RTCPeerConnection
      const pc = getOrCreatePeerConnection();
      stream.getTracks().forEach(track => {
        pc.addTrack(track, stream);
      });

      // 3. Create and set Local Offer
      const offer = await pc.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: type === 'video'
      });
      await pc.setLocalDescription(offer);

      // 4. Send via WebSocket
      sendSignal('call:offer', {
        callId,
        chatId,
        callerId: user.id,
        callerName: user.name,
        callerAvatar: user.avatar || '',
        recipientId: recipient.id,
        callType: type,
        sdp: offer
      });

      // 5. Dual signaling sync in Firestore for instant fallback
      try {
        await setDoc(doc(db, 'calls', callId), cleanObject({
          ...newCall,
          sdp: offer,
          createdAt: new Date().toISOString()
        }));

        // Subscribe to call state changes
        const unsub = onSnapshot(doc(db, 'calls', callId), async (docSnap) => {
          if (!docSnap.exists()) return;
          const data = docSnap.data();
          if (data?.state === 'connected' && data?.answerSdp) {
            const currentPc = peerConnectionRef.current;
            if (currentPc && currentPc.signalingState === 'have-local-offer') {
              try {
                await currentPc.setRemoteDescription(new RTCSessionDescription(data.answerSdp));
                while (iceCandidatesQueue.current.length > 0) {
                  const candidate = iceCandidatesQueue.current.shift();
                  if (candidate) await currentPc.addIceCandidate(new RTCIceCandidate(candidate));
                }
                setActiveCall(prev => prev ? { ...prev, state: 'connected' } : null);
              } catch (e) {
                console.warn('Remote description error from Firestore:', e);
              }
            }
          } else if (data?.state === 'declined' || data?.state === 'busy') {
            setActiveCall(prev => prev ? { ...prev, state: data.state } : null);
            playEndCallTone();
            setTimeout(() => {
              setActiveCall(null);
              cleanupMediaAndPeer();
            }, 1200);
          }
        });
        callDocUnsubRef.current = unsub;
      } catch (e) {
        console.warn('Firestore call sync note:', e);
      }

    } catch (err) {
      console.error('Error starting media stream for call:', err);
      playEndCallTone();
      cleanupMediaAndPeer();
      setActiveCall(null);
    }
  };

  // Accept Incoming Call
  const acceptCall = async (withVideo?: boolean) => {
    if (!incomingCall || !user) return;
    stopAllCallSounds();

    const callType: CallType = withVideo !== undefined ? (withVideo ? 'video' : 'audio') : incomingCall.type;
    const callToActivate: CallInfo = {
      ...incomingCall,
      type: callType,
      state: 'connecting',
      isIncoming: true,
      isVideoOff: callType === 'audio',
      isMuted: false
    };

    activeCallRef.current = callToActivate;
    setActiveCall(callToActivate);
    setIncomingCall(null);

    try {
      // 1. Get Local Stream with resilient fallback
      const mediaResult = await getSafeUserMedia({
        type: callType,
        facingMode: 'user',
        userName: user.name
      });
      const stream = mediaResult.stream;
      setLocalStream(stream);

      if (callType === 'video' && !mediaResult.hasRealVideo) {
        setIsVideoOff(true);
      }

      // 2. Setup RTCPeerConnection
      const pc = getOrCreatePeerConnection();
      stream.getTracks().forEach(track => {
        pc.addTrack(track, stream);
      });

      // 3. If remote SDP was provided in incoming payload
      const remoteSdp = (incomingCall as any).remoteSdp || (incomingCall as any).sdp;
      if (remoteSdp) {
        await pc.setRemoteDescription(new RTCSessionDescription(remoteSdp));
      }

      // 4. Create Answer
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      // 5. Send Answer via WebSocket
      sendSignal('call:answer', {
        callId: incomingCall.id,
        callerId: user.id,
        targetUserId: incomingCall.callerId,
        sdp: answer
      });

      // Drain ICE queue
      while (iceCandidatesQueue.current.length > 0) {
        const candidate = iceCandidatesQueue.current.shift();
        if (candidate) await pc.addIceCandidate(new RTCIceCandidate(candidate));
      }

      // 6. Update Firestore state
      try {
        await updateDoc(doc(db, 'calls', incomingCall.id), cleanObject({
          state: 'connected',
          answerSdp: answer
        }));
      } catch (e) {}

    } catch (err) {
      console.error('Error accepting call:', err);
      playEndCallTone();
      declineCall();
    }
  };

  // Decline Incoming Call
  const declineCall = async () => {
    if (!incomingCall) return;
    const current = incomingCall;
    stopAllCallSounds();
    playEndCallTone();

    sendSignal('call:reject', {
      callId: current.id,
      targetUserId: current.callerId
    });

    try {
      await updateDoc(doc(db, 'calls', current.id), { state: 'declined' });
      await deleteDoc(doc(db, 'calls', current.id));
    } catch (e) {}

    await recordCallLog(current, 0, 'declined');
    setIncomingCall(null);
    cleanupMediaAndPeer();
  };

  // End or Cancel Active Call
  const endCall = async () => {
    const current = activeCall;
    if (!current) return;

    playEndCallTone();
    const targetId = current.isIncoming ? current.callerId : current.recipientId;
    const isEarlyCancel = (current.state === 'calling' || current.state === 'ringing') && !current.isIncoming;

    sendSignal(isEarlyCancel ? 'call:cancel' : 'call:hangup', {
      callId: current.id,
      targetUserId: targetId
    });

    try {
      await deleteDoc(doc(db, 'calls', current.id));
    } catch (e) {}

    await recordCallLog(current, callDuration, callDuration > 0 ? 'completed' : 'missed');
    setActiveCall(null);
    cleanupMediaAndPeer();
  };

  // Toggle Microphone
  const toggleMute = () => {
    if (localStream) {
      const nextMute = !isMuted;
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !nextMute;
      });
      setIsMuted(nextMute);
      playToggleTone(nextMute);

      if (activeCall) {
        const targetId = activeCall.isIncoming ? activeCall.callerId : activeCall.recipientId;
        sendSignal('call:media-state', {
          callId: activeCall.id,
          targetUserId: targetId,
          isMuted: nextMute
        });
      }
    }
  };

  // Toggle Camera
  const toggleVideo = async () => {
    if (!localStream) return;
    const nextVideoOff = !isVideoOff;

    if (nextVideoOff) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = false;
      });
      setIsVideoOff(true);
    } else {
      // If we didn't have video track, request video stream with fallback
      if (localStream.getVideoTracks().length === 0) {
        try {
          const mediaResult = await getSafeUserMedia({
            type: 'video',
            facingMode,
            userName: user?.name
          });
          const newVideoTrack = mediaResult.stream.getVideoTracks()[0];
          if (newVideoTrack) {
            localStream.addTrack(newVideoTrack);
            if (peerConnectionRef.current) {
              peerConnectionRef.current.addTrack(newVideoTrack, localStream);
            }
          }
        } catch (e) {
          console.warn('Could not activate camera:', e);
          return;
        }
      } else {
        localStream.getVideoTracks().forEach(track => {
          track.enabled = true;
        });
      }
      setIsVideoOff(false);
    }

    if (activeCall && socketRef.current?.readyState === WebSocket.OPEN) {
      const targetId = activeCall.isIncoming ? activeCall.callerId : activeCall.recipientId;
      socketRef.current.send(JSON.stringify({
        type: 'call:media-state',
        payload: { callId: activeCall.id, targetUserId: targetId, isVideoOff: nextVideoOff }
      }));
    }
  };

  // Switch Front/Back Camera
  const switchCamera = async () => {
    if (!localStream || isVideoOff) return;
    const nextMode = facingMode === 'user' ? 'environment' : 'user';

    try {
      let newStream: MediaStream;
      try {
        newStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: nextMode }
        });
      } catch (err) {
        newStream = await navigator.mediaDevices.getUserMedia({ video: true });
      }
      const newTrack = newStream.getVideoTracks()[0];
      const oldTrack = localStream.getVideoTracks()[0];

      if (oldTrack) {
        oldTrack.stop();
        localStream.removeTrack(oldTrack);
      }
      localStream.addTrack(newTrack);

      if (peerConnectionRef.current) {
        const senders = peerConnectionRef.current.getSenders();
        const videoSender = senders.find(s => s.track && s.track.kind === 'video');
        if (videoSender) {
          videoSender.replaceTrack(newTrack);
        }
      }
      setFacingMode(nextMode);
    } catch (e) {
      console.warn('Switch camera not supported or failed on this device:', e);
    }
  };

  // Toggle Speaker / Output
  const toggleSpeaker = () => {
    setIsSpeakerOn(prev => !prev);
  };

  // Clear Call History
  const clearCallHistory = async () => {
    if (!user) return;
    try {
      await fetch(`/api/calls/history?userId=${encodeURIComponent(user.id)}`, { method: 'DELETE' });
      localStorage.removeItem(`zentora_call_logs_${user.id}`);
      setCallLogs([]);
    } catch (e) {}
  };

  // Redial
  const redialCall = async (log: CallLog) => {
    if (!user) return;
    const isCaller = log.callerId === user.id;
    const target = {
      id: isCaller ? log.recipientId : log.callerId,
      name: isCaller ? log.recipientName : log.callerName,
      avatar: isCaller ? log.recipientAvatar : log.callerAvatar
    };
    await startCall(log.chatId || '', target, log.type);
  };

  return (
    <CallContext.Provider
      value={{
        activeCall,
        incomingCall,
        callLogs,
        localStream,
        remoteStream,
        isMuted,
        isVideoOff,
        isSpeakerOn,
        isMinimized,
        callDuration,
        connectionQuality,
        startCall,
        acceptCall,
        declineCall,
        endCall,
        toggleMute,
        toggleVideo,
        switchCamera,
        toggleSpeaker,
        setMinimized: setIsMinimized,
        clearCallHistory,
        redialCall
      }}
    >
      {children}
    </CallContext.Provider>
  );
};

export const useCall = () => {
  const context = useContext(CallContext);
  if (!context) {
    throw new Error('useCall must be used within a CallProvider');
  }
  return context;
};
