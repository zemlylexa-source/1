import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserSettings, UserSession } from '../types';
import { DEFAULT_SETTINGS, INITIAL_SESSIONS, CURRENT_USER } from '../lib/initialData';
import { auth, db, cleanObject } from '../lib/firebase';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  query, 
  where, 
  onSnapshot, 
  getDocs
} from 'firebase/firestore';

import { DELETED_ACCOUNT_NAME } from '../components/UserAvatar';

interface AuthContextType {
  registeredUsers: User[];
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  settings: UserSettings;
  sessions: UserSession[];
  bannedUserModal: User | null;
  setBannedUserModal: (u: User | null) => void;
  login: (loginInput: string, passwordInput: string) => Promise<{ success: boolean; error?: string; isBanned?: boolean; bannedUser?: User }>;
  register: (name: string, username: string, email: string, passwordInput: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updated: Partial<User>) => Promise<void>;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  terminateSession: (sessionId: string) => void;
  terminateAllOtherSessions: () => void;
  setUserModeratorStatus: (targetUserId: string, isModerator: boolean) => Promise<void>;
  banUser: (targetUserId: string, duration: { seconds?: number; minutes?: number; isPermanent?: boolean }, reason?: string) => Promise<void>;
  unbanUser: (targetUserId: string) => Promise<void>;
  recordSpamViolation: (userId: string) => Promise<{ isBanned: boolean; newCount: number; banSeconds?: number }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const sanitizeUser = (u: User): User => {
  const isRen = u.username?.toLowerCase() === 'den' || u.id === 'usr_admin_den' || u.email?.toLowerCase() === 'den@zentora.io';
  return {
    ...u,
    isAdmin: isRen ? true : false,
    isModerator: isRen ? true : !!u.isModerator,
  };
};


const hashPassword = async (password: string) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      if (sessionStorage.getItem('zentora_logged_out') === 'true') {
        return null;
      }
      const saved = sessionStorage.getItem('zentora_guest_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.id === 'usr_admin_rafa' || parsed.username === 'rafa') {
          sessionStorage.removeItem('zentora_guest_user');
          return null;
        }
        return sanitizeUser(parsed);
      }
    } catch {
      // fallback
    }
    return null;
  });
  const [isLoading, setIsLoading] = useState(true);
  const [registeredUsers, setRegisteredUsers] = useState<User[]>([CURRENT_USER]);
  const [sessions, setSessions] = useState<UserSession[]>(INITIAL_SESSIONS);
  const [bannedUserModal, setBannedUserModal] = useState<User | null>(null);
  const [settings, setSettings] = useState<UserSettings>(() => {
    try {
      const saved = sessionStorage.getItem('zentora_settings');
      return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Check if a user's temporary ban has expired
  const isBanExpired = (targetUser: User): boolean => {
    if (!targetUser.isBanned && !targetUser.isDeleted) return false;
    if (!targetUser.banExpiresAt || targetUser.banExpiresAt === 'permanent') return false;
    try {
      return new Date(targetUser.banExpiresAt).getTime() <= Date.now();
    } catch {
      return false;
    }
  };

  // Periodic ban expiration check and force kick for currently logged in user
  useEffect(() => {
    const checkActiveUserBan = async () => {
      if (!user) return;

      // Find freshest data for current user
      const freshUser = registeredUsers.find(u => u.id === user.id) || user;

      if (freshUser.isBanned || freshUser.isDeleted) {
        if (isBanExpired(freshUser)) {
          // Auto unban!
          await unbanUser(freshUser.id);
        } else {
          // Force kick / logout
          setBannedUserModal(freshUser);
          sessionStorage.removeItem('zentora_guest_user');
          sessionStorage.setItem('zentora_logged_out', 'true');
          setUser(null);
          try {
            await signOut(auth);
          } catch {}
        }
      }
    };

    checkActiveUserBan();
    const interval = setInterval(checkActiveUserBan, 1500);
    return () => clearInterval(interval);
  }, [user, registeredUsers]);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      setIsLoading(true);
      if (firebaseUser) {
        // Listen to user profile changes
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        const unsubProfile = onSnapshot(userDocRef, (docSnap) => {
          if (docSnap.exists()) {
            const uData = docSnap.data() as User;
            setUser(sanitizeUser(uData));
          } else {
            const firebaseAccount: User = {
              id: firebaseUser.uid,
              name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
              username: (firebaseUser.email?.split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9_]/g, ''),
              email: firebaseUser.email || `${firebaseUser.uid}@zentora.io`,
              avatar: firebaseUser.photoURL || `https://api.dicebear.com/7.x/identicon/svg?seed=${firebaseUser.uid}`,
              bio: '',
              phone: '',
              status: 'online',
              isAdmin: false,
              isModerator: false,
              is2FAEnabled: false,
              createdAt: new Date().toISOString()
            };
            setUser(firebaseAccount);
            setDoc(doc(db, 'users', firebaseUser.uid), cleanObject(firebaseAccount)).catch(() => {});
          }
          setIsLoading(false);
        }, (err) => {
          console.warn("User profile sync fallback:", err);
          setIsLoading(false);
        });
        return () => unsubProfile();
      } else {
        // Check if explicitly logged out or has saved session
        if (sessionStorage.getItem('zentora_logged_out') === 'true') {
          setUser(null);
        } else {
          const savedGuest = sessionStorage.getItem('zentora_guest_user');
          if (savedGuest) {
            try {
              const parsed = JSON.parse(savedGuest);
              if (parsed.id === 'usr_admin_rafa' || parsed.username === 'rafa') {
                sessionStorage.removeItem('zentora_guest_user');
                setUser(null);
              } else {
                setUser(sanitizeUser(parsed));
              }
            } catch {
              setUser(null);
            }
          } else {
            // New user / visitor opening app starts with Auth/Registration modal
            setUser(null);
          }
        }
        setIsLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Listen to all users (for discovery/admin)
  useEffect(() => {
    if (!user) return;
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const usersMap = new Map<string, User>();

      // 1. Default Admin Ren
      usersMap.set(CURRENT_USER.id, CURRENT_USER);

      // 2. Local storage accounts (filtered from old legacy accounts)
      try {
        const savedLocal = sessionStorage.getItem('zentora_all_users');
        if (savedLocal) {
          const parsed: User[] = JSON.parse(savedLocal);
          parsed
            .filter(u => u.id !== 'usr_admin_rafa' && u.username?.toLowerCase() !== 'rafa')
            .forEach(u => usersMap.set(u.id, u));
        }
      } catch (e) {
        console.warn("Local users parse error:", e);
      }

      // 3. Firestore snapshot users
      snapshot.forEach(docSnap => {
        const u = docSnap.data() as User;
        if (u && u.id && u.id !== 'usr_admin_rafa' && u.username?.toLowerCase() !== 'rafa') {
          usersMap.set(u.id, u);
        }
      });

      const sanitizedList = Array.from(usersMap.values()).map(sanitizeUser);
      setRegisteredUsers(sanitizedList);
    }, (err) => {
      console.warn("Registered users snapshot sync error:", err);
      // Fallback to local storage users
      const usersMap = new Map<string, User>();
      usersMap.set(CURRENT_USER.id, CURRENT_USER);
      try {
        const savedLocal = sessionStorage.getItem('zentora_all_users');
        if (savedLocal) {
          const parsed: User[] = JSON.parse(savedLocal);
          parsed
            .filter(u => u.id !== 'usr_admin_rafa' && u.username?.toLowerCase() !== 'rafa')
            .forEach(u => usersMap.set(u.id, u));
        }
      } catch (e) {}
      const sanitizedList = Array.from(usersMap.values()).map(sanitizeUser);
      setRegisteredUsers(sanitizedList);
    });
    return () => unsubUsers();
  }, [user]);

  useEffect(() => {
    sessionStorage.setItem('zentora_settings', JSON.stringify(settings));
    const root = document.documentElement;
    root.setAttribute('data-theme', settings.theme);
    if (['dark', 'black', 'cyber'].includes(settings.theme)) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings]);

  const saveUserLocally = (newUser: User) => {
    try {
      const savedLocal = sessionStorage.getItem('zentora_all_users');
      let list: User[] = savedLocal ? JSON.parse(savedLocal) : [CURRENT_USER];
      list = list.filter(u => u.id !== 'usr_admin_rafa' && u.username?.toLowerCase() !== 'rafa');
      list = list.filter(u => u.id !== newUser.id && u.username?.toLowerCase() !== newUser.username?.toLowerCase());
      list.push(newUser);
      sessionStorage.setItem('zentora_all_users', JSON.stringify(list));
      setRegisteredUsers(prev => {
        const map = new Map<string, User>();
        prev.forEach(u => map.set(u.id, u));
        map.set(newUser.id, newUser);
        return Array.from(map.values());
      });
    } catch (e) {
      console.warn("Error saving user locally:", e);
    }
  };

  const unbanUser = async (targetUserId: string) => {
    let target = registeredUsers.find(u => u.id === targetUserId);
    if (!target) {
      try {
        const snap = await getDoc(doc(db, 'users', targetUserId));
        if (snap.exists()) {
          target = snap.data() as User;
        }
      } catch {}
    }

    const restoredName = target?.originalName || target?.username || 'Пользователь';
    const restoredBio = target?.originalBio || '';
    const restoredAvatar = target?.originalAvatar || (target?.username ? `https://api.dicebear.com/7.x/identicon/svg?seed=${target.username}` : '');

    const restoredPayload: Partial<User> = {
      isBanned: false,
      isDeleted: false,
      status: 'offline',
      name: restoredName,
      bio: restoredBio,
      avatar: restoredAvatar,
      banExpiresAt: null,
      banReason: '',
      deleteReason: '',
      spamViolationsCount: 0
    };

    // Update locally
    setRegisteredUsers(prev => {
      const updated = prev.map(u => u.id === targetUserId ? { ...u, ...restoredPayload } : u);
      try {
        sessionStorage.setItem('zentora_all_users', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    if (bannedUserModal?.id === targetUserId) {
      setBannedUserModal(null);
    }

    // Update Firestore
    try {
      await setDoc(doc(db, 'users', targetUserId), cleanObject(restoredPayload), { merge: true });
    } catch (e) {
      console.warn("Firestore unban sync error:", e);
    }
  };

  const banUser = async (
    targetUserId: string,
    duration: { seconds?: number; minutes?: number; isPermanent?: boolean },
    reason: string = 'Нарушение правил сообщества Zentora (Спам сообщений)'
  ) => {
    let target = registeredUsers.find(u => u.id === targetUserId);
    if (!target) {
      try {
        const snap = await getDoc(doc(db, 'users', targetUserId));
        if (snap.exists()) {
          target = snap.data() as User;
        }
      } catch {}
    }

    if (!target) return;
    if (target.username?.toLowerCase() === 'ren' || target.id === 'usr_admin_den' || target.isAdmin) {
      alert('Нельзя заблокировать администратора!');
      return;
    }

    let banExpiresAt: string | null = 'permanent';
    if (!duration.isPermanent) {
      if (duration.seconds) {
        banExpiresAt = new Date(Date.now() + duration.seconds * 1000).toISOString();
      } else if (duration.minutes) {
        banExpiresAt = new Date(Date.now() + duration.minutes * 60000).toISOString();
      }
    }

    const origName = target.originalName || target.name || target.username;
    const origBio = target.originalBio || target.bio || '';
    const origAvatar = target.originalAvatar || target.avatar || '';
    const finalBio = `Данный аккаунт был удален за иную причину администрацией Zentora.\nПричина: ${reason}`;

    const bannedPayload: Partial<User> = {
      isBanned: true,
      isDeleted: true,
      status: 'deleted',
      name: DELETED_ACCOUNT_NAME,
      bio: finalBio,
      avatar: '',
      banReason: reason,
      deleteReason: reason,
      banExpiresAt: banExpiresAt,
      originalName: origName,
      originalBio: origBio,
      originalAvatar: origAvatar
    };

    const updatedUserObj: User = { ...target, ...bannedPayload } as User;

    // Update registered users list
    setRegisteredUsers(prev => {
      const updated = prev.map(u => u.id === targetUserId ? updatedUserObj : u);
      try {
        sessionStorage.setItem('zentora_all_users', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // If currently logged in user is the target, force kick/logout immediately!
    if (user?.id === targetUserId) {
      setBannedUserModal(updatedUserObj);
      sessionStorage.removeItem('zentora_guest_user');
      sessionStorage.setItem('zentora_logged_out', 'true');
      setUser(null);
      try {
        await signOut(auth);
      } catch {}
    }

    // Update Firestore
    try {
      await setDoc(doc(db, 'users', targetUserId), cleanObject(bannedPayload), { merge: true });
    } catch (e) {
      console.warn("Firestore ban sync error:", e);
    }
  };

  const recordSpamViolation = async (userId: string): Promise<{ isBanned: boolean; newCount: number; banSeconds?: number }> => {
    const target = registeredUsers.find(u => u.id === userId) || user;
    if (!target) return { isBanned: false, newCount: 1 };

    const currentCount = (target.spamViolationsCount || 0) + 1;

    // Update violations count
    setRegisteredUsers(prev => {
      const updated = prev.map(u => u.id === userId ? { ...u, spamViolationsCount: currentCount } : u);
      try {
        sessionStorage.setItem('zentora_all_users', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    try {
      await setDoc(doc(db, 'users', userId), { spamViolationsCount: currentCount }, { merge: true });
    } catch {}

    // If reached 3 violations -> Ban account for 1 minute (60s) for spam!
    if (currentCount >= 3) {
      const banSeconds = 60;
      await banUser(
        userId,
        { seconds: banSeconds },
        'Обнаружен спам: многократная отправка длинных сообщений (>5 слов)'
      );
      return { isBanned: true, newCount: currentCount, banSeconds };
    }

    return { isBanned: false, newCount: currentCount };
  };

    const login = async (emailInput: string, passwordInput: string) => {
    sessionStorage.removeItem('zentora_logged_out');
    const trimmedInput = emailInput.trim().toLowerCase();
    const cleanUsername = trimmedInput.replace(/^@/, '');
    
    const pwdHash = await hashPassword(passwordInput);

    // Check for admin account Ren securely
    if (cleanUsername === 'den' || trimmedInput === 'den@zentora.io') {
      if (pwdHash === '84cd2989dc91d13ea10da515e884c6d59acafe997d62c04c78a258975d064832') {
        const renAdmin: User = { ...CURRENT_USER, isAdmin: true, isModerator: true };
        setUser(renAdmin);
        sessionStorage.setItem('zentora_guest_user', JSON.stringify(renAdmin));
        saveUserLocally(renAdmin);
        try {
          await setDoc(doc(db, 'users', renAdmin.id), cleanObject(renAdmin), { merge: true });
        } catch (e) {}
        return { success: true };
      } else {
        return { success: false, error: 'Неверный пароль.' };
      }
    }

    // First check locally registered users
    const localMatch = registeredUsers.find(u => 
      u.email?.toLowerCase() === trimmedInput || 
      u.username?.toLowerCase() === cleanUsername
    );

    if (localMatch) {
      if ((localMatch as any)._pwdHash && (localMatch as any)._pwdHash !== pwdHash) {
        return { success: false, error: 'Неверный пароль.' };
      } else if (!(localMatch as any)._pwdHash) {
        return { success: false, error: 'В целях безопасности требуется повторная регистрация.' };
      }

      // Check if account is banned
      // Check if account is banned
      if (localMatch.isBanned || localMatch.isDeleted) {
        if (isBanExpired(localMatch)) {
          // Ban has expired! Automatically restore account and allow login!
          await unbanUser(localMatch.id);
          const unbanned = { ...localMatch, isBanned: false, isDeleted: false, status: 'online' as const };
          setUser(unbanned);
          sessionStorage.setItem('zentora_guest_user', JSON.stringify(unbanned));
          return { success: true };
        } else {
          setBannedUserModal(localMatch);
          return { 
            success: false, 
            isBanned: true, 
            bannedUser: localMatch, 
            error: `Аккаунт заблокирован. Причина: ${localMatch.banReason || localMatch.deleteReason || 'Нарушение правил'}` 
          };
        }
      }

      setUser(localMatch);
      sessionStorage.setItem('zentora_guest_user', JSON.stringify(localMatch));
      return { success: true };
    }

    try {
      let emailToUse = emailInput.trim();
      if (!emailToUse.includes('@')) {
        const usersRef = collection(db, 'users');
        const q = query(usersRef, where('username', '==', cleanUsername));
        const querySnapshot = await getDocs(q);
        
        if (!querySnapshot.empty) {
          const userData = querySnapshot.docs[0].data() as User;
          if (userData) {
            // Check if banned
            if (userData.isBanned || userData.isDeleted) {
              if (isBanExpired(userData)) {
                await unbanUser(userData.id);
              } else {
                setBannedUserModal(userData);
                return { 
                  success: false, 
                  isBanned: true, 
                  bannedUser: userData, 
                  error: `Аккаунт заблокирован: ${userData.banReason || 'Нарушение правил'}` 
                };
              }
            }
            if (userData.email) emailToUse = userData.email;
          }
        } else {
          emailToUse = `${cleanUsername}@zentora.io`;
        }
      }

      await signInWithEmailAndPassword(auth, emailToUse, passwordInput);
      return { success: true };
    } catch (err: any) {
      let errorMessage = err.message || 'Ошибка входа.';
      if (err.code === 'auth/invalid-email') {
        errorMessage = 'Неверный формат Email или имя пользователя.';
      } else if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        errorMessage = 'Пользователь не найден или пароль неверный.';
      }
      return { success: false, error: errorMessage };
    }
  };

  const register = async (name: string, username: string, email: string, passwordInput: string) => {
    sessionStorage.removeItem('zentora_logged_out');
    const cleanUsername = username.toLowerCase().trim().replace(/[^a-z0-9_]/g, '') || 'user_' + Math.floor(Math.random()*1000);
    const formattedEmail = email.trim().includes('@') ? email.trim() : `${email.trim()}@zentora.io`;

    // Check existing
    const existing = registeredUsers.find(u => 
      u.username?.toLowerCase() === cleanUsername || 
      u.email?.toLowerCase() === formattedEmail
    );

    if (existing) {
      return { success: false, error: 'Пользователь с таким именем или email уже зарегистрирован. Пожалуйста, выполните вход.' };
    }

    const newUid = 'usr_' + Date.now();
    const pwdHash = await hashPassword(passwordInput);
    const newUser: any = {
      id: newUid,
      _pwdHash: pwdHash,
      name: name.trim(),
      username: cleanUsername,
      email: formattedEmail,
      avatar: `https://api.dicebear.com/7.x/identicon/svg?seed=${cleanUsername}`,
      bio: '',
      phone: '',
      status: 'online',
      isAdmin: false,
      isModerator: false,
      is2FAEnabled: false,
      createdAt: new Date().toISOString()
    };

    try {
      const { user: firebaseUser } = await createUserWithEmailAndPassword(auth, formattedEmail, passwordInput);
      newUser.id = firebaseUser.uid;
    } catch (err: any) {
      console.warn("Firebase auth creation note (using direct local account):", err?.message);
    }

    // Always save user in Firestore and locally
    saveUserLocally(newUser);
    setUser(newUser);
    sessionStorage.setItem('zentora_guest_user', JSON.stringify(newUser));

    try {
      await setDoc(doc(db, 'users', newUser.id), cleanObject(newUser));
    } catch (e) {
      console.warn("Firestore user sync warning:", e);
    }

    return { success: true };
  };

  const logout = async () => {
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.id), cleanObject({ status: 'offline', lastSeen: new Date().toISOString() }), { merge: true });
      } catch (e) {
        console.warn("Could not update status on logout:", e);
      }
    }
    sessionStorage.setItem('zentora_logged_out', 'true');
    sessionStorage.removeItem('zentora_guest_user');
    setUser(null);
    try {
      await signOut(auth);
    } catch (e) {
      console.warn("SignOut error:", e);
    }
  };

  const updateProfile = async (updated: Partial<User>) => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'users', user.id), cleanObject(updated), { merge: true });
      if (user.id.startsWith('usr_')) {
        const newUser = { ...user, ...updated };
        setUser(newUser);
        sessionStorage.setItem('zentora_guest_user', JSON.stringify(newUser));
      }
    } catch (err) {
      console.error("Profile update failed:", err);
      throw err;
    }
  };

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const terminateSession = (sessionId: string) => {
    setSessions(prev => prev.filter(s => s.id !== sessionId));
  };

  const terminateAllOtherSessions = () => {
    setSessions(prev => prev.filter(s => s.isCurrent));
  };

  const setUserModeratorStatus = async (targetUserId: string, isModerator: boolean) => {
    if (user?.username?.toLowerCase() !== 'ren' && user?.id !== 'usr_admin_den') return;

    setRegisteredUsers(prev => {
      const updated = prev.map(u => {
        if (u.id === targetUserId) {
          return { ...u, isModerator };
        }
        return u;
      });
      try {
        sessionStorage.setItem('zentora_all_users', JSON.stringify(updated));
      } catch (e) {
        console.warn("Could not store updated users in sessionStorage:", e);
      }
      return updated;
    });

    try {
      await setDoc(doc(db, 'users', targetUserId), cleanObject({ isModerator }), { merge: true });
    } catch (e) {
      console.warn("Firestore setDoc moderator warning:", e);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        registeredUsers,
        user,
        isAuthenticated: !!user,
        isLoading,
        settings,
        sessions,
        bannedUserModal,
        setBannedUserModal,
        login,
        register,
        logout,
        updateProfile,
        updateSettings,
        terminateSession,
        terminateAllOtherSessions,
        setUserModeratorStatus,
        banUser,
        unbanUser,
        recordSpamViolation
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
