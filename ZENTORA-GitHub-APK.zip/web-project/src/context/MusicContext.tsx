import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { MusicTrack, User } from '../types';
import { useAuth } from './AuthContext';

export const INITIAL_TRACKS: MusicTrack[] = [
  {
    id: 'tr_1',
    title: 'Midnight Synthwave Drive',
    artist: 'Zentora Waves',
    url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=synthwave-80s-110045.mp3',
    cover: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&auto=format&fit=crop&q=80',
    duration: 180
  },
  {
    id: 'tr_2',
    title: 'Lo-Fi Chill Hop Study',
    artist: 'VK Vibes & Chill',
    url: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a731ef.mp3?filename=lofi-study-112191.mp3',
    cover: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80',
    duration: 154
  },
  {
    id: 'tr_3',
    title: 'Cyberpunk Neon Phonk',
    artist: 'Telegram Beats 2099',
    url: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=cyberpunk-2099-10701.mp3',
    cover: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=300&auto=format&fit=crop&q=80',
    duration: 142
  },
  {
    id: 'tr_4',
    title: 'Acoustic Sunset Romance',
    artist: 'Exotic Sound',
    url: 'https://cdn.pixabay.com/download/audio/2021/09/06/audio_8fa38c823f.mp3?filename=acoustic-guitar-loop-11308.mp3',
    cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80',
    duration: 128
  },
  {
    id: 'tr_5',
    title: 'Night City Atmosphere',
    artist: 'Zentora Cyber',
    url: 'https://cdn.pixabay.com/download/audio/2022/10/14/audio_9939f77399.mp3?filename=ambient-piano-amp-strings-10711.mp3',
    cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80',
    duration: 165
  },
  {
    id: 'tr_6',
    title: 'Deep Electronic Pulse',
    artist: 'Electro Beats',
    url: 'https://cdn.pixabay.com/download/audio/2021/08/04/audio_bb630cc098.mp3?filename=electronic-future-beats-117997.mp3',
    cover: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&auto=format&fit=crop&q=80',
    duration: 140
  }
];

interface MusicContextType {
  playlist: MusicTrack[];
  currentTrack: MusicTrack | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isLooping: boolean;
  isMiniPlayerOpen: boolean;
  isFullPlayerOpen: boolean;
  setIsFullPlayerOpen: (open: boolean) => void;
  setIsMiniPlayerOpen: (open: boolean) => void;
  playTrack: (track: MusicTrack) => void;
  pauseTrack: () => void;
  stopMusic: () => void;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  seek: (seconds: number) => void;
  setVolume: (vol: number) => void;
  toggleMute: () => void;
  toggleLoop: () => void;
  downloadTrack: (track: MusicTrack) => Promise<void>;
  setTrackToProfile: (track: MusicTrack) => Promise<void>;
  removeTrackFromProfile: () => Promise<void>;
  uploadCustomTrack: (file: File) => Promise<MusicTrack>;
}

const MusicContext = createContext<MusicContextType | null>(null);

export const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, updateProfile } = useAuth();
  const [playlist, setPlaylist] = useState<MusicTrack[]>(() => {
    try {
      const saved = sessionStorage.getItem('zentora_music_playlist');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return INITIAL_TRACKS;
  });

  const [currentTrack, setCurrentTrack] = useState<MusicTrack | null>(playlist[0] || null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolumeState] = useState<number>(0.8);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(false);
  const [isMiniPlayerOpen, setIsMiniPlayerOpen] = useState<boolean>(false);
  const [isFullPlayerOpen, setIsFullPlayerOpen] = useState<boolean>(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize single audio element
  useEffect(() => {
    const audio = new Audio();
    audioRef.current = audio;
    audio.preload = 'metadata';
    audio.volume = isMuted ? 0 : volume;

    audio.ontimeupdate = () => {
      setCurrentTime(audio.currentTime);
    };

    audio.onloadedmetadata = () => {
      setDuration(audio.duration || currentTrack?.duration || 0);
    };

    audio.onended = () => {
      if (isLooping) {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      } else {
        nextTrack();
      }
    };

    return () => {
      audio.pause();
      audio.src = '';
      audioRef.current = null;
    };
  }, []);

  // Sync volume & mute
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // Sync looping
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.loop = isLooping;
    }
  }, [isLooping]);

  // Save playlist
  useEffect(() => {
    try {
      sessionStorage.setItem('zentora_music_playlist', JSON.stringify(playlist));
    } catch (e) {}
  }, [playlist]);

  const playTrack = (track: MusicTrack) => {
    if (!audioRef.current) return;
    
    // If same track, just resume
    if (currentTrack?.id === track.id && audioRef.current.src.includes(encodeURI(track.url)) || currentTrack?.url === track.url) {
      audioRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(e => console.warn("Audio play blocked:", e));
      setIsMiniPlayerOpen(true);
      return;
    }

    setCurrentTrack(track);
    setCurrentTime(0);
    setDuration(track.duration || 0);
    audioRef.current.src = track.url;
    audioRef.current.load();
    audioRef.current.play()
      .then(() => {
        setIsPlaying(true);
        setIsMiniPlayerOpen(true);
      })
      .catch(e => console.warn("Audio play error:", e));
  };

  const pauseTrack = () => {
    if (!audioRef.current) return;
    audioRef.current.pause();
    setIsPlaying(false);
  };

  const stopMusic = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsPlaying(false);
    setCurrentTime(0);
    setIsMiniPlayerOpen(false);
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      pauseTrack();
    } else {
      if (currentTrack) {
        if (!audioRef.current.src) {
          audioRef.current.src = currentTrack.url;
        }
        audioRef.current.play()
          .then(() => {
            setIsPlaying(true);
            setIsMiniPlayerOpen(true);
          })
          .catch(e => console.warn("Audio play error:", e));
      } else if (playlist.length > 0) {
        playTrack(playlist[0]);
      }
    }
  };

  const nextTrack = () => {
    if (playlist.length === 0) return;
    const currentIndex = currentTrack ? playlist.findIndex(t => t.id === currentTrack.id) : 0;
    const nextIndex = (currentIndex + 1) % playlist.length;
    playTrack(playlist[nextIndex]);
  };

  const prevTrack = () => {
    if (playlist.length === 0) return;
    const currentIndex = currentTrack ? playlist.findIndex(t => t.id === currentTrack.id) : 0;
    const prevIndex = (currentIndex - 1 + playlist.length) % playlist.length;
    playTrack(playlist[prevIndex]);
  };

  const seek = (seconds: number) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = seconds;
    setCurrentTime(seconds);
  };

  const setVolume = (vol: number) => {
    const clamped = Math.max(0, Math.min(1, vol));
    setVolumeState(clamped);
    if (isMuted && clamped > 0) setIsMuted(false);
  };

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  const toggleLoop = () => {
    setIsLooping(prev => !prev);
  };

  // Download track (MP3)
  const downloadTrack = async (track: MusicTrack) => {
    try {
      const response = await fetch(track.url);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      const safeFilename = `${track.artist} - ${track.title}`.replace(/[/\\?%*:|"<>]/g, '_') + '.mp3';
      link.download = safeFilename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (e) {
      // Fallback: direct anchor download
      const link = document.createElement('a');
      link.href = track.url;
      link.target = '_blank';
      link.download = `${track.artist} - ${track.title}.mp3`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  // Pin track to user profile
  const setTrackToProfile = async (track: MusicTrack) => {
    if (!user) return;
    try {
      await updateProfile({
        profileTrack: track
      });
    } catch (err) {
      console.error("Failed to pin track to profile:", err);
      throw err;
    }
  };

  // Remove track from user profile
  const removeTrackFromProfile = async () => {
    if (!user) return;
    try {
      await updateProfile({
        profileTrack: undefined
      });
    } catch (err) {
      console.error("Failed to remove track from profile:", err);
      throw err;
    }
  };

  // Upload custom MP3 from user device
  const uploadCustomTrack = async (file: File): Promise<MusicTrack> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        const rawName = file.name.replace(/\.[^/.]+$/, "");
        const parts = rawName.split('-');
        const artist = parts.length > 1 ? parts[0].trim() : (user?.name || 'Мой трек');
        const title = parts.length > 1 ? parts.slice(1).join('-').trim() : rawName;

        const newTrack: MusicTrack = {
          id: `custom_tr_${Date.now()}`,
          title: title || 'Аудиозапись',
          artist: artist || 'Пользователь',
          url: result,
          cover: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
          duration: 180,
          isCustom: true,
          addedBy: user?.id
        };

        setPlaylist(prev => [newTrack, ...prev]);
        resolve(newTrack);
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  };

  return (
    <MusicContext.Provider
      value={{
        playlist,
        currentTrack,
        isPlaying,
        currentTime,
        duration,
        volume,
        isMuted,
        isLooping,
        isMiniPlayerOpen,
        isFullPlayerOpen,
        setIsFullPlayerOpen,
        setIsMiniPlayerOpen,
        playTrack,
        pauseTrack,
        stopMusic,
        togglePlay,
        nextTrack,
        prevTrack,
        seek,
        setVolume,
        toggleMute,
        toggleLoop,
        downloadTrack,
        setTrackToProfile,
        removeTrackFromProfile,
        uploadCustomTrack
      }}
    >
      {children}
    </MusicContext.Provider>
  );
};

export const useMusic = () => {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error('useMusic must be used within a MusicProvider');
  }
  return context;
};
