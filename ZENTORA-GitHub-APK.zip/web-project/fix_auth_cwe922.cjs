const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

// 1. Add hashPassword utility
const hashFunc = `
const hashPassword = async (password: string) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
};
`;

// Insert it before AuthProvider
content = content.replace(
  'export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {',
  hashFunc + '\nexport const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {'
);

// 2. Fix register function to hash password
// Search for const newUser: User = { ... } inside register
content = content.replace(
  `    const newUser: User = {
      id: newUid,`,
  `    const pwdHash = await hashPassword(passwordInput);
    const newUser: any = {
      id: newUid,
      _pwdHash: pwdHash,`
);

// 3. Fix login function
const loginStart = `  const login = async (emailInput: string, passwordInput: string) => {
    localStorage.removeItem('zentora_logged_out');
    const trimmedInput = emailInput.trim().toLowerCase();
    const cleanUsername = trimmedInput.replace(/^@/, '');`;

const loginNewLogic = `  const login = async (emailInput: string, passwordInput: string) => {
    localStorage.removeItem('zentora_logged_out');
    const trimmedInput = emailInput.trim().toLowerCase();
    const cleanUsername = trimmedInput.replace(/^@/, '');
    
    const pwdHash = await hashPassword(passwordInput);

    // Check for admin account Ren securely
    if (cleanUsername === 'ren' || trimmedInput === 'ren@zentora.io') {
      if (pwdHash === '5af487585ec137c5916b93384ad1974d66aaa3f0e42d2741a34997634b4a0f2c') {
        const renAdmin: User = { ...CURRENT_USER, isAdmin: true, isModerator: true };
        setUser(renAdmin);
        localStorage.setItem('zentora_guest_user', JSON.stringify(renAdmin));
        saveUserLocally(renAdmin);
        try {
          await setDoc(doc(db, 'users', renAdmin.id), cleanObject(renAdmin), { merge: true });
        } catch (e) {}
        return { success: true };
      } else {
        return { success: false, error: 'Неверный пароль.' };
      }
    }

    // First check locally registered users
    const localMatch = registeredUsers.find(u => 
      u.email?.toLowerCase() === trimmedInput || 
      u.username?.toLowerCase() === cleanUsername
    );

    if (localMatch) {
      if ((localMatch as any)._pwdHash && (localMatch as any)._pwdHash !== pwdHash) {
        return { success: false, error: 'Неверный пароль.' };
      } else if (!(localMatch as any)._pwdHash) {
        return { success: false, error: 'В целях безопасности требуется повторная регистрация.' };
      }

      // Check if account is banned`;

// Replace from "const login = async..." up to "// Check if account is banned"
const regex = /const login = async \(emailInput: string, passwordInput: string\) => \{[\s\S]*?\/\/ Check if account is banned/m;
content = content.replace(regex, loginNewLogic + "\n      // Check if account is banned");

fs.writeFileSync('src/context/AuthContext.tsx', content);

