const fs = require('fs');
let code = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');

code = code.replace(/createChat: \(type: ChatType, name\?: string, memberIds\?: string\[\], description\?: string\) => void;/, 
  'createChat: (type: ChatType, name?: string, memberIds?: string[], description?: string, avatar?: string) => void;');

code = code.replace(/const createChat = \(type: ChatType, name\?: string, memberIds\?: string\[\], description\?: string\) => \{/, 
  'const createChat = (type: ChatType, name?: string, memberIds?: string[], description?: string, avatar?: string) => {');

code = code.replace(/let chatAvatar = `https:\/\/api\.dicebear\.com\/7\.x\/identicon\/svg\?seed=\$\{newChatId\}`;[\s\S]*?if \(targetUser\) \{[\s\S]*?\}[\s\S]*?\}/, 
  `let chatAvatar = avatar || \`https://api.dicebear.com/7.x/identicon/svg?seed=\${newChatId}\`;`);

fs.writeFileSync('src/context/ChatContext.tsx', code);
