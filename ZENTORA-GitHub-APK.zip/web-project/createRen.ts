import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { getFirestore, doc, setDoc } from 'firebase/firestore';
import fs from 'fs';

const configStr = fs.readFileSync('firebase-applet-config.json', 'utf8');
const config = JSON.parse(configStr);

const app = initializeApp(config);
const auth = getAuth(app);
const db = getFirestore(app);

async function createAdmin() {
  try {
    const cred = await createUserWithEmailAndPassword(auth, 'ren@zentora.io', 'admin123455');
    console.log("Created Ren in Firebase Auth with UID:", cred.user.uid);
    
    await updateProfile(cred.user, { displayName: 'Ren' });

    await setDoc(doc(db, 'users', 'usr_admin_ren'), {
      id: 'usr_admin_ren',
      authUid: cred.user.uid,
      name: 'Ren',
      username: 'ren',
      email: 'ren@zentora.io',
      avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=ren',
      bio: 'Главный Администратор Zentora ⚡',
      status: 'online',
      isAdmin: true,
      isModerator: true,
      is2FAEnabled: false,
      createdAt: '2026-01-01T00:00:00.000Z'
    });
    
    console.log("Saved Ren to Firestore.");
    process.exit(0);
  } catch (e) {
    console.error("Error creating Ren:", e);
    process.exit(1);
  }
}
createAdmin();
