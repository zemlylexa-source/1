const fs = require('fs');

let viteConfig = fs.readFileSync('vite.config.ts', 'utf8');

// Replace the server configuration to strictly disable HMR and watching
viteConfig = viteConfig.replace(
  /server: \{[\s\S]*?\},/,
  `server: {\n      hmr: false,\n      watch: null,\n    },`
);

fs.writeFileSync('vite.config.ts', viteConfig);
