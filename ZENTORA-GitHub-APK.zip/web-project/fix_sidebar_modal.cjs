const fs = require('fs');
let sidebarTsx = fs.readFileSync('src/components/social/SocialSidebar.tsx', 'utf8');

if (!sidebarTsx.includes('onOpenPremium')) {
  sidebarTsx = sidebarTsx.replace(
    "interface SocialSidebarProps {",
    "interface SocialSidebarProps {\n  onOpenPremium?: () => void;"
  );
  sidebarTsx = sidebarTsx.replace(
    "export const SocialSidebar: React.FC<SocialSidebarProps> = ({ activeTab, onTabChange }) => {",
    "export const SocialSidebar: React.FC<SocialSidebarProps> = ({ activeTab, onTabChange, onOpenPremium }) => {"
  );
  sidebarTsx = sidebarTsx.replace(
    '<button className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-amber-500 hover:bg-amber-500/10 rounded-2xl transition-all">',
    '<button onClick={onOpenPremium} className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-amber-500 hover:bg-amber-500/10 rounded-2xl transition-all">'
  );
  fs.writeFileSync('src/components/social/SocialSidebar.tsx', sidebarTsx);
}

let profileTsx = fs.readFileSync('src/components/social/ProfileView.tsx', 'utf8');
if (!profileTsx.includes('onOpenPremium')) {
  profileTsx = profileTsx.replace(
    "export const ProfileView: React.FC = () => {",
    "interface ProfileViewProps { onOpenPremium?: () => void; }\nexport const ProfileView: React.FC<ProfileViewProps> = ({ onOpenPremium }) => {"
  );
  profileTsx = profileTsx.replace(
    '<button className="px-4 py-2.5 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full font-bold text-sm hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">\n                  ZENTORA PREMIUM\n                </button>',
    '<button onClick={onOpenPremium} className="px-4 py-2.5 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full font-bold text-sm hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">\n                  ZENTORA PREMIUM\n                </button>'
  );
  fs.writeFileSync('src/components/social/ProfileView.tsx', profileTsx);
}
