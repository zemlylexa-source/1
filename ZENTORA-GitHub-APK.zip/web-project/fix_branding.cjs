const fs = require('fs');

// 1. Remove Footer Info from FeedView (First screenshot request)
let feedTsx = fs.readFileSync('src/components/social/FeedView.tsx', 'utf8');
feedTsx = feedTsx.replace(
  /<div className="hidden lg:block w-64 pt-8 pr-8 text-xs text-\[var\(--text-secondary\)\] space-y-3 sticky top-0 h-fit">[\s\S]*?<\/div>/,
  ''
);

// 2. Change ИТД to ZENTORA in SocialSidebar
let sidebarTsx = fs.readFileSync('src/components/social/SocialSidebar.tsx', 'utf8');
sidebarTsx = sidebarTsx.replace(
  '<h1 className="font-black text-2xl tracking-tighter">ИТД</h1>',
  '<h1 className="font-black text-2xl tracking-tighter">ZENTORA</h1>'
);
sidebarTsx = sidebarTsx.replace(
  '<span>ИТД НУКСТА</span>',
  '<span>ZENTORA PREMIUM</span>'
);
fs.writeFileSync('src/components/social/SocialSidebar.tsx', sidebarTsx);

// 3. Change ИТД НУКСТА to ZENTORA PREMIUM in ProfileView
let profileTsx = fs.readFileSync('src/components/social/ProfileView.tsx', 'utf8');
profileTsx = profileTsx.replace(
  'ИТД НУКСТА',
  'ZENTORA PREMIUM'
);
fs.writeFileSync('src/components/social/ProfileView.tsx', profileTsx);


// Fix text color contrast in FeedView (light theme visibility)
feedTsx = feedTsx.replace(/text-\[var\(--text-primary\)\]/g, "text-gray-900 dark:text-white");
feedTsx = feedTsx.replace(/text-\[var\(--text-secondary\)\]/g, "text-gray-600 dark:text-gray-400");
feedTsx = feedTsx.replace(/bg-\[\#F3F4F6\]/g, "bg-[#F3F4F6]"); // keep bg-gray-100 equivalent for light theme
fs.writeFileSync('src/components/social/FeedView.tsx', feedTsx);

