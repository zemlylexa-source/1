const fs = require('fs');
let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// Add import for ZentoraPremiumModal
if (!appTsx.includes('import { ZentoraPremiumModal }')) {
  appTsx = appTsx.replace(
    "import { SearchView } from './components/social/SearchView';",
    "import { SearchView } from './components/social/SearchView';\nimport { ZentoraPremiumModal } from './components/social/ZentoraPremiumModal';"
  );
}

// Add state for premium modal
if (!appTsx.includes('showPremiumModal')) {
  appTsx = appTsx.replace(
    "const [showStoriesModal, setShowStoriesModal] = useState(false);",
    "const [showStoriesModal, setShowStoriesModal] = useState(false);\n  const [showPremiumModal, setShowPremiumModal] = useState(false);"
  );
}

// Update SocialSidebar call
appTsx = appTsx.replace(
  "<SocialSidebar activeTab={globalTab} onTabChange={setGlobalTab} />",
  "<SocialSidebar activeTab={globalTab} onTabChange={setGlobalTab} onOpenPremium={() => setShowPremiumModal(true)} />"
);

// Update ProfileView call
appTsx = appTsx.replace(
  "{globalTab === 'profile' && <ProfileView />}",
  "{globalTab === 'profile' && <ProfileView onOpenPremium={() => setShowPremiumModal(true)} />}"
);

// Add the modal component
if (!appTsx.includes('<ZentoraPremiumModal')) {
  appTsx = appTsx.replace(
    "{showStoriesModal && <StoriesModal currentUser={user} isOpen={showStoriesModal} onClose={() => setShowStoriesModal(false)} />}",
    "{showStoriesModal && <StoriesModal currentUser={user} isOpen={showStoriesModal} onClose={() => setShowStoriesModal(false)} />}\n      {showPremiumModal && <ZentoraPremiumModal onClose={() => setShowPremiumModal(false)} />}"
  );
}

fs.writeFileSync('src/App.tsx', appTsx);
