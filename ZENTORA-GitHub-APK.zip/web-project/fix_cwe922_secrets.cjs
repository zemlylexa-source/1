const fs = require('fs');

const file = 'src/context/AuthContext.tsx';
let content = fs.readFileSync(file, 'utf8');

// Inside AuthContext.tsx, there's a sanitizeUser function or similar where we can strip secrets.
// Let's find onSnapshot for users.
const replacement = `      snapshot.forEach(docSnap => {
        const data = docSnap.data() as Partial<User>;
        delete data.twoFASecret;
        delete (data as any)._pwdHash;
        const u: User = {`;

content = content.replace(/      snapshot\.forEach\(docSnap => \{\n        const data = docSnap\.data\(\) as Partial<User>;\n        const u: User = \{/, replacement);

// Also sanitize in login if we load from localStorage?
// We can just add a global sanitize function and use it before setting usersMap.

fs.writeFileSync(file, content);
