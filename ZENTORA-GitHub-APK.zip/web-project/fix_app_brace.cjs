const fs = require('fs');

let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// The replacement script messed up the braces of MainLayout because it probably didn't match the whole structure exactly, or left a stray closing brace.
// Let's find the closing of MainLayout and ensure it's correct.

// Find where MainLayout ends.
const mainLayoutEnd = appTsx.indexOf('export default function App()');

let mainLayoutContent = appTsx.substring(0, mainLayoutEnd);

// Let's count open/close braces in mainLayoutContent
let openCount = (mainLayoutContent.match(/\{/g) || []).length;
let closeCount = (mainLayoutContent.match(/\}/g) || []).length;

console.log("Open Braces:", openCount, "Close Braces:", closeCount);

// There's a stray `};` at the end of the previous replacement or something.
appTsx = appTsx.replace(
`      {showStoriesModal && <StoriesModal currentUser={user} isOpen={showStoriesModal} onClose={() => setShowStoriesModal(false)} />}
      {showPremiumModal && <ZentoraPremiumModal onClose={() => setShowPremiumModal(false)} />}`,
`      {showStoriesModal && <StoriesModal currentUser={user} isOpen={showStoriesModal} onClose={() => setShowStoriesModal(false)} />}`
)

fs.writeFileSync('src/App.tsx', appTsx);
