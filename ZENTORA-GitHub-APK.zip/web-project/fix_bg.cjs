const fs = require('fs');
let chatArea = fs.readFileSync('src/components/ChatArea.tsx', 'utf8');

const oldBg = `<div className="absolute inset-0 bg-[var(--background)] pointer-events-none" />`;
const newBg = `
      {/* Pattern Background matching Telegram */}
      <div 
        className="absolute inset-0 bg-[var(--background)] pointer-events-none" 
        style={{
          backgroundImage: 'url("https://www.transparenttextures.com/patterns/cubes.png")',
          opacity: 0.25,
          backgroundSize: '200px'
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[var(--background)]/80 to-[var(--background)]/30 pointer-events-none" />
`;

chatArea = chatArea.replace(oldBg, newBg);
fs.writeFileSync('src/components/ChatArea.tsx', chatArea);
