const fs = require('fs');
let appTsx = fs.readFileSync('src/App.tsx', 'utf8');

// The replacement script replaced the social imports but left out some variables that were defined.
// Also we need to fix the stray '};' if any.

appTsx = appTsx.replace(
  "const [globalTab, setGlobalTab] = useState<'messenger' | 'feed' | 'profile' | 'notifications' | 'search' | 'store' | 'event'>('messenger');",
  ""
);

appTsx = appTsx.replace(
  "const [showPremiumModal, setShowPremiumModal] = useState(false);",
  ""
);

fs.writeFileSync('src/App.tsx', appTsx);
