const fs = require('fs');
let code = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');

code = code.replace(/const \[messagesMap, setMessagesMap\] = useState<Record<string, Message\[\]>>\(\(\) => \{[\s\S]*?\}\);/,
`const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>(() => {
    const saved = localStorage.getItem('zentora_messages');
    if (!saved) return INITIAL_MESSAGES;
    const loaded = JSON.parse(saved);
    if (loaded['chat_elena']) {
       localStorage.removeItem('zentora_messages');
       return INITIAL_MESSAGES;
    }
    return loaded;
  });`);

fs.writeFileSync('src/context/ChatContext.tsx', code);
