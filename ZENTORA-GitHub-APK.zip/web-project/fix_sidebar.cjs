const fs = require('fs');
let content = fs.readFileSync('src/components/Sidebar.tsx', 'utf8');

if (!content.includes('import { collection')) {
  content = content.replace(
    "import { Chat, Message } from '../types';",
    "import { Chat, Message } from '../types';\nimport { collection, query, where, getDocs } from 'firebase/firestore';\nimport { db } from '../lib/firebase';"
  );
}

// Replace search fetch
const searchEffect = `
  useEffect(() => {
    const clean = qClean.trim();
    if (clean.length >= 3) {
      const handler = setTimeout(async () => {
        try {
          const q = query(collection(db, 'users'), where('username', '==', clean));
          const snapshot = await getDocs(q);
          if (!snapshot.empty) {
            setSearchedUser(snapshot.docs[0].data());
            setSearchNotFound(false);
          } else {
            setSearchedUser(null);
            setSearchNotFound(true);
          }
        } catch (e) {
          console.error("Search error:", e);
          setSearchedUser(null);
          setSearchNotFound(true);
        }
      }, 500);
      return () => clearTimeout(handler);
    } else {
      setSearchedUser(null);
      setSearchNotFound(false);
    }
  }, [qClean]);
`;

content = content.replace(
/  useEffect\(\(\) => \{\s+const clean = qClean\.trim\(\);\s+if \(clean\.length >= 3\) \{\s+const handler = setTimeout\(\(\) => \{\s+fetch\(\`\/api\/users\/search\?username=\$\{encodeURIComponent\(clean\)\}\`\).*?\n\s+return \(\) => clearTimeout\(handler\);\s+\} else \{\s+setSearchedUser\(null\);\s+setSearchNotFound\(false\);\s+\}\s+\}, \[qClean\]\);/s,
  searchEffect.trim()
);

fs.writeFileSync('src/components/Sidebar.tsx', content, 'utf8');
