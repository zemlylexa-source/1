const fs = require('fs');
let code = fs.readFileSync('src/components/CreateChatModal.tsx', 'utf8');

code = code.replace(/let finalName = nameInput;\n    if \(chatType === 'direct'\) \{\n       const target = registeredUsers.find\(u => u\.id === selectedUserIds\[0\]\);\n       if \(target\) finalName = target\.name;\n    \}\n    createChat\(chatType, finalName, selectedUserIds, descInput\);/,
`let finalName = nameInput;
    let finalAvatar = undefined;
    if (chatType === 'direct') {
       const target = registeredUsers.find(u => u.id === selectedUserIds[0]);
       if (target) {
         finalName = target.name;
         finalAvatar = target.avatar;
       }
    }
    createChat(chatType, finalName, selectedUserIds, descInput, finalAvatar);`);

fs.writeFileSync('src/components/CreateChatModal.tsx', code);
