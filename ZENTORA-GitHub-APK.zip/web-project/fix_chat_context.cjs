const fs = require('fs');
let code = fs.readFileSync('src/context/ChatContext.tsx', 'utf8');

code = code.replace(/import \{ INITIAL_CHATS, INITIAL_MESSAGES, MOCK_USERS \} from '\.\.\/lib\/initialData';/, "import { INITIAL_CHATS, INITIAL_MESSAGES } from '../lib/initialData';");

// Use registeredUsers from AuthContext
code = code.replace(/const targetUser = MOCK_USERS\.find\(u => u\.id === memberIds\[0\]\);/, "const targetUser = undefined; // We can't access registeredUsers easily here without refactoring, so we'll pass it from the component.");

fs.writeFileSync('src/context/ChatContext.tsx', code);
