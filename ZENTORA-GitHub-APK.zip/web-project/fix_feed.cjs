const fs = require('fs');

let feedTsx = fs.readFileSync('src/components/social/FeedView.tsx', 'utf8');

// Remove attachment icons from post creation
feedTsx = feedTsx.replace(
  /<div className="flex items-center gap-4 text-gray-600 dark:text-gray-400">[\s\S]*?<\/div>/,
  '<div className="flex items-center gap-4 text-gray-600 dark:text-gray-400"></div>'
);

fs.writeFileSync('src/components/social/FeedView.tsx', feedTsx);

let profileTsx = fs.readFileSync('src/components/social/ProfileView.tsx', 'utf8');
profileTsx = profileTsx.replace(
  /<div className="flex items-center gap-4 text-gray-600 dark:text-gray-400">[\s\S]*?<\/div>/,
  '<div className="flex items-center gap-4 text-gray-600 dark:text-gray-400"></div>'
);
fs.writeFileSync('src/components/social/ProfileView.tsx', profileTsx);
