# ZENTORA Android WebView

Android WebView wrapper for:

https://remix-zentora.ai.studio/

## Build

Open this folder in Android Studio and let Gradle sync.

Then:
Build -> Generate App Bundles or APKs -> Generate APKs

The source ZIP received from the user is preserved under `web-project/`.


## Automatic APK build with GitHub Actions

1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build ZENTORA APK**.
4. Click **Run workflow**.
5. When the workflow finishes, open the run and download the **ZENTORA-debug-apk** artifact.
